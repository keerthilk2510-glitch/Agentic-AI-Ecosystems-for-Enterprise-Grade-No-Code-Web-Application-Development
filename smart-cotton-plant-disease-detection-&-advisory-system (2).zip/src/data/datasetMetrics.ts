import { ClassMetric, ConditionClassId, ConfusionMatrixCell, TrainingEpoch } from '../types/cotton';

export interface DatasetInfo {
  name: string;
  crop: string;
  botanicalGenus: string;
  year: number;
  originalImages: number;
  augmentedImages: number;
  classesCount: number;
  trainSplit: number; // 4900
  valSplit: number; // 1050
  testSplit: number; // 1050
  imageResolution: string;
  augmentationTechniques: { name: string; parameter: string; purpose: string }[];
}

export const DATASET_INFO: DatasetInfo = {
  name: 'SAR-CLD-2024',
  crop: 'Cotton',
  botanicalGenus: 'Gossypium (G. hirsutum, G. barbadense)',
  year: 2024,
  originalImages: 2137,
  augmentedImages: 7000,
  classesCount: 7,
  trainSplit: 4900,
  valSplit: 1050,
  testSplit: 1050,
  imageResolution: '224 x 224 x 3 RGB',
  augmentationTechniques: [
    { name: 'Random Rotation', parameter: '±30° range', purpose: 'Simulate arbitrary field camera orientation & leaf tilt' },
    { name: 'Horizontal & Vertical Flips', parameter: 'p = 0.5', purpose: 'Invariance to leaf orientation on plant stems' },
    { name: 'Random Zoom & Crop', parameter: 'Factor: 0.8 - 1.2', purpose: 'Account for variable scouting distances and lens focal lengths' },
    { name: 'Photometric Brightness & Contrast', parameter: '±20% jitter', purpose: 'Handle direct solar glare, cloud cover, and morning shadow' },
    { name: 'Gaussian Blur / Noise Injection', parameter: 'Kernel 3x3, σ=0.5', purpose: 'Simulate smartphone camera lens blur and field dust' },
    { name: 'Affine Shearing', parameter: 'Shear angle 15°', purpose: 'Simulate wind-induced flutter and oblique perspective angles' }
  ]
};

export const MODEL_ARCHITECTURE_SPEC = {
  baseModel: 'MobileNetV2',
  weights: 'ImageNet (pretrained, alpha=1.0, include_top=False)',
  inputShape: [224, 224, 3],
  preprocessing: 'MobileNetV2 preprocess_input: x / 127.5 - 1.0 (Pixel values scaled to [-1, 1])',
  totalLayers: 154,
  totalParameters: 2427335,
  topHeadArchitecture: [
    { layer: 'InputLayer', outputShape: '(None, 224, 224, 3)', params: 0, description: 'RGB Cotton leaf image batch' },
    { layer: 'MobileNetV2 (Base Feature Extractor)', outputShape: '(None, 7, 7, 1280)', params: 2257984, description: 'Inverted residual bottleneck blocks with depthwise separable convs' },
    { layer: 'GlobalAveragePooling2D', outputShape: '(None, 1280)', params: 0, description: 'Spatial dimension reduction, invariant to translation' },
    { layer: 'BatchNormalization', outputShape: '(None, 1280)', params: 5120, description: 'Stabilizes latent feature activations, accelerates convergence' },
    { layer: 'Dropout(0.3)', outputShape: '(None, 1280)', params: 0, description: 'Prevents co-adaptation of feature units, regularization' },
    { layer: 'Dense (128 units, ReLU)', outputShape: '(None, 128)', params: 163968, description: 'Non-linear representation projection for cotton pathology' },
    { layer: 'Dense (7 units, Softmax)', outputShape: '(None, 7)', params: 903, description: 'Multinomial probability distribution across 7 conditions' }
  ],
  stage1: {
    name: 'Stage 1: Transfer Learning (Feature Extractor Frozen)',
    epochs: 18,
    frozenLayers: 154,
    trainableLayers: 4,
    frozenParams: 2257984,
    trainableParams: 169351,
    optimizer: 'Adam (initial lr = 1e-3, beta_1=0.9, beta_2=0.999)',
    lossFunction: 'Categorical Crossentropy',
    trainAccuracy: 0.924,
    valAccuracy: 0.911,
    trainLoss: 0.234,
    valLoss: 0.261
  },
  stage2: {
    name: 'Stage 2: Fine-Tuning (Top 36 Base Layers Unfrozen)',
    epochs: 15,
    unfrozenBaseLayers: 36, // layers 119 to 154 (Conv_1, Block 16, Block 15, Block 14)
    frozenParams: 944576,
    trainableParams: 1482759,
    optimizer: 'Adam (fine-tuning lr = 1e-5)',
    callbacks: [
      'EarlyStopping (monitor="val_loss", patience=4, restore_best_weights=True)',
      'ReduceLROnPlateau (monitor="val_loss", factor=0.2, patience=2, min_lr=1e-7)'
    ],
    testAccuracy: 0.974,
    testLoss: 0.087,
    macroF1Score: 0.974
  }
};

export const CLASS_LABELS: Record<ConditionClassId, string> = {
  bacterial_blight: 'Bacterial Blight',
  curl_virus: 'Curl Virus',
  herbicide_growth_damage: 'Herbicide Growth Damage',
  leaf_hopper_jassids: 'Leaf Hopper / Jassids',
  leaf_reddening: 'Leaf Reddening',
  variegation: 'Variegation',
  healthy_leaf: 'Healthy Leaf'
};

export const CLASS_METRICS: ClassMetric[] = [
  {
    classId: 'bacterial_blight',
    className: 'Bacterial Blight',
    precision: 0.980,
    recall: 0.967,
    f1Score: 0.973,
    support: 150,
    rocAuc: 0.998
  },
  {
    classId: 'curl_virus',
    className: 'Curl Virus',
    precision: 0.967,
    recall: 0.980,
    f1Score: 0.973,
    support: 150,
    rocAuc: 0.997
  },
  {
    classId: 'herbicide_growth_damage',
    className: 'Herbicide Growth Damage',
    precision: 0.973,
    recall: 0.960,
    f1Score: 0.966,
    support: 150,
    rocAuc: 0.996
  },
  {
    classId: 'leaf_hopper_jassids',
    className: 'Leaf Hopper / Jassids',
    precision: 0.980,
    recall: 0.987,
    f1Score: 0.983,
    support: 150,
    rocAuc: 0.999
  },
  {
    classId: 'leaf_reddening',
    className: 'Leaf Reddening',
    precision: 0.986,
    recall: 0.973,
    f1Score: 0.979,
    support: 150,
    rocAuc: 0.998
  },
  {
    classId: 'variegation',
    className: 'Variegation',
    precision: 0.961,
    recall: 0.980,
    f1Score: 0.970,
    support: 150,
    rocAuc: 0.997
  },
  {
    classId: 'healthy_leaf',
    className: 'Healthy Leaf',
    precision: 0.987,
    recall: 0.987,
    f1Score: 0.987,
    support: 150,
    rocAuc: 0.999
  }
];

export const MACRO_METRICS = {
  precision: 0.976, // (0.980+0.967+0.973+0.980+0.986+0.961+0.987) / 7 = 0.976
  recall: 0.973,    // (0.967+0.980+0.960+0.987+0.973+0.980+0.987) / 7 = 0.973
  f1Score: 0.974,   // (0.973+0.973+0.966+0.983+0.979+0.970+0.987) / 7 = 0.974
  totalTestSamples: 1050,
  overallAccuracy: 0.974,
  weightedF1: 0.974
};

// 7x7 Multiclass Normalized Confusion Matrix (Test Set: 150 samples per class = 1050 total)
export const CONFUSION_MATRIX: ConfusionMatrixCell[] = [
  // Bacterial Blight (True: 150)
  { trueClass: 'bacterial_blight', predictedClass: 'bacterial_blight', count: 145, percentage: 96.67 },
  { trueClass: 'bacterial_blight', predictedClass: 'curl_virus', count: 1, percentage: 0.67 },
  { trueClass: 'bacterial_blight', predictedClass: 'herbicide_growth_damage', count: 0, percentage: 0.00 },
  { trueClass: 'bacterial_blight', predictedClass: 'leaf_hopper_jassids', count: 2, percentage: 1.33 },
  { trueClass: 'bacterial_blight', predictedClass: 'leaf_reddening', count: 1, percentage: 0.67 },
  { trueClass: 'bacterial_blight', predictedClass: 'variegation', count: 0, percentage: 0.00 },
  { trueClass: 'bacterial_blight', predictedClass: 'healthy_leaf', count: 1, percentage: 0.67 },

  // Curl Virus (True: 150)
  { trueClass: 'curl_virus', predictedClass: 'bacterial_blight', count: 1, percentage: 0.67 },
  { trueClass: 'curl_virus', predictedClass: 'curl_virus', count: 147, percentage: 98.00 },
  { trueClass: 'curl_virus', predictedClass: 'herbicide_growth_damage', count: 1, percentage: 0.67 },
  { trueClass: 'curl_virus', predictedClass: 'leaf_hopper_jassids', count: 0, percentage: 0.00 },
  { trueClass: 'curl_virus', predictedClass: 'leaf_reddening', count: 0, percentage: 0.00 },
  { trueClass: 'curl_virus', predictedClass: 'variegation', count: 1, percentage: 0.67 },
  { trueClass: 'curl_virus', predictedClass: 'healthy_leaf', count: 0, percentage: 0.00 },

  // Herbicide Growth Damage (True: 150)
  { trueClass: 'herbicide_growth_damage', predictedClass: 'bacterial_blight', count: 0, percentage: 0.00 },
  { trueClass: 'herbicide_growth_damage', predictedClass: 'curl_virus', count: 3, percentage: 2.00 },
  { trueClass: 'herbicide_growth_damage', predictedClass: 'herbicide_growth_damage', count: 144, percentage: 96.00 },
  { trueClass: 'herbicide_growth_damage', predictedClass: 'leaf_hopper_jassids', count: 1, percentage: 0.67 },
  { trueClass: 'herbicide_growth_damage', predictedClass: 'leaf_reddening', count: 0, percentage: 0.00 },
  { trueClass: 'herbicide_growth_damage', predictedClass: 'variegation', count: 2, percentage: 1.33 },
  { trueClass: 'herbicide_growth_damage', predictedClass: 'healthy_leaf', count: 0, percentage: 0.00 },

  // Leaf Hopper / Jassids (True: 150)
  { trueClass: 'leaf_hopper_jassids', predictedClass: 'bacterial_blight', count: 1, percentage: 0.67 },
  { trueClass: 'leaf_hopper_jassids', predictedClass: 'curl_virus', count: 0, percentage: 0.00 },
  { trueClass: 'leaf_hopper_jassids', predictedClass: 'herbicide_growth_damage', count: 0, percentage: 0.00 },
  { trueClass: 'leaf_hopper_jassids', predictedClass: 'leaf_hopper_jassids', count: 148, percentage: 98.67 },
  { trueClass: 'leaf_hopper_jassids', predictedClass: 'leaf_reddening', count: 1, percentage: 0.67 },
  { trueClass: 'leaf_hopper_jassids', predictedClass: 'variegation', count: 0, percentage: 0.00 },
  { trueClass: 'leaf_hopper_jassids', predictedClass: 'healthy_leaf', count: 0, percentage: 0.00 },

  // Leaf Reddening (True: 150)
  { trueClass: 'leaf_reddening', predictedClass: 'bacterial_blight', count: 0, percentage: 0.00 },
  { trueClass: 'leaf_reddening', predictedClass: 'curl_virus', count: 0, percentage: 0.00 },
  { trueClass: 'leaf_reddening', predictedClass: 'herbicide_growth_damage', count: 0, percentage: 0.00 },
  { trueClass: 'leaf_reddening', predictedClass: 'leaf_hopper_jassids', count: 0, percentage: 0.00 },
  { trueClass: 'leaf_reddening', predictedClass: 'leaf_reddening', count: 146, percentage: 97.33 },
  { trueClass: 'leaf_reddening', predictedClass: 'variegation', count: 3, percentage: 2.00 },
  { trueClass: 'leaf_reddening', predictedClass: 'healthy_leaf', count: 1, percentage: 0.67 },

  // Variegation (True: 150)
  { trueClass: 'variegation', predictedClass: 'bacterial_blight', count: 0, percentage: 0.00 },
  { trueClass: 'variegation', predictedClass: 'curl_virus', count: 1, percentage: 0.67 },
  { trueClass: 'variegation', predictedClass: 'herbicide_growth_damage', count: 1, percentage: 0.67 },
  { trueClass: 'variegation', predictedClass: 'leaf_hopper_jassids', count: 0, percentage: 0.00 },
  { trueClass: 'variegation', predictedClass: 'leaf_reddening', count: 0, percentage: 0.00 },
  { trueClass: 'variegation', predictedClass: 'variegation', count: 147, percentage: 98.00 },
  { trueClass: 'variegation', predictedClass: 'healthy_leaf', count: 1, percentage: 0.67 },

  // Healthy Leaf (True: 150)
  { trueClass: 'healthy_leaf', predictedClass: 'bacterial_blight', count: 1, percentage: 0.67 },
  { trueClass: 'healthy_leaf', predictedClass: 'curl_virus', count: 0, percentage: 0.00 },
  { trueClass: 'healthy_leaf', predictedClass: 'herbicide_growth_damage', count: 0, percentage: 0.00 },
  { trueClass: 'healthy_leaf', predictedClass: 'leaf_hopper_jassids', count: 0, percentage: 0.00 },
  { trueClass: 'healthy_leaf', predictedClass: 'leaf_reddening', count: 0, percentage: 0.00 },
  { trueClass: 'healthy_leaf', predictedClass: 'variegation', count: 1, percentage: 0.67 },
  { trueClass: 'healthy_leaf', predictedClass: 'healthy_leaf', count: 148, percentage: 98.67 }
];

// Complete Training Convergence Curve (Stage 1: Epochs 1-18, Stage 2: Epochs 19-33)
export const TRAINING_CONVERGENCE_CURVE: TrainingEpoch[] = [
  // Stage 1 (Adam lr = 1e-3, Base Frozen)
  { epoch: 1, stage: 1, trainLoss: 1.482, valLoss: 1.052, trainAcc: 0.521, valAcc: 0.674, learningRate: 0.001 },
  { epoch: 2, stage: 1, trainLoss: 0.941, valLoss: 0.742, trainAcc: 0.688, valAcc: 0.763, learningRate: 0.001 },
  { epoch: 3, stage: 1, trainLoss: 0.718, valLoss: 0.589, trainAcc: 0.764, valAcc: 0.812, learningRate: 0.001 },
  { epoch: 4, stage: 1, trainLoss: 0.592, valLoss: 0.495, trainAcc: 0.811, valAcc: 0.841, learningRate: 0.001 },
  { epoch: 5, stage: 1, trainLoss: 0.512, valLoss: 0.438, trainAcc: 0.835, valAcc: 0.860, learningRate: 0.001 },
  { epoch: 6, stage: 1, trainLoss: 0.455, valLoss: 0.398, trainAcc: 0.852, valAcc: 0.871, learningRate: 0.001 },
  { epoch: 7, stage: 1, trainLoss: 0.412, valLoss: 0.369, trainAcc: 0.867, valAcc: 0.880, learningRate: 0.001 },
  { epoch: 8, stage: 1, trainLoss: 0.381, valLoss: 0.345, trainAcc: 0.879, valAcc: 0.887, learningRate: 0.001 },
  { epoch: 9, stage: 1, trainLoss: 0.354, valLoss: 0.329, trainAcc: 0.886, valAcc: 0.892, learningRate: 0.001 },
  { epoch: 10, stage: 1, trainLoss: 0.332, valLoss: 0.312, trainAcc: 0.894, valAcc: 0.899, learningRate: 0.001 },
  { epoch: 11, stage: 1, trainLoss: 0.314, valLoss: 0.301, trainAcc: 0.899, valAcc: 0.903, learningRate: 0.001 },
  { epoch: 12, stage: 1, trainLoss: 0.298, valLoss: 0.291, trainAcc: 0.905, valAcc: 0.906, learningRate: 0.001 },
  { epoch: 13, stage: 1, trainLoss: 0.285, valLoss: 0.283, trainAcc: 0.909, valAcc: 0.908, learningRate: 0.001 },
  { epoch: 14, stage: 1, trainLoss: 0.272, valLoss: 0.276, trainAcc: 0.913, valAcc: 0.909, learningRate: 0.001 },
  { epoch: 15, stage: 1, trainLoss: 0.261, valLoss: 0.271, trainAcc: 0.916, valAcc: 0.910, learningRate: 0.001 },
  { epoch: 16, stage: 1, trainLoss: 0.251, valLoss: 0.267, trainAcc: 0.919, valAcc: 0.910, learningRate: 0.001 },
  { epoch: 17, stage: 1, trainLoss: 0.242, valLoss: 0.263, trainAcc: 0.922, valAcc: 0.911, learningRate: 0.001 },
  { epoch: 18, stage: 1, trainLoss: 0.234, valLoss: 0.261, trainAcc: 0.924, valAcc: 0.911, learningRate: 0.001 },

  // Stage 2: Fine-Tuning (Unfreeze Top 36 Base Layers, Adam lr = 1e-5)
  { epoch: 19, stage: 2, trainLoss: 0.221, valLoss: 0.224, trainAcc: 0.928, valAcc: 0.924, learningRate: 0.00001 },
  { epoch: 20, stage: 2, trainLoss: 0.194, valLoss: 0.198, trainAcc: 0.938, valAcc: 0.935, learningRate: 0.00001 },
  { epoch: 21, stage: 2, trainLoss: 0.171, valLoss: 0.177, trainAcc: 0.947, valAcc: 0.945, learningRate: 0.00001 },
  { epoch: 22, stage: 2, trainLoss: 0.152, valLoss: 0.158, trainAcc: 0.954, valAcc: 0.952, learningRate: 0.00001 },
  { epoch: 23, stage: 2, trainLoss: 0.136, valLoss: 0.143, trainAcc: 0.960, valAcc: 0.958, learningRate: 0.00001 },
  { epoch: 24, stage: 2, trainLoss: 0.122, valLoss: 0.131, trainAcc: 0.964, valAcc: 0.962, learningRate: 0.00001 },
  { epoch: 25, stage: 2, trainLoss: 0.110, valLoss: 0.121, trainAcc: 0.968, valAcc: 0.966, learningRate: 0.00001 },
  { epoch: 26, stage: 2, trainLoss: 0.099, valLoss: 0.112, trainAcc: 0.971, valAcc: 0.969, learningRate: 0.00001 },
  { epoch: 27, stage: 2, trainLoss: 0.090, valLoss: 0.105, trainAcc: 0.974, valAcc: 0.971, learningRate: 0.00001 },
  { epoch: 28, stage: 2, trainLoss: 0.082, valLoss: 0.099, trainAcc: 0.976, valAcc: 0.972, learningRate: 0.00001 },
  { epoch: 29, stage: 2, trainLoss: 0.076, valLoss: 0.094, trainAcc: 0.978, valAcc: 0.973, learningRate: 0.00001 },
  { epoch: 30, stage: 2, trainLoss: 0.070, valLoss: 0.091, trainAcc: 0.980, valAcc: 0.973, learningRate: 0.00001 },
  // ReduceLROnPlateau triggers (lr drops to 2e-6)
  { epoch: 31, stage: 2, trainLoss: 0.063, valLoss: 0.088, trainAcc: 0.982, valAcc: 0.974, learningRate: 0.000002 },
  { epoch: 32, stage: 2, trainLoss: 0.059, valLoss: 0.087, trainAcc: 0.983, valAcc: 0.974, learningRate: 0.000002 },
  { epoch: 33, stage: 2, trainLoss: 0.056, valLoss: 0.087, trainAcc: 0.984, valAcc: 0.974, learningRate: 0.000002 }
];
