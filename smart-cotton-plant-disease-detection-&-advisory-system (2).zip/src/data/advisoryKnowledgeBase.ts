import { AdvisoryDetails, ConditionClassId } from '../types/cotton';

export const ADVISORY_KNOWLEDGE_BASE: Record<ConditionClassId, AdvisoryDetails> = {
  bacterial_blight: {
    id: 'bacterial_blight',
    commonName: 'Bacterial Blight (Angular Leaf Spot / Blackarm)',
    scientificName: 'Xanthomonas citri pv. malvacearum',
    casualAgent: 'Bacterial pathogen (Gram-negative rod, seed & debris-borne)',
    diseaseType: 'Bacterial',
    severity: 'Critical',
    severityScore: 88,
    economicThresholdLevel: '10% of plants showing angular water-soaked lesions or 2 blackarm lesions/plant',
    botanicalDescription: 'Bacterial blight is one of the most destructive foliar diseases in Gossypium hirsutum, causing angular leaf spots bounded by leaf veins, vein necrosis, and petiole blackarm lesions that can induce catastrophic premature defoliation.',
    symptoms: {
      earlyStage: 'Small, water-soaked polygonal spots on the abaxial (lower) leaf surface restricted strictly between leaf veins.',
      advancedStage: 'Lesions turn dark brown to purplish-black with an angular geometric outline; coalescence causes extensive necrosis, petiole blackarm girdling, and leaf shedding.',
      foliarMarkers: [
        'Vein-delimited angular water-soaked spots',
        'Dark brownish-black geometric necrotic patches',
        'Girdling black lesions on petiole & stem (Blackarm phase)',
        'Water-soaked circular spots on bolls turning into boll rot'
      ],
      affectedParts: ['Cotyledons', 'Foliar blade', 'Petioles', 'Fruiting branches', 'Green bolls']
    },
    immediateCulturalControl: [
      'Immediately isolate and rogue out severely infected seedling foci before rain splash or overhead sprinkler irrigation.',
      'Switch strictly from overhead sprinkler to drip irrigation to prevent bacterial aerosol dispersal across rows.',
      'Refrain from field operations, inter-cultivation, or personnel movement while foliage is wet with morning dew.',
      'Burn or deeply bury post-harvest infected cotton stubble and crop residue to reduce primary inoculum.'
    ],
    chemicalRemedies: [
      {
        activeIngredient: 'Copper Oxychloride 50% WP + Streptomycin Sulphate 9% + Tetracycline Hydrochloride 1%',
        recommendedBrands: ['Blitox 50 + Streptocycline', 'Cupramar + Plantomycin'],
        dosagePerHectare: '1.25 kg Copper Oxychloride + 100 g Streptocycline',
        dosagePerAcre: '500 g Copper Oxychloride + 40 g Streptocycline',
        applicationMode: 'High-volume foliar canopy spray targeting both upper and lower leaf surfaces',
        waterVolume: '450 - 500 Liters/ha (180 - 200 L/acre)',
        safetyIntervalDays: 14
      },
      {
        activeIngredient: 'Copper Hydroxide 53.8% DF',
        recommendedBrands: ['Kocide 3000', 'Champ DP'],
        dosagePerHectare: '1.0 kg/ha',
        dosagePerAcre: '400 g/acre',
        applicationMode: 'Preventive protective foliar wash at first appearance of angular spots',
        waterVolume: '450 Liters/ha',
        safetyIntervalDays: 14
      }
    ],
    biologicalRemedies: [
      {
        agentName: 'Pseudomonas fluorescens 1% WP (TNAU / ICAR isolate)',
        type: 'Beneficial Microbe',
        preparationMethod: 'Mix 10 g/kg seed for delinted seed treatment, or 2.5 kg/ha with 500 L water for foliar wash.',
        applicationNotes: 'Produces 2,4-diacetylphloroglucinol (DAPG) and pyoluteorin which effectively inhibit Xanthomonas colonization.'
      },
      {
        agentName: 'Bacillus subtilis (Strain QST 713 / FZB24)',
        type: 'Bio-fungicide',
        preparationMethod: 'Foliar spray at 2.0 L/ha (800 ml/acre) in 500 L water.',
        applicationNotes: 'Induces systemic acquired resistance (SAR) in cotton vascular tissues.'
      }
    ],
    preventionAndIPM: [
      'Acid delinting of cottonseed: treat seeds with concentrated Sulphuric Acid (100 ml/kg seed) to eliminate seed coat bacterial bacteria.',
      'Cultivate certified bacterial blight-resistant hybrids (e.g., cultivars incorporating B2, B3, B12 resistance gene complexes).',
      'Follow 3-year crop rotation with non-host graminaceous crops such as sorghum, pearl millet, or maize.',
      'Avoid excessive vegetative nitrogen top-dressing; maintain balanced Potassium (K2O) fertilization to thicken leaf epidermal cuticle.'
    ],
    optimalSprayingWindow: 'Early morning (06:30 - 09:30) or late afternoon (16:30 - 18:30) when leaf stomata are open and winds are < 8 km/h.'
  },

  curl_virus: {
    id: 'curl_virus',
    commonName: 'Cotton Leaf Curl Virus (CLCuV)',
    scientificName: 'Cotton leaf curl virus complex (Genus: Begomovirus, Family: Geminiviridae)',
    casualAgent: 'Monopartite Begomovirus transmitted by Silverleaf Whitefly (Bemisia tabaci)',
    diseaseType: 'Viral',
    severity: 'Critical',
    severityScore: 92,
    economicThresholdLevel: '5 to 8 Whitefly adults per leaf or 5% incidence of upward leaf cupping at square stage',
    botanicalDescription: 'A devastating viral disease spread persistently by Bemisia tabaci, causing deep upward/downward cup distortion, swollen leaf veins, cup-shaped foliar outgrowths (enations) under leaves, and extreme plant stunting.',
    symptoms: {
      earlyStage: 'Small vein thickening on the lower surface of young leaves, visible by holding the leaf against sunlight.',
      advancedStage: 'Pronounced upward curling of leaf margins, severe vein thickening, enation (cup-shaped leaf-like enations) on main veins, brittle crinkled foliage, and aborted square formation.',
      foliarMarkers: [
        'Upward and downward margin rolling into cup shapes',
        'Swollen, opaque primary and secondary veins',
        'Leaf-like enation outgrowths underneath the blade',
        'Severely stunted shortened internodes and bunched crown'
      ],
      affectedParts: ['Terminal shoot', 'Youngest upper leaves', 'Vein network', 'Fruiting buds (squares)']
    },
    immediateCulturalControl: [
      'Rogue out and destroy infected viral symptomatic plants within the first 60 days after sowing.',
      'Eradicate alternative dicotyledonous weed hosts around bunds (e.g., Sida acuta, Abutilon indicum, Parthenium hysterophorus).',
      'Install yellow sticky traps (15 - 20 traps per hectare) at canopy level to monitor and mass-trap whitefly vector populations.',
      'Avoid planting cotton adjacent to alternate whitefly host crops like okra (ladyfinger), tomato, or brinjal.'
    ],
    chemicalRemedies: [
      {
        activeIngredient: 'Diafenthiuron 50% WP (Vector Control)',
        recommendedBrands: ['Pegasus 50 WP', 'Polo 50 WP'],
        dosagePerHectare: '600 g/ha',
        dosagePerAcre: '250 g/acre',
        applicationMode: 'Thorough coverage of underleaf surface targeting whitefly nymphs and adults',
        waterVolume: '500 Liters/ha',
        safetyIntervalDays: 21
      },
      {
        activeIngredient: 'Pyriproxyfen 10% EC + Fenpropathrin 10% EC',
        recommendedBrands: ['Sumipresto', 'Tiger'],
        dosagePerHectare: '1.0 Liter/ha',
        dosagePerAcre: '400 ml/acre',
        applicationMode: 'Juvenile hormone mimic targeting egg hatch and early nymphal stages',
        waterVolume: '500 Liters/ha',
        safetyIntervalDays: 15
      },
      {
        activeIngredient: 'Afidopyropen 50 g/L DC',
        recommendedBrands: ['Sefina'],
        dosagePerHectare: '1.0 Liter/ha',
        dosagePerAcre: '400 ml/acre',
        applicationMode: 'Chordotonal organ TRPV channel modulator with swift knockdown against resistant whiteflies',
        waterVolume: '500 Liters/ha',
        safetyIntervalDays: 14
      }
    ],
    biologicalRemedies: [
      {
        agentName: 'Neem Seed Kernel Extract (NSKE 5%) or Azadirachtin 10,000 ppm',
        type: 'Botanical Extract',
        preparationMethod: '1.0 Liter of Azadirachtin (1% EC) per hectare in 500 L water.',
        applicationNotes: 'Repels adult whitefly oviposition, disrupts chitin molting, and reduces viral transmission efficiency.'
      },
      {
        agentName: 'Verticillium lecanii (Lecanicillium lecanii) 1x10^8 CFU/g',
        type: 'Bio-insecticide',
        preparationMethod: '2.5 kg/ha applied as high-humidity foliar spray.',
        applicationNotes: 'Entomopathogenic fungus that parasitizes whitefly nymphs.'
      }
    ],
    preventionAndIPM: [
      'Plant only verified CLCuV-tolerant cotton cultivars (e.g., resistant hybrids bred for CLCuD resistance).',
      'Maintain an early synchronized sowing window to avoid coinciding tender plant stages with peak summer whitefly migration.',
      'Sow border barrier crops of 3–4 rows of forage sorghum or pearl millet to hinder whitefly airflow ingress.',
      'Strictly avoid synthetic pyrethroid early applications which trigger whitefly resurgence by eliminating natural predators.'
    ],
    optimalSprayingWindow: 'Early morning when whiteflies are sluggish on the undersides of leaves.'
  },

  herbicide_growth_damage: {
    id: 'herbicide_growth_damage',
    commonName: 'Herbicide Growth Regulator Damage',
    scientificName: 'Non-pathogenic Abiotic Phytotoxicity (Synthetic Auxin / Glyphosate Drift)',
    casualAgent: 'Spray drift or tank contamination of 2,4-D, Dicamba, or Glyphosate',
    diseaseType: 'Abiotic / Chemical',
    severity: 'Moderate',
    severityScore: 65,
    economicThresholdLevel: 'Visible strapping/epinasty on > 5% of terminal leaves within 50m of neighboring crop boundary',
    botanicalDescription: 'Physiological injury caused by hormone-type herbicide drift (phenoxys, synthetic auxins) or non-selective amino acid synthesis inhibitors, producing classic leaf strapping, parallel venation, downward epinasty, and malformed square clusters.',
    symptoms: {
      earlyStage: 'Rapid stem bending (epinasty) within 24-48 hours, petiole twisting, and prominent vein clearing.',
      advancedStage: 'New leaves develop abnormal "fan-like" strapping, narrow elongated finger lobes, parallel secondary veins without typical webbed venation, and brittle petioles.',
      foliarMarkers: [
        'Fan-like leaf strapping and finger-shaped lobes',
        'Abnormal parallel venation with leathery texture',
        'Downward stem and petiole epinasty (stem twisting)',
        'Proliferation of stunted deformed squares'
      ],
      affectedParts: ['Terminal meristem', 'Young unfolding leaves', 'Petioles', 'Squares and blooms']
    },
    immediateCulturalControl: [
      'Identify and halt any ongoing spraying operations on adjacent wheat, corn, or non-crop areas immediately.',
      'Flush irrigation ditches and clean tank delivery lines with 1% ammonia solution or activated charcoal slurry.',
      'Do NOT prune damaged branches immediately; allow terminal bud 10 to 14 days to determine whether vegetative meristems recover.',
      'Provide immediate light irrigation to dilute root-zone systemic concentration if herbicide was soil-applied.'
    ],
    chemicalRemedies: [
      {
        activeIngredient: 'Foliar Bio-stimulant: Nitrobenzene 20% w/w + Amino Acid Complex',
        recommendedBrands: ['Boom Flower', 'Isabion', 'Fantac Plus'],
        dosagePerHectare: '1.25 Liters/ha',
        dosagePerAcre: '500 ml/acre',
        applicationMode: 'Canopy foliar spray to stimulate cell division and overcome auxin shock',
        waterVolume: '400 Liters/ha',
        safetyIntervalDays: 0
      },
      {
        activeIngredient: 'Foliar Nutrient Booster: 19:19:19 (N:P:K) Water Soluble + Micronutrients',
        recommendedBrands: ['Polyfeed 19-19-19', 'Nutrivex'],
        dosagePerHectare: '2.5 kg/ha',
        dosagePerAcre: '1.0 kg/acre',
        applicationMode: 'Foliar feed combined with Zinc EDTA (0.5 g/L) to replenish damaged chloroplasts',
        waterVolume: '500 Liters/ha',
        safetyIntervalDays: 0
      }
    ],
    biologicalRemedies: [
      {
        agentName: 'Seaweed Extract (Ascophyllum nodosum) 28% Liquid',
        type: 'Nutritional Foliar',
        preparationMethod: '1.0 L/ha in 400 L water.',
        applicationNotes: 'Contains natural betaines, cytokinins, and auxin-antagonizing precursors that alleviate chemical stress.'
      },
      {
        agentName: 'Humic Acid 12% + Fulvic Acid Complex',
        type: 'Nutritional Foliar',
        preparationMethod: '2.5 L/ha applied via fertigation or root drench.',
        applicationNotes: 'Enhances root cation exchange capacity and speeds up plant detoxification pathways.'
      }
    ],
    preventionAndIPM: [
      'Enforce strict dedicated herbicide sprayers—never use herbicide spray equipment for cotton foliar fungicides or insecticides.',
      'Maintain minimum 150m buffer zones when applying hormone herbicides on upwind neighboring cereals.',
      'Install low-drift air-induction nozzles (AIXR or TTI) operating at low pressures (< 2.5 bar) during herbicide applications.',
      'Document wind speed (< 10 km/h) and temperature inversions before any application near cotton fields.'
    ],
    optimalSprayingWindow: 'Apply recovery foliar bio-stimulants during calm cool evening hours.'
  },

  leaf_hopper_jassids: {
    id: 'leaf_hopper_jassids',
    commonName: 'Leaf Hopper / Jassids Infestation (Hopperburn)',
    scientificName: 'Amrasca biguttula biguttula (Hemiptera: Cicadellidae)',
    casualAgent: 'Sucking insect pest injecting phytotoxic salivary secretions while feeding',
    diseaseType: 'Pest Infestation',
    severity: 'High',
    severityScore: 82,
    economicThresholdLevel: '1 to 2 jassid nymphs per leaf or Grade-II hopperburn symptoms (yellowing and marginal curling)',
    botanicalDescription: 'Both green nymphs and adults suck phloem sap from the lower leaf blade and inject toxic saliva containing enzymes that disintegrate mesophyll tissue, producing characteristic marginal hopperburn, downward rolling, and bronze necrosis.',
    symptoms: {
      earlyStage: 'Mild yellowing (chlorosis) along the leaf margins, with translucent wedge-shaped patches.',
      advancedStage: 'Marginal tissue turns brown, dry, and brittle (hopperburn); leaves cup downwards, turn reddish-brown to burnt brick red, and prematurely drop.',
      foliarMarkers: [
        'Wedge-shaped marginal chlorosis progressing inward',
        'Downward curling and cupping of leaf edges',
        'Scorched necrotic "hopperburn" along peripheral lobes',
        'Presence of small pale-green wedge-shaped nymphs running diagonally on undersides'
      ],
      affectedParts: ['Abaxial (lower) leaf surfaces', 'Middle and top canopy leaves', 'Fruiting squares']
    },
    immediateCulturalControl: [
      'Conduct regular sweep net or underside leaf counts twice weekly during vegetative and flowering stages.',
      'Conserve natural predators including Chrysoperla carnea (green lacewing), ladybird beetles (Coccinella septempunctata), and predatory spiders.',
      'Avoid high-rate excessive split applications of urea/nitrogen which render leaves tender, succulent, and highly attractive to jassids.',
      'Maintain weed-free border strips to deprive overwintering jassid populations of alternate hosts.'
    ],
    chemicalRemedies: [
      {
        activeIngredient: 'Flonicamid 50% WG',
        recommendedBrands: ['Ulala', 'Teppeki'],
        dosagePerHectare: '200 g/ha',
        dosagePerAcre: '80 g/acre',
        applicationMode: 'Systemic selective feeding blocker; stops jassid sucking within 30 minutes without harming pollinators',
        waterVolume: '500 Liters/ha',
        safetyIntervalDays: 20
      },
      {
        activeIngredient: 'Dinotefuran 20% SG',
        recommendedBrands: ['Token', 'Osheen'],
        dosagePerHectare: '150 g/ha',
        dosagePerAcre: '60 g/acre',
        applicationMode: 'Rapid trans-laminar third-generation neonicotinoid targeting nerve synapses',
        waterVolume: '500 Liters/ha',
        safetyIntervalDays: 14
      },
      {
        activeIngredient: 'Thiamethoxam 25% WG',
        recommendedBrands: ['Actara'],
        dosagePerHectare: '100 g/ha',
        dosagePerAcre: '40 g/acre',
        applicationMode: 'Foliar spray when ETL is exceeded',
        waterVolume: '450 Liters/ha',
        safetyIntervalDays: 21
      }
    ],
    biologicalRemedies: [
      {
        agentName: 'Chrysoperla carnea (Green Lacewing Larvae)',
        type: 'Beneficial Microbe',
        preparationMethod: 'Field release of 10,000 to 15,000 second-instar larvae per hectare at ETL.',
        applicationNotes: 'Voracious predator of jassid nymphs; each larva consumes up to 30 nymphs per day.'
      },
      {
        agentName: 'Beauveria bassiana 1.15% WP (2x10^8 CFU/g)',
        type: 'Bio-insecticide',
        preparationMethod: '2.5 kg/ha mixed with 500 L water + 0.1% surfactant.',
        applicationNotes: 'Spores germinate and penetrate jassid cuticle, producing white muscardine disease.'
      }
    ],
    preventionAndIPM: [
      'Select hair-dense (pilose) cotton varieties: dense trichomes on leaf undersides physically deter jassid stylet penetration and oviposition.',
      'Seed treatment with Imidacloprid 70% WS (5 g/kg seed) or Thiamethoxam 30% FS (7 ml/kg seed) protects seedlings up to 35-40 days.',
      'Intercrop cotton with cowpea, green gram, or black gram (1:2 ratio) to foster generalist beneficial predator populations.',
      'Rotate chemical classes (e.g. Flonicamid -> Dinotefuran) to prevent insecticide resistance build-up.'
    ],
    optimalSprayingWindow: 'Late afternoon when wind is calm; direct spray nozzle upwards towards leaf undersides.'
  },

  leaf_reddening: {
    id: 'leaf_reddening',
    commonName: 'Physiological Leaf Reddening (Anthocyanosis)',
    scientificName: 'Non-parasitic Nutritional & Cold Shock Disorder',
    casualAgent: 'Magnesium (Mg) deficiency, low nighttime temperature (< 15°C), moisture stress, or soil acidity',
    diseaseType: 'Physiological / Nutritional',
    severity: 'Moderate',
    severityScore: 58,
    economicThresholdLevel: '15% of middle and lower canopy leaves showing interveinal reddish-purple pigmentation during boll filling',
    botanicalDescription: 'A physiological breakdown of chlorophyll accompanied by rapid synthesis of anthocyanin pigments. Primarily triggered by heavy boll load demanding nitrogen and magnesium during cool fall nights or drought stress.',
    symptoms: {
      earlyStage: 'Interveinal yellowing transitioning quickly to bronze and light reddish hues on older lower leaves while main veins remain dark green.',
      advancedStage: 'Entire leaf blade between veins turns intense purple, crimson, or wine-red; leaves turn leathery, photosynthetically inactive, and drop prematurely.',
      foliarMarkers: [
        'Prominent interveinal crimson / wine-red discoloration',
        'Leaf veins retain distinct green color (classic "Christmas tree" pattern)',
        'Thickened, leathery leaf texture without water-soaking or fungus spores',
        'Occurs predominantly during heavy boll bursting stage'
      ],
      affectedParts: ['Lower to middle canopy leaves', 'Leaves adjacent to heavy boll loads']
    },
    immediateCulturalControl: [
      'Regulate irrigation intervals: avoid both prolonged dry soil spells and waterlogged conditions that impair Mg root uptake.',
      'Check root zone soil pH; if pH < 5.8, apply agricultural dolomitic limestone to restore exchangeable Magnesium.',
      'Maintain adequate soil moisture during October–November when night temperatures drop below 15°C.',
      'Avoid sudden nitrogen deprivation after peak flowering.'
    ],
    chemicalRemedies: [
      {
        activeIngredient: 'Magnesium Sulphate (MgSO4 - Epsom Salt) 9.6% Mg, 12% S',
        recommendedBrands: ['Agri-Mag', 'Kieserite / Pure Tech'],
        dosagePerHectare: '10.0 kg/ha foliar (or 25 kg/ha soil)',
        dosagePerAcre: '4.0 kg/acre foliar (10 kg/acre soil)',
        applicationMode: 'Foliar spray at 1.0% concentration (10 g/L water) at 75 and 90 days after sowing',
        waterVolume: '500 Liters/ha',
        safetyIntervalDays: 0
      },
      {
        activeIngredient: 'Potassium Nitrate (13:0:45) + Urea 1% foliar spray',
        recommendedBrands: ['Multi-K 13-0-45'],
        dosagePerHectare: '5.0 kg Potassium Nitrate + 5.0 kg Urea per ha',
        dosagePerAcre: '2.0 kg KNO3 + 2.0 kg Urea per acre',
        applicationMode: 'Canopy spray to quickly boost carbohydrate translocation to maturing bolls',
        waterVolume: '500 Liters/ha',
        safetyIntervalDays: 0
      }
    ],
    biologicalRemedies: [
      {
        agentName: 'Vesicular Arbuscular Mycorrhiza (VAM - Glomus intraradices)',
        type: 'Beneficial Microbe',
        preparationMethod: 'Inoculate root zone with 12.5 kg/ha at sowing or early squaring.',
        applicationNotes: 'Extends fungal hyphae network up to 100x beyond root surface, dramatically boosting soil Mg and P uptake.'
      },
      {
        agentName: 'Fermented Jeevamrit / Panchagavya 3% Foliar Wash',
        type: 'Nutritional Foliar',
        preparationMethod: '15 Liters in 500 L water per hectare applied every 15 days.',
        applicationNotes: 'Supplies micronutrients and beneficial rhizobacteria that stabilize foliar chlorophyll.'
      }
    ],
    preventionAndIPM: [
      'Basal soil application of Magnesium Sulphate @ 25 kg/ha along with recommended NPK dose at time of land preparation.',
      'Select Bt cotton hybrids with verified low susceptibility to anthocyanosis.',
      'Plan planting schedules so that heavy boll maturation precedes severe nocturnal cold snaps.',
      'Conduct pre-season soil test to balance K:Mg ratio (ideal ratio 3:1 to 5:1; excessive K hinders Mg absorption).'
    ],
    optimalSprayingWindow: 'Mid-morning on bright sunny days to accelerate foliar absorption of Magnesium ions.'
  },

  variegation: {
    id: 'variegation',
    commonName: 'Leaf Variegation (Genetic Plastid Chimera)',
    scientificName: 'Physiological Chlorophyll Mutation / Sectorial Chimera',
    casualAgent: 'Spontaneous somatic plastid gene mutation or nuclear-plastid incompatibility',
    diseaseType: 'Genetic / Chimeric',
    severity: 'Low',
    severityScore: 22,
    economicThresholdLevel: 'Non-contagious; does not require chemical intervention. Monitor if > 2% of stand displays phenotype.',
    botanicalDescription: 'A harmless genetic or physiological phenomenon in which somatic mutations in plastid DNA (ptDNA) or nuclear alleles prevent normal thylakoid chlorophyll synthesis in specific cell lineages, producing striking white, cream, or pale yellow sectors with sharp borders.',
    symptoms: {
      earlyStage: 'Clear, sharply demarcated creamy white or bright yellow patches appearing on one half or sector of the leaf blade.',
      advancedStage: 'Patches remain static with crisp borders alongside normal healthy green leaf tissue; no tissue necrosis, rot, or wilting occurs.',
      foliarMarkers: [
        'Crisp geometric or sectorial white/yellow chlorophyll-free patches',
        'Normal leaf turgor and healthy tissue texture (no rotting or lesions)',
        'Veins within yellow sectors remain clear and unthickened',
        'Localized to isolated branches or individual leaves'
      ],
      affectedParts: ['Individual leaf blades', 'Occasional side vegetative branch']
    },
    immediateCulturalControl: [
      'Confirm diagnosis to reassure field scouts that variegation is NON-INFECTIOUS and cannot spread to neighboring plants.',
      'Do NOT spray fungicides, bactericides, or synthetic pesticides—such applications cause unnecessary expense and chemical runoff.',
      'Mark affected plants for observation if maintaining pure pedigree seed plots to avoid harvesting seed for breeder stock.',
      'Ensure standard fertilization schedule continues without interruption.'
    ],
    chemicalRemedies: [
      {
        activeIngredient: 'No Chemical Application Required (Abiotic Non-Pathogenic Condition)',
        recommendedBrands: ['N/A - Non-parasitic condition'],
        dosagePerHectare: '0 kg/ha',
        dosagePerAcre: '0 kg/acre',
        applicationMode: 'Chemical sprays strictly contraindicated; treat purely as a diagnostic benchmark',
        waterVolume: '0 L',
        safetyIntervalDays: 0
      }
    ],
    biologicalRemedies: [
      {
        agentName: 'Standard Balanced Foliar Micronutrient Spray (Zn, Fe, Mn)',
        type: 'Nutritional Foliar',
        preparationMethod: 'Chelated Micronutrient mix (Fe-EDTA 0.5 g/L) if suspecting transient iron chlorosis.',
        applicationNotes: 'Helps rule out transient micronutrient deficiencies; true genetic variegation will persist with clean margins.'
      }
    ],
    preventionAndIPM: [
      'Procure certified foundation seed from verified seed corporations with rigorous roguing standards.',
      'Educate field scouting personnel to differentiate genetic variegation from viral mosaic or spider mite damage.',
      'Record GPS coordinates of chimeric plants for scientific genetic study or breeding observation.'
    ],
    optimalSprayingWindow: 'No treatment required.'
  },

  healthy_leaf: {
    id: 'healthy_leaf',
    commonName: 'Healthy Cotton Leaf (Optimal Canopy)',
    scientificName: 'Gossypium hirsutum L. (Malvaceae)',
    casualAgent: 'None (Optimum physiological and photosynthetic equilibrium)',
    diseaseType: 'Healthy Canopy',
    severity: 'Healthy',
    severityScore: 0,
    economicThresholdLevel: 'Canopy is healthy and thriving. Maintain standard preventive scouting.',
    botanicalDescription: 'Pristine cotton leaf displaying robust vegetative development, deep uniform chlorophyll pigmentation, smooth 3-to-5 lobed palmate geometry, crisp prominent veins, and high photosynthetic efficiency.',
    symptoms: {
      earlyStage: 'Uniform vibrant green coloration across whole leaf blade.',
      advancedStage: 'Fully expanded, turgid palmate leaf with pristine cuticle and intact margins.',
      foliarMarkers: [
        'Deep vibrant emerald green coloration',
        'Uniform palmate venation without thickening or discoloration',
        'Clean, unspotted blade without water-soaked or necrotic spots',
        'Intact leaf margin and optimal leaf turgor'
      ],
      affectedParts: ['All plant organs functioning at peak physiological health']
    },
    immediateCulturalControl: [
      'Maintain scheduled irrigation based on soil moisture tensiometer readings (keep soil tension between -30 and -50 kPa).',
      'Continue regular twice-weekly scouting for early detection of chewing caterpillars (bollworms) and sucking pests.',
      'Perform light inter-cultivation to keep furrows weed-free and aerate upper root rhizosphere.',
      'Ensure optimum canopy light interception by managing planting density.'
    ],
    chemicalRemedies: [
      {
        activeIngredient: 'Preventive Nutrition: Soluble Boron (20% Borax) + Zinc Sulfate (33% Zn)',
        recommendedBrands: ['Solubor', 'Chelamin'],
        dosagePerHectare: '1.0 kg Boron + 1.25 kg Zinc Sulfate per ha',
        dosagePerAcre: '400 g Boron + 500 g Zinc Sulfate per acre',
        applicationMode: 'Maintenance foliar spray at square initiation and peak boll formation',
        waterVolume: '450 Liters/ha',
        safetyIntervalDays: 0
      }
    ],
    biologicalRemedies: [
      {
        agentName: 'Trichoderma viride / harzianum (Bio-stimulant root protectant)',
        type: 'Beneficial Microbe',
        preparationMethod: '2.5 kg/ha applied with 250 kg well-decomposed FYM at root zone.',
        applicationNotes: 'Maintains root health and suppresses soil-borne fungal complexes.'
      }
    ],
    preventionAndIPM: [
      'Follow integrated plant nutrition system (IPNS) supplying balanced N:P:K:S:Zn:B.',
      'Maintain pheromone traps (5 traps/ha) for monitoring pink bollworm (Pectinophora gossypiella) and Helicoverpa.',
      'Preserve habitat for natural insect biocontrol agents along farm fence lines.'
    ],
    optimalSprayingWindow: 'Standard preventive foliar nutrition during calm early mornings.'
  }
};
