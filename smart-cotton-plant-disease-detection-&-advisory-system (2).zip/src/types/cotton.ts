export type ConditionClassId =
  | 'bacterial_blight'
  | 'curl_virus'
  | 'herbicide_growth_damage'
  | 'leaf_hopper_jassids'
  | 'leaf_reddening'
  | 'variegation'
  | 'healthy_leaf';

export type SeverityLevel = 'Critical' | 'High' | 'Moderate' | 'Low' | 'Healthy';

export interface ChemicalRemedy {
  activeIngredient: string;
  recommendedBrands: string[];
  dosagePerHectare: string;
  dosagePerAcre: string;
  applicationMode: string;
  waterVolume: string;
  safetyIntervalDays: number;
}

export interface BiologicalRemedy {
  agentName: string;
  type: 'Bio-fungicide' | 'Bio-insecticide' | 'Botanical Extract' | 'Beneficial Microbe' | 'Nutritional Foliar';
  preparationMethod: string;
  applicationNotes: string;
}

export interface AdvisoryDetails {
  id: ConditionClassId;
  commonName: string;
  scientificName: string;
  casualAgent: string;
  diseaseType: 'Bacterial' | 'Viral' | 'Pest Infestation' | 'Abiotic / Chemical' | 'Physiological / Nutritional' | 'Genetic / Chimeric' | 'Healthy Canopy';
  severity: SeverityLevel;
  severityScore: number; // 0 to 100
  economicThresholdLevel: string; // ETL
  symptoms: {
    earlyStage: string;
    advancedStage: string;
    foliarMarkers: string[];
    affectedParts: string[];
  };
  immediateCulturalControl: string[];
  chemicalRemedies: ChemicalRemedy[];
  biologicalRemedies: BiologicalRemedy[];
  preventionAndIPM: string[];
  optimalSprayingWindow: string;
  botanicalDescription: string;
}

export interface LeafTemplateItem {
  id: string;
  classId: ConditionClassId;
  label: string;
  scientificName: string;
  severity: SeverityLevel;
  description: string;
  accentColor: string;
  features: string[];
  sampleType: 'Standard Botanical Type' | 'Field Variant A' | 'Field Variant B';
  realEnvironmentPhotoUrl?: string;
  fieldEnvironment?: string;
  samplingGps?: string;
  foliarChlorophyllIndex?: number; // 0-100
  canopySunlightLux?: number;
}

export interface PipelineStep {
  name: string;
  description: string;
  technicalDetails: string;
  canvasRenderType: 'raw' | 'grayscale' | 'lab_chlorophyll' | 'bilateral' | 'contour_mask' | 'clahe' | 'tensor_224';
}

export interface PredictionResult {
  classId: ConditionClassId;
  className: string;
  confidence: number; // 0 to 1
  entropy: number;
  allProbabilities: {
    classId: ConditionClassId;
    className: string;
    probability: number;
  }[];
  inferenceTimeMs: number;
  imageDimensions: { width: number; height: number };
  tensorShape: [1, 224, 224, 3];
}

export interface ConfusionMatrixCell {
  trueClass: ConditionClassId;
  predictedClass: ConditionClassId;
  count: number;
  percentage: number;
}

export interface ClassMetric {
  classId: ConditionClassId;
  className: string;
  precision: number;
  recall: number;
  f1Score: number;
  support: number;
  rocAuc: number;
}

export interface TrainingEpoch {
  epoch: number;
  stage: 1 | 2;
  trainLoss: number;
  valLoss: number;
  trainAcc: number;
  valAcc: number;
  learningRate: number;
}
