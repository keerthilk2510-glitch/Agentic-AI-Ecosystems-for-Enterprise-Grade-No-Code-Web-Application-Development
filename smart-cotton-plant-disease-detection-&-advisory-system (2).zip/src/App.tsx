/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Header } from './components/Header';
import { InferenceConsole } from './components/InferenceConsole';
import { LeafTemplateGallery } from './components/LeafTemplateGallery';
import { ModelDiagnostics } from './components/ModelDiagnostics';
import { DatasetExplorer } from './components/DatasetExplorer';
import { PythonScriptViewer } from './components/PythonScriptViewer';
import { AdvisoryPanel } from './components/AdvisoryPanel';
import { AgronomicReportModal } from './components/AgronomicReportModal';
import { ExtendedLeafTemplate, LEAF_TEMPLATES } from './data/leafTemplates';
import { ConditionClassId, PredictionResult } from './types/cotton';

export default function App() {
  const [activeTab, setActiveTab] = useState<'console' | 'templates' | 'diagnostics' | 'dataset' | 'python_code'>('console');
  const [selectedTemplate, setSelectedTemplate] = useState<ExtendedLeafTemplate>(LEAF_TEMPLATES[0]);
  const [currentPrediction, setCurrentPrediction] = useState<PredictionResult | null>(null);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);

  // Active condition class (driven by current prediction or selected template)
  const activeClassId: ConditionClassId = currentPrediction?.classId || selectedTemplate.classId || 'bacterial_blight';

  const handleSelectTemplate = (template: ExtendedLeafTemplate) => {
    setSelectedTemplate(template);
    setActiveTab('console');
  };

  return (
    <div className="min-h-screen bg-linear-to-b from-white via-emerald-50/20 to-slate-50 text-slate-900 flex flex-col antialiased">
      {/* Top Bar (Zone Contract: Wordmark, 5 nav links, Export CTA) */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenReportModal={() => setIsReportModalOpen(true)}
      />

      {/* System Telemetry & Mission Ribbon (Bright Daylight Precision Ag Aesthetic) */}
      <div className="border-b border-emerald-100 bg-white shadow-2xs">
        <div className="mx-auto max-w-7xl px-4 py-3 sm:px-6 lg:px-8 flex flex-wrap items-center justify-between gap-y-2 text-xs text-slate-700">
          <div className="flex flex-wrap items-center gap-3">
            <span className="font-bold text-emerald-950">CROP:</span>
            <span className="text-emerald-800 font-mono font-semibold">Gossypium hirsutum (Cotton)</span>
            <span aria-hidden="true" className="text-slate-200">|</span>
            <span className="font-bold text-emerald-950">DATASET:</span>
            <span className="font-mono text-slate-700">SAR-CLD-2024 (7,000 augmented field leaves)</span>
            <span aria-hidden="true" className="text-slate-200">|</span>
            <span className="inline-flex items-center gap-1.5 font-medium text-emerald-900 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200 text-[11px]">
              ☀️ Scouting Sun: 88,200 Lux
            </span>
          </div>

          <div className="flex items-center gap-4 font-mono text-[11px]">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500">BACKBONE:</span>
              <span className="text-slate-900 font-bold">MobileNetV2 (α=1.0)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500">MACRO F1:</span>
              <span className="text-emerald-700 font-bold tabular-nums">97.4%</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500">FIELD TEST ACC:</span>
              <span className="text-teal-700 font-bold tabular-nums">97.4%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Viewport Stage */}
      <main className="mx-auto max-w-7xl flex-1 w-full px-4 py-8 sm:px-6 lg:px-8 space-y-8">
        {/* Tab 1: Inference & Diagnostic Advisory Console */}
        {activeTab === 'console' && (
          <div className="space-y-8">
            <InferenceConsole
              selectedTemplate={selectedTemplate}
              onSelectTemplate={setSelectedTemplate}
              onPredictionChange={setCurrentPrediction}
            />

            <AdvisoryPanel
              currentClassId={activeClassId}
              onOpenReportModal={() => setIsReportModalOpen(true)}
            />
          </div>
        )}

        {/* Tab 2: Curated Botanical Leaf Templates */}
        {activeTab === 'templates' && (
          <LeafTemplateGallery
            selectedTemplateId={selectedTemplate.id}
            onSelectTemplate={handleSelectTemplate}
          />
        )}

        {/* Tab 3: Model Diagnostics & Evaluation */}
        {activeTab === 'diagnostics' && <ModelDiagnostics />}

        {/* Tab 4: SAR-CLD-2024 Dataset Corpus */}
        {activeTab === 'dataset' && (
          <DatasetExplorer onSelectTemplate={handleSelectTemplate} />
        )}

        {/* Tab 5: Python Model Scripts */}
        {activeTab === 'python_code' && <PythonScriptViewer />}
      </main>

      {/* Footer (Bright Clean Design) */}
      <footer className="border-t border-slate-200 bg-white py-6 text-xs text-slate-500">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">AI Smart Cotton Plant Detection and Advisory System</span>
            <span>·</span>
            <span>MobileNetV2 Deep Transfer Learning on SAR-CLD-2024</span>
          </div>
          <div className="text-slate-500">
            Precision agriculture, real-environment field diagnostics & agronomic advisory.
          </div>
        </div>
      </footer>

      {/* Printable Report Modal */}
      {isReportModalOpen && (
        <AgronomicReportModal
          currentClassId={activeClassId}
          prediction={currentPrediction}
          onClose={() => setIsReportModalOpen(false)}
        />
      )}
    </div>
  );
}
