import React, { useState } from 'react';

const PYTHON_SCRIPTS = {
  training: {
    filename: 'train_mobilenetv2_sar_cld.py',
    description: 'TensorFlow / Keras MobileNetV2 Stage 1 (Transfer Learning) and Stage 2 (Fine-Tuning)',
    code: `"""
AI Smart Cotton Plant Detection and Advisory System - SAR-CLD-2024
Architecture: MobileNetV2 (pretrained ImageNet, alpha=1.0)
Dual-Stage Transfer Learning and Fine-Tuning Pipeline
"""

import tensorflow as tf
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras import layers, models, optimizers, callbacks
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import numpy as np

# 1. Configuration & Hyperparameters
IMG_SIZE = (224, 224)
BATCH_SIZE = 32
NUM_CLASSES = 7
STAGE1_EPOCHS = 18
STAGE2_EPOCHS = 15

# 2. Data Generators with Augmentation for SAR-CLD-2024
train_datagen = ImageDataGenerator(
    preprocessing_function=preprocess_input, # Normalizes to [-1.0, 1.0]
    rotation_range=30,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.15,
    zoom_range=0.2,
    horizontal_flip=True,
    vertical_flip=True,
    fill_mode='nearest'
)

val_test_datagen = ImageDataGenerator(
    preprocessing_function=preprocess_input
)

train_generator = train_datagen.flow_from_directory(
    'sar_cld_2024/train',
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode='categorical'
)

val_generator = val_test_datagen.flow_from_directory(
    'sar_cld_2024/val',
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode='categorical'
)

# 3. Model Architecture Construction
base_model = MobileNetV2(
    input_shape=(224, 224, 3),
    include_top=False,
    weights='imagenet',
    alpha=1.0
)

# Initially freeze all base model layers
base_model.trainable = False

# Top Head
x = base_model.output
x = layers.GlobalAveragePooling2D(name='global_avg_pool')(x)
x = layers.BatchNormalization(name='top_bn')(x)
x = layers.Dropout(0.3, name='top_dropout')(x)
x = layers.Dense(128, activation='relu', name='top_dense_128')(x)
predictions = layers.Dense(NUM_CLASSES, activation='softmax', name='top_softmax')(x)

model = models.Model(inputs=base_model.input, outputs=predictions, name='MobileNetV2_SAR_CLD')
model.summary()

# 4. Stage 1: Transfer Learning (Train Top Head Only)
model.compile(
    optimizer=optimizers.Adam(learning_rate=1e-3),
    loss='categorical_crossentropy',
    metrics=['accuracy', tf.keras.metrics.Precision(name='precision'), tf.keras.metrics.Recall(name='recall')]
)

print("\\n[STAGE 1] Training top classification head with Adam(lr=1e-3)...")
history_stage1 = model.fit(
    train_generator,
    epochs=STAGE1_EPOCHS,
    validation_data=val_generator
)

# 5. Stage 2: Fine-Tuning (Unfreeze Top 36 Base Layers)
base_model.trainable = True
fine_tune_at = len(base_model.layers) - 36

# Freeze all layers before fine_tune_at
for layer in base_model.layers[:fine_tune_at]:
    layer.trainable = False

print(f"\\n[STAGE 2] Unfroze top {36} layers (from layer {fine_tune_at} to {len(base_model.layers)})")

model.compile(
    optimizer=optimizers.Adam(learning_rate=1e-5),
    loss='categorical_crossentropy',
    metrics=['accuracy', tf.keras.metrics.Precision(name='precision'), tf.keras.metrics.Recall(name='recall')]
)

stage2_callbacks = [
    callbacks.EarlyStopping(
        monitor='val_loss',
        patience=4,
        restore_best_weights=True,
        verbose=1
    ),
    callbacks.ReduceLROnPlateau(
        monitor='val_loss',
        factor=0.2,
        patience=2,
        min_lr=1e-7,
        verbose=1
    ),
    callbacks.ModelCheckpoint(
        filepath='best_mobilenetv2_sar_cld.keras',
        monitor='val_accuracy',
        save_best_only=True
    )
]

print("\\n[STAGE 2] Commencing Fine-Tuning with Adam(lr=1e-5)...")
history_stage2 = model.fit(
    train_generator,
    epochs=STAGE2_EPOCHS,
    validation_data=val_generator,
    callbacks=stage2_callbacks
)

# Export production model
model.save('final_cotton_disease_mobilenetv2.keras')
print("Model successfully trained and saved!")
`
  },

  evaluation: {
    filename: 'evaluate_scikit_learn.py',
    description: 'Scikit-Learn Macro Precision, Recall, F1-Score & Matplotlib Confusion Matrix',
    code: `"""
Evaluation Script: Macro Metrics & Multiclass Confusion Matrix
Evaluated on SAR-CLD-2024 Test Split (1,050 samples)
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report, confusion_matrix, precision_recall_fscore_support
import tensorflow as tf

CLASS_NAMES = [
    'Bacterial Blight',
    'Curl Virus',
    'Herbicide Growth Damage',
    'Leaf Hopper / Jassids',
    'Leaf Reddening',
    'Variegation',
    'Healthy Leaf'
]

# Load saved model & test generator
model = tf.keras.models.load_model('final_cotton_disease_mobilenetv2.keras')
test_generator = test_datagen.flow_from_directory(
    'sar_cld_2024/test',
    target_size=(224, 224),
    batch_size=32,
    class_mode='categorical',
    shuffle=False
)

# Predict logits and compute argmax
y_pred_probs = model.predict(test_generator)
y_pred = np.argmax(y_pred_probs, axis=1)
y_true = test_generator.classes

# 1. Scikit-Learn Classification Report
report = classification_report(y_true, y_pred, target_names=CLASS_NAMES, digits=4)
print("=== SCIKIT-LEARN CLASSIFICATION REPORT ===")
print(report)

# Compute explicit Macro Metrics
p_macro, r_macro, f1_macro, _ = precision_recall_fscore_support(y_true, y_pred, average='macro')
print(f"Macro Precision : {p_macro * 100:.2f}%")
print(f"Macro Recall    : {r_macro * 100:.2f}%")
print(f"Macro F1-Score  : {f1_macro * 100:.2f}%")

# 2. Normalized Confusion Matrix Visualization via Matplotlib
cm = confusion_matrix(y_true, y_pred)
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

plt.figure(figsize=(9, 8))
plt.imshow(cm_normalized, interpolation='nearest', cmap=plt.cm.Greens)
plt.title('Normalized Multiclass Confusion Matrix (SAR-CLD-2024)', fontsize=14, pad=15)
plt.colorbar(fraction=0.046, pad=0.04)

tick_marks = np.arange(len(CLASS_NAMES))
plt.xticks(tick_marks, CLASS_NAMES, rotation=45, ha='right', fontsize=10)
plt.yticks(tick_marks, CLASS_NAMES, fontsize=10)

thresh = cm_normalized.max() / 2.
for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):
        plt.text(j, i, f"{cm_normalized[i, j]*100:.1f}%\\n({cm[i, j]})",
                 horizontalalignment="center",
                 color="white" if cm_normalized[i, j] > thresh else "black",
                 fontsize=9)

plt.ylabel('True Class', fontsize=12)
plt.xlabel('Predicted Class', fontsize=12)
plt.tight_layout()
plt.savefig('confusion_matrix_sar_cld_2024.png', dpi=300)
plt.show()
`
  },

  gradio_streamlit: {
    filename: 'app_streamlit.py',
    description: 'Streamlit & OpenCV Interactive Agricultural Field Advisory Deployment',
    code: `"""
Smart Cotton Plant Disease Detection & Advisory Web Console
Streamlit + OpenCV + MobileNetV2
"""

import streamlit as st
import cv2
import numpy as np
import tensorflow as tf
import json

st.set_page_config(
    page_title="Smart Cotton Disease Detection & Advisory",
    page_icon="🌱",
    layout="wide"
)

# Load Knowledge Base & Model
@st.cache_resource
def load_system():
    model = tf.keras.models.load_model('final_cotton_disease_mobilenetv2.keras')
    with open('advisory_knowledge_base.json', 'r') as f:
        kb = json.load(f)
    return model, kb

model, KB = load_system()
CLASS_LABELS = list(KB.keys())

st.title("🌱 Smart Cotton Plant Disease Detection & Advisory System")
st.markdown("Precision agriculture diagnostics powered by **MobileNetV2** and **SAR-CLD-2024**.")

uploaded_file = st.file_uploader("Upload Cotton Leaf Image", type=['jpg', 'jpeg', 'png'])

if uploaded_file is not None:
    # 1. OpenCV Preprocessing Pipeline
    file_bytes = np.asarray(bytearray(uploaded_file.read()), dtype=np.uint8)
    img_bgr = cv2.imdecode(file_bytes, 1)
    img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    
    col1, col2 = st.columns([1, 1])
    with col1:
        st.image(img_rgb, caption="Raw Scouting Leaf Image", use_column_width=True)
        
    # Preprocessing to 224x224 and [-1, 1]
    img_resized = cv2.resize(img_rgb, (224, 224))
    img_preprocessed = tf.keras.applications.mobilenet_v2.preprocess_input(img_resized.astype(np.float32))
    input_tensor = np.expand_dims(img_preprocessed, axis=0)
    
    # 2. Batch Inference
    predictions = model.predict(input_tensor)[0]
    top_idx = int(np.argmax(predictions))
    top_class = CLASS_LABELS[top_idx]
    confidence = float(predictions[top_idx])
    
    advisory = KB[top_class]
    
    with col2:
        st.subheader("Diagnostic Finding:")
        st.metric(label="Predicted Condition", value=advisory['commonName'], delta=f"{confidence*100:.1f}% Confidence")
        st.write(f"**Scientific Name:** *{advisory['scientificName']}*")
        st.write(f"**Severity Level:** {advisory['severity']}")
        st.progress(confidence)

    st.divider()
    st.subheader("Actionable Agronomic Advisory:")
    tab1, tab2, tab3, tab4 = st.tabs(["Immediate Cultural Control", "Chemical Remedies", "Biological Biocontrol", "IPM Prevention"])
    
    with tab1:
        for item in advisory['immediateCulturalControl']:
            st.write(f"- {item}")
    with tab2:
        for rem in advisory['chemicalRemedies']:
            st.info(f"**{rem['activeIngredient']}**\\nDosage: {rem['dosagePerHectare']} ({rem['dosagePerAcre']})\\nMode: {rem['applicationMode']}")
    with tab3:
        for bio in advisory['biologicalRemedies']:
            st.success(f"**{bio['agentName']}** ({bio['type']}): {bio['preparationMethod']}")
    with tab4:
        for ipm in advisory['preventionAndIPM']:
            st.write(f"- {ipm}")
`
  }
};

export const PythonScriptViewer: React.FC = () => {
  const [activeScript, setActiveScript] = useState<'training' | 'evaluation' | 'gradio_streamlit'>('training');
  const [copied, setCopied] = useState(false);

  const script = PYTHON_SCRIPTS[activeScript];

  const handleCopy = () => {
    navigator.clipboard.writeText(script.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-slate-100 pb-4 gap-3">
        <div>
          <span className="text-xs font-mono uppercase tracking-wider text-emerald-700 font-bold">
            Precision Ag Codebase
          </span>
          <h2 className="text-lg font-bold text-slate-900 mt-0.5">
            Production Model & Deployment Scripts
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Full TensorFlow, scikit-learn, and Streamlit scripts implementing the SAR-CLD-2024 specifications.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="rounded-lg bg-emerald-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 transition-all cursor-pointer flex items-center gap-1.5 shadow-xs"
          >
            {copied ? (
              <>
                <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="20 6 9 17 4 12" />
                </svg>
                <span>Copied Code</span>
              </>
            ) : (
              <>
                <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                </svg>
                <span>Copy Script</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Script Selector Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-1">
        <button
          onClick={() => setActiveScript('training')}
          className={`px-3 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeScript === 'training'
              ? 'border-emerald-600 text-emerald-800 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          train_mobilenetv2_sar_cld.py
        </button>
        <button
          onClick={() => setActiveScript('evaluation')}
          className={`px-3 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeScript === 'evaluation'
              ? 'border-emerald-600 text-emerald-800 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          evaluate_scikit_learn.py
        </button>
        <button
          onClick={() => setActiveScript('gradio_streamlit')}
          className={`px-3 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeScript === 'gradio_streamlit'
              ? 'border-emerald-600 text-emerald-800 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          app_streamlit.py
        </button>
      </div>

      <div className="text-xs text-slate-600 font-mono">
        {script.description}
      </div>

      {/* Code Block Container */}
      <div className="relative rounded-xl border border-slate-800 bg-slate-950 p-4 font-mono text-xs text-slate-200 overflow-x-auto max-h-[520px] scrollbar-thin">
        <pre className="whitespace-pre">
          <code>{script.code}</code>
        </pre>
      </div>
    </div>
  );
};
