import React, { useState } from 'react';
import { ExtendedLeafTemplate, LEAF_TEMPLATES } from '../data/leafTemplates';

interface LeafTemplateGalleryProps {
  onSelectTemplate: (template: ExtendedLeafTemplate) => void;
  selectedTemplateId?: string;
}

export const LeafTemplateGallery: React.FC<LeafTemplateGalleryProps> = ({
  onSelectTemplate,
  selectedTemplateId
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [inspectModalTemplate, setInspectModalTemplate] = useState<ExtendedLeafTemplate | null>(null);

  const filteredTemplates = LEAF_TEMPLATES.filter(tpl => {
    if (filterCategory === 'all') return true;
    if (filterCategory === 'bacterial') return tpl.classId === 'bacterial_blight';
    if (filterCategory === 'viral') return tpl.classId === 'curl_virus';
    if (filterCategory === 'pest') return tpl.classId === 'leaf_hopper_jassids';
    if (filterCategory === 'abiotic') return tpl.classId === 'herbicide_growth_damage';
    if (filterCategory === 'nutritional') return tpl.classId === 'leaf_reddening';
    if (filterCategory === 'healthy') return tpl.classId === 'healthy_leaf';
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header text & category filter buttons (Bright Clean Theme) */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900">
              Real In-Field Environment Cotton Leaf Specimen Gallery
            </h2>
            <span className="inline-flex items-center rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-semibold text-emerald-800">
              SAR-CLD-2024
            </span>
          </div>
          <p className="mt-1 text-sm text-slate-600">
            Authentic ground-truth field specimens of <em>Gossypium hirsutum</em> photographed under natural farm sunlight, soil, and crop canopy.
          </p>
        </div>

        {/* Filter controls */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200">
          <button
            onClick={() => setFilterCategory('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
              filterCategory === 'all'
                ? 'bg-white text-emerald-950 shadow-2xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Real Leaves (14)
          </button>
          <button
            onClick={() => setFilterCategory('bacterial')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
              filterCategory === 'bacterial'
                ? 'bg-white text-emerald-950 shadow-2xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Bacterial Blight
          </button>
          <button
            onClick={() => setFilterCategory('viral')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
              filterCategory === 'viral'
                ? 'bg-white text-emerald-950 shadow-2xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Curl Virus
          </button>
          <button
            onClick={() => setFilterCategory('pest')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
              filterCategory === 'pest'
                ? 'bg-white text-emerald-950 shadow-2xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Jassids
          </button>
          <button
            onClick={() => setFilterCategory('abiotic')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
              filterCategory === 'abiotic'
                ? 'bg-white text-emerald-950 shadow-2xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Herbicide Damage
          </button>
          <button
            onClick={() => setFilterCategory('nutritional')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
              filterCategory === 'nutritional'
                ? 'bg-white text-emerald-950 shadow-2xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Reddening
          </button>
          <button
            onClick={() => setFilterCategory('healthy')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
              filterCategory === 'healthy'
                ? 'bg-white text-emerald-950 shadow-2xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Healthy
          </button>
        </div>
      </div>

      {/* Grid of templates */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filteredTemplates.map(template => (
          <TemplateCard
            key={template.id}
            template={template}
            isSelected={selectedTemplateId === template.id}
            onSelect={() => onSelectTemplate(template)}
            onInspect={() => setInspectModalTemplate(template)}
          />
        ))}
      </div>

      {/* Inspect Specimen Modal */}
      {inspectModalTemplate && (
        <SpecimenDetailModal
          template={inspectModalTemplate}
          onClose={() => setInspectModalTemplate(null)}
          onLoadIntoConsole={() => {
            onSelectTemplate(inspectModalTemplate);
            setInspectModalTemplate(null);
          }}
        />
      )}
    </div>
  );
};

interface TemplateCardProps {
  template: ExtendedLeafTemplate;
  isSelected: boolean;
  onSelect: () => void;
  onInspect: () => void;
}

const TemplateCard: React.FC<TemplateCardProps> = ({
  template,
  isSelected,
  onSelect,
  onInspect
}) => {
  const severityTone =
    template.severity === 'Critical'
      ? 'text-rose-700 bg-rose-50 border-rose-200'
      : template.severity === 'High'
      ? 'text-amber-800 bg-amber-50 border-amber-200'
      : template.severity === 'Moderate'
      ? 'text-orange-800 bg-orange-50 border-orange-200'
      : template.severity === 'Low'
      ? 'text-yellow-800 bg-yellow-50 border-yellow-200'
      : 'text-emerald-800 bg-emerald-50 border-emerald-200';

  return (
    <div
      className={`group relative flex flex-col justify-between overflow-hidden rounded-2xl border bg-white transition-all shadow-xs ${
        isSelected
          ? 'border-emerald-500 shadow-md ring-2 ring-emerald-500/20'
          : 'border-slate-200 hover:border-emerald-300 hover:shadow-sm'
      }`}
    >
      {/* Real Specimen Visual Area */}
      <div className="relative aspect-square w-full overflow-hidden bg-slate-50 flex items-center justify-center p-3 border-b border-slate-100">
        <img
          src={template.svgDataUri}
          alt={template.label}
          className="h-full w-full object-contain transition-transform duration-300 group-hover:scale-105 rounded-xl"
        />

        {/* Top specimen metadata overlay */}
        <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between text-xs">
          <span className="font-mono text-[11px] bg-white/95 font-semibold px-2 py-0.5 rounded-md border border-slate-200 text-slate-800 shadow-2xs">
            {template.fieldCode}
          </span>
          <span className={`font-semibold ${severityTone} px-2 py-0.5 rounded-md border shadow-2xs text-[11px]`}>
            {template.severity}
          </span>
        </div>

        {/* Hover quick inspect affordance */}
        <button
          onClick={e => {
            e.stopPropagation();
            onInspect();
          }}
          className="absolute bottom-2.5 right-2.5 rounded-xl bg-white/95 border border-slate-300 p-2 text-slate-700 opacity-0 group-hover:opacity-100 transition-opacity hover:text-emerald-700 shadow-xs cursor-pointer"
          title="Inspect Real Leaf Specimen"
        >
          <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
            <line x1="11" y1="8" x2="11" y2="14" />
            <line x1="8" y1="11" x2="14" y2="11" />
          </svg>
        </button>

        {/* Real Environment Tag */}
        <div className="absolute bottom-2.5 left-2.5 bg-white/90 backdrop-blur-xs px-2 py-0.5 rounded text-[10px] font-mono text-emerald-900 border border-slate-200">
          ☀️ {template.canopySunlightLux?.toLocaleString() || '85,000'} Lux
        </div>
      </div>

      {/* Card Body */}
      <div className="p-4 flex flex-col flex-1 justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
            <span>{template.sampleType}</span>
            <span aria-hidden="true">·</span>
            <span className="truncate">{template.canopyPosition}</span>
          </div>
          <h3 className="mt-1 font-bold text-slate-900 text-sm line-clamp-1">
            {template.label}
          </h3>
          <p className="text-xs italic text-emerald-700 font-serif mt-0.5 line-clamp-1">
            {template.scientificName}
          </p>

          <p className="mt-2 text-xs text-slate-600 line-clamp-2 leading-relaxed">
            {template.description}
          </p>
        </div>

        {/* Feature bullets */}
        <div className="pt-2 border-t border-slate-100">
          <div className="text-[11px] text-slate-600 space-y-1 mb-3">
            {template.features.slice(0, 2).map((feat, idx) => (
              <div key={idx} className="flex items-start gap-1.5 line-clamp-1">
                <span className="text-emerald-600 font-bold">›</span>
                <span className="truncate">{feat}</span>
              </div>
            ))}
          </div>

          {/* Action button */}
          <button
            onClick={onSelect}
            className={`w-full rounded-xl px-3 py-2 text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs ${
              isSelected
                ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                : 'bg-emerald-50 text-emerald-900 hover:bg-emerald-100 border border-emerald-200'
            }`}
          >
            <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polygon points="5 3 19 12 5 21 5 3" />
            </svg>
            {isSelected ? 'Loaded In Detection Console' : 'Test In Real Detection Console'}
          </button>
        </div>
      </div>
    </div>
  );
};

interface SpecimenDetailModalProps {
  template: ExtendedLeafTemplate;
  onClose: () => void;
  onLoadIntoConsole: () => void;
}

const SpecimenDetailModal: React.FC<SpecimenDetailModalProps> = ({
  template,
  onClose,
  onLoadIntoConsole
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-lg text-slate-900">{template.label}</h3>
              <span className="bg-emerald-100 text-emerald-800 text-xs px-2 py-0.5 rounded-full font-semibold">
                Real Field Specimen
              </span>
            </div>
            <p className="text-xs text-emerald-700 font-serif italic mt-0.5">{template.scientificName}</p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 cursor-pointer"
          >
            <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
          <div className="flex flex-col gap-2">
            <div className="relative flex aspect-square items-center justify-center rounded-xl bg-slate-50 border border-slate-200 p-2">
              <img
                src={template.svgDataUri}
                alt={template.label}
                className="h-full w-full object-contain rounded-lg"
              />
            </div>
            <div className="flex items-center justify-between text-xs text-slate-500 font-mono px-1">
              <span>{template.fieldCode}</span>
              <span>{template.samplingDate}</span>
            </div>
          </div>

          <div className="flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div>
                <span className="text-[11px] font-mono uppercase tracking-wider text-slate-500 block">
                  Field Environment & Location
                </span>
                <p className="text-xs font-semibold text-slate-900 mt-0.5">{template.plotLocation}</p>
                <p className="text-xs text-slate-600 mt-0.5">GPS: {template.samplingGps}</p>
              </div>

              <div>
                <span className="text-[11px] font-mono uppercase tracking-wider text-slate-500 block">
                  Foliar Pathology Description
                </span>
                <p className="text-xs text-slate-700 leading-relaxed mt-0.5">{template.description}</p>
              </div>

              <div>
                <span className="text-[11px] font-mono uppercase tracking-wider text-slate-500 block mb-1">
                  Key Foliar Disease Markers
                </span>
                <ul className="text-xs text-slate-600 space-y-1">
                  {template.features.map((f, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="text-emerald-600 font-bold">›</span>
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 font-mono text-xs">
                <div className="p-2 rounded bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 block text-[10px]">CHLOROPHYLL INDEX</span>
                  <span className="font-bold text-emerald-800">{template.foliarChlorophyllIndex}%</span>
                </div>
                <div className="p-2 rounded bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 block text-[10px]">FIELD SUNLIGHT</span>
                  <span className="font-bold text-slate-800">{template.canopySunlightLux?.toLocaleString()} Lux</span>
                </div>
              </div>
            </div>

            <button
              onClick={onLoadIntoConsole}
              className="w-full rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-emerald-700 transition-all shadow-xs cursor-pointer flex items-center justify-center gap-2"
            >
              <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polygon points="5 3 19 12 5 21 5 3" />
              </svg>
              Load In Real Detection Console
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
