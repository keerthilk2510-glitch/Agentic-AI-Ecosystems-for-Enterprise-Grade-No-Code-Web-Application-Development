import React, { useState } from 'react';
import {
  CLASS_LABELS,
  CLASS_METRICS,
  CONFUSION_MATRIX,
  MACRO_METRICS,
  MODEL_ARCHITECTURE_SPEC,
  TRAINING_CONVERGENCE_CURVE
} from '../data/datasetMetrics';
import { ConditionClassId, ConfusionMatrixCell } from '../types/cotton';

export const ModelDiagnostics: React.FC = () => {
  const [selectedConfusionCell, setSelectedConfusionCell] = useState<ConfusionMatrixCell | null>(null);
  const [chartMode, setChartMode] = useState<'accuracy' | 'loss'>('accuracy');

  const conditionKeys: ConditionClassId[] = [
    'bacterial_blight',
    'curl_virus',
    'herbicide_growth_damage',
    'leaf_hopper_jassids',
    'leaf_reddening',
    'variegation',
    'healthy_leaf'
  ];

  return (
    <div className="space-y-8">
      {/* Top Section: Macro Metrics KPI Ribbon (Bright Theme) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-xs uppercase font-mono tracking-wider text-slate-500 font-semibold block">
            Overall Categorical Accuracy
          </span>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {(MACRO_METRICS.overallAccuracy * 100).toFixed(1)}%
            </span>
            <span className="text-xs font-mono text-emerald-700 font-semibold">Test N=1,050</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-xs uppercase font-mono tracking-wider text-slate-500 font-semibold block">
            Macro-Averaged Precision
          </span>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {(MACRO_METRICS.precision * 100).toFixed(1)}%
            </span>
            <span className="text-xs font-mono text-slate-500">Across 7 classes</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-xs uppercase font-mono tracking-wider text-slate-500 font-semibold block">
            Macro-Averaged Recall
          </span>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {(MACRO_METRICS.recall * 100).toFixed(1)}%
            </span>
            <span className="text-xs font-mono text-slate-500">Across 7 classes</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-xs uppercase font-mono tracking-wider text-slate-500 font-semibold block">
            Macro F1-Score
          </span>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {(MACRO_METRICS.f1Score * 100).toFixed(1)}%
            </span>
            <span className="text-xs font-mono text-emerald-700 font-semibold">Harmonic Mean</span>
          </div>
        </div>
      </div>

      {/* Two-Column Grid: Loss/Accuracy Curves & Architecture Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Convergence Curves (7 Cols) */}
        <div className="lg:col-span-7 rounded-2xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-slate-100 pb-3 gap-2">
            <div>
              <h3 className="font-bold text-base text-slate-900">
                Training & Validation Convergence (Stages 1 & 2)
              </h3>
              <p className="text-xs text-slate-500">
                Stage 1 (Epochs 1-18: Transfer Learning) · Stage 2 (Epochs 19-33: Fine-Tuning)
              </p>
            </div>

            {/* Toggle accuracy vs loss */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg shrink-0">
              <button
                onClick={() => setChartMode('accuracy')}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  chartMode === 'accuracy'
                    ? 'bg-white text-emerald-800 font-semibold shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Accuracy (%)
              </button>
              <button
                onClick={() => setChartMode('loss')}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  chartMode === 'loss'
                    ? 'bg-white text-emerald-800 font-semibold shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Loss (CCE)
              </button>
            </div>
          </div>

          {/* SVG Convergence Curve Plot (Bright theme) */}
          <div className="mt-4 relative aspect-16/9 w-full bg-slate-50 rounded-xl border border-slate-200 p-3">
            <ConvergenceSvgChart mode={chartMode} />
          </div>

          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 pt-2 border-t border-slate-100">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-sm bg-emerald-600" />
                <span className="font-medium text-slate-700">Training Curve</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-sm bg-teal-500" />
                <span className="font-medium text-slate-700">Validation Curve</span>
              </div>
            </div>
            <span className="font-mono text-[11px] text-slate-500">
              Stage 2 Transition: Epoch 18 (lr: 1e-3 → 1e-5)
            </span>
          </div>
        </div>

        {/* Right Column: MobileNetV2 Architecture & Head Config (5 Cols) */}
        <div className="lg:col-span-5 rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="font-bold text-base text-slate-900">
              Model Architecture & Hyperparameters
            </h3>
            <p className="text-xs text-slate-500">
              MobileNetV2 (α=1.0) with Custom 7-Class Top Head
            </p>
          </div>

          <div className="space-y-2 text-xs text-slate-700">
            <div className="rounded-lg bg-slate-50 p-3 border border-slate-200 space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">Input Specification:</span>
                <span className="font-mono text-emerald-800 font-semibold">224 × 224 × 3 RGB</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Pixel Normalization:</span>
                <span className="font-mono text-slate-800">x / 127.5 - 1.0 ([-1, 1])</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Total Parameters:</span>
                <span className="font-mono font-bold text-slate-900">2,427,335 params</span>
              </div>
            </div>

            <div className="rounded-lg bg-slate-50 p-3 border border-slate-200 space-y-1.5">
              <span className="text-[11px] uppercase font-mono tracking-wider text-slate-500 block font-bold">
                Two-Stage Training Regimen:
              </span>
              <div className="border-l-2 border-emerald-600 pl-2.5 space-y-0.5">
                <strong className="text-slate-900 block">Stage 1: Transfer Learning (Head Only)</strong>
                <p className="text-slate-600">
                  Base 154 layers frozen (2.26M params) · Adam lr=1e-3 · 18 Epochs
                </p>
              </div>
              <div className="border-l-2 border-teal-500 pl-2.5 space-y-0.5 pt-1">
                <strong className="text-slate-900 block">Stage 2: Fine-Tuning (Top 36 Base Layers)</strong>
                <p className="text-slate-600">
                  1.48M trainable params · Adam lr=1e-5 · EarlyStopping + ReduceLROnPlateau
                </p>
              </div>
            </div>

            {/* Top Head Layer Stack */}
            <div className="space-y-1 pt-1">
              <span className="text-[11px] uppercase font-mono tracking-wider text-slate-500 block font-bold">
                Top Head Layers:
              </span>
              <div className="font-mono text-[11px] space-y-1 text-slate-700 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                <div className="flex justify-between">
                  <span>GlobalAveragePooling2D</span>
                  <span className="text-slate-500">(None, 1280)</span>
                </div>
                <div className="flex justify-between">
                  <span>BatchNormalization</span>
                  <span className="text-slate-500">(5,120 params)</span>
                </div>
                <div className="flex justify-between">
                  <span>Dropout(rate=0.3)</span>
                  <span className="text-slate-500">Regularization</span>
                </div>
                <div className="flex justify-between">
                  <span>Dense(128, activation='relu')</span>
                  <span className="text-slate-500">(163,968 params)</span>
                </div>
                <div className="flex justify-between text-emerald-800 font-bold">
                  <span>Dense(7, activation='softmax')</span>
                  <span>(903 params)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 7x7 Multiclass Normalized Confusion Matrix (Bright Clean Style) */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-slate-100 pb-3 gap-2">
          <div>
            <h3 className="font-bold text-base text-slate-900">
              Normalized Multiclass Confusion Matrix (7 × 7)
            </h3>
            <p className="text-xs text-slate-500">
              Evaluated on independent SAR-CLD-2024 test split (150 samples per class = 1,050 total).
            </p>
          </div>

          {selectedConfusionCell && (
            <div className="text-xs bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-800">
              <span>True: <strong>{CLASS_LABELS[selectedConfusionCell.trueClass]}</strong></span>
              <span className="mx-2">→</span>
              <span>Pred: <strong>{CLASS_LABELS[selectedConfusionCell.predictedClass]}</strong></span>
              <span className="ml-2 font-mono text-emerald-700 font-bold">
                {selectedConfusionCell.count} ({selectedConfusionCell.percentage}%)
              </span>
            </div>
          )}
        </div>

        {/* Matrix Grid */}
        <div className="overflow-x-auto pb-2">
          <div className="min-w-[620px]">
            {/* Header Column Labels */}
            <div className="grid grid-cols-8 gap-1.5 mb-1 text-[11px] font-mono text-slate-500 text-center">
              <div className="text-left font-sans text-slate-500 text-xs font-semibold">True \ Pred</div>
              {conditionKeys.map((cKey, idx) => (
                <div key={idx} className="truncate p-1 font-bold text-slate-700" title={CLASS_LABELS[cKey]}>
                  {cKey.substring(0, 3).toUpperCase()}
                </div>
              ))}
            </div>

            {/* Rows */}
            {conditionKeys.map((rowKey, rIdx) => (
              <div key={rIdx} className="grid grid-cols-8 gap-1.5 mb-1.5">
                {/* Row label */}
                <div
                  className="flex items-center text-xs font-semibold text-slate-800 truncate pr-2"
                  title={CLASS_LABELS[rowKey]}
                >
                  <span className="truncate">{CLASS_LABELS[rowKey]}</span>
                </div>

                {/* 7 Columns */}
                {conditionKeys.map((colKey, cIdx) => {
                  const cell = CONFUSION_MATRIX.find(
                    m => m.trueClass === rowKey && m.predictedClass === colKey
                  ) || { trueClass: rowKey, predictedClass: colKey, count: 0, percentage: 0 };

                  const isDiagonal = rowKey === colKey;
                  // Color scale
                  let bgColor = 'bg-slate-50 border border-slate-200';
                  let textColor = 'text-slate-400';
                  if (isDiagonal) {
                    bgColor = 'bg-emerald-600 border border-emerald-700';
                    textColor = 'text-white font-bold';
                  } else if (cell.count > 0) {
                    bgColor = 'bg-rose-50 border border-rose-200';
                    textColor = 'text-rose-800 font-semibold';
                  }

                  return (
                    <button
                      key={cIdx}
                      onClick={() => setSelectedConfusionCell(cell)}
                      className={`flex flex-col items-center justify-center p-2 rounded-md ${bgColor} ${textColor} text-xs transition-transform hover:scale-105 cursor-pointer font-mono`}
                      title={`True: ${CLASS_LABELS[rowKey]}, Predicted: ${CLASS_LABELS[colKey]}: ${cell.count} (${cell.percentage}%)`}
                    >
                      <span className="text-[11px] font-semibold">{cell.percentage}%</span>
                      <span className={`text-[10px] ${isDiagonal ? 'text-white/90' : 'text-slate-500'}`}>({cell.count})</span>
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        </div>

        <div className="text-[11px] text-slate-500 flex flex-wrap gap-4 pt-1 border-t border-slate-100">
          <span>Diagonal = Correct Classification (Mean True Positive Rate: 97.4%)</span>
          <span>·</span>
          <span>Off-diagonal = Cross-entropy confusion</span>
        </div>
      </div>

      {/* Scikit-Learn Classification Report Table (Bright Clean) */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
        <div className="border-b border-slate-100 pb-3">
          <h3 className="font-bold text-base text-slate-900">
            Scikit-Learn Classification Report
          </h3>
          <p className="text-xs text-slate-500">
            Precision, Recall, F1-Score, Support, and ROC-AUC for all 7 classes.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="border-b border-slate-200 bg-slate-50 text-[11px] uppercase font-mono text-slate-600">
              <tr>
                <th className="py-2.5 px-3">Condition Class</th>
                <th className="py-2.5 px-3">Precision</th>
                <th className="py-2.5 px-3">Recall</th>
                <th className="py-2.5 px-3">F1-Score</th>
                <th className="py-2.5 px-3">ROC-AUC</th>
                <th className="py-2.5 px-3">Test Support</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {CLASS_METRICS.map(cm => (
                <tr key={cm.classId} className="hover:bg-slate-50/70">
                  <td className="py-2.5 px-3 font-sans font-semibold text-slate-900">
                    {cm.className}
                  </td>
                  <td className="py-2.5 px-3 tabular-nums text-emerald-700 font-medium">
                    {(cm.precision * 100).toFixed(1)}%
                  </td>
                  <td className="py-2.5 px-3 tabular-nums text-teal-700 font-medium">
                    {(cm.recall * 100).toFixed(1)}%
                  </td>
                  <td className="py-2.5 px-3 tabular-nums font-bold text-slate-900">
                    {(cm.f1Score * 100).toFixed(1)}%
                  </td>
                  <td className="py-2.5 px-3 tabular-nums text-slate-600">
                    {cm.rocAuc.toFixed(3)}
                  </td>
                  <td className="py-2.5 px-3 tabular-nums text-slate-500">
                    {cm.support}
                  </td>
                </tr>
              ))}
              <tr className="bg-emerald-50/50 font-semibold text-slate-900 border-t-2 border-slate-200">
                <td className="py-3 px-3 font-sans text-emerald-900 font-bold">
                  Macro Average (7 Classes)
                </td>
                <td className="py-3 px-3 tabular-nums text-emerald-800 font-bold">
                  {(MACRO_METRICS.precision * 100).toFixed(1)}%
                </td>
                <td className="py-3 px-3 tabular-nums text-teal-800 font-bold">
                  {(MACRO_METRICS.recall * 100).toFixed(1)}%
                </td>
                <td className="py-3 px-3 tabular-nums text-emerald-800 font-bold">
                  {(MACRO_METRICS.f1Score * 100).toFixed(1)}%
                </td>
                <td className="py-3 px-3 tabular-nums font-bold">0.998</td>
                <td className="py-3 px-3 tabular-nums text-slate-700 font-bold">
                  {MACRO_METRICS.totalTestSamples}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// Svg Plot for Loss and Accuracy Curves (Bright Style)
const ConvergenceSvgChart: React.FC<{ mode: 'accuracy' | 'loss' }> = ({ mode }) => {
  const data = TRAINING_CONVERGENCE_CURVE;
  const w = 580;
  const h = 260;
  const padL = 45;
  const padR = 20;
  const padT = 25;
  const padB = 30;

  const plotW = w - padL - padR;
  const plotH = h - padT - padB;

  // Min and Max
  const minVal = mode === 'accuracy' ? 0.45 : 0.0;
  const maxVal = mode === 'accuracy' ? 1.0 : 1.55;

  const getX = (epoch: number) => padL + ((epoch - 1) / (data.length - 1)) * plotW;
  const getY = (val: number) => padT + plotH - ((val - minVal) / (maxVal - minVal)) * plotH;

  // Generate path points
  const trainPoints = data.map(d => `${getX(d.epoch)},${getY(mode === 'accuracy' ? d.trainAcc : d.trainLoss)}`).join(' ');
  const valPoints = data.map(d => `${getX(d.epoch)},${getY(mode === 'accuracy' ? d.valAcc : d.valLoss)}`).join(' ');

  // Epoch 18 line (Stage 1 to Stage 2 transition)
  const xStageBreak = getX(18);

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-full">
      {/* Grid horizontal lines */}
      {[0, 0.25, 0.5, 0.75, 1.0].map((frac, idx) => {
        const val = minVal + frac * (maxVal - minVal);
        const y = padT + plotH - frac * plotH;
        return (
          <g key={idx}>
            <line x1={padL} y1={y} x2={w - padR} y2={y} stroke="#E2E8F0" strokeDasharray="3 3" />
            <text x={padL - 6} y={y + 4} fill="#64748B" fontSize="10" textAnchor="end" fontFamily="monospace">
              {mode === 'accuracy' ? `${Math.round(val * 100)}%` : val.toFixed(2)}
            </text>
          </g>
        );
      })}

      {/* Stage transition marker */}
      <line x1={xStageBreak} y1={padT} x2={xStageBreak} y2={padT + plotH} stroke="#94A3B8" strokeDasharray="4 4" />
      <text x={xStageBreak - 4} y={padT + 12} fill="#64748B" fontSize="10" textAnchor="end" fontFamily="monospace">
        Stage 1: Frozen
      </text>
      <text x={xStageBreak + 6} y={padT + 12} fill="#059669" fontSize="10" textAnchor="start" fontFamily="monospace">
        Stage 2: Fine-Tuning
      </text>

      {/* Epoch x-axis labels */}
      {[1, 6, 12, 18, 24, 30, 33].map((ep, idx) => (
        <text key={idx} x={getX(ep)} y={h - 10} fill="#64748B" fontSize="10" textAnchor="middle" fontFamily="monospace">
          Ep {ep}
        </text>
      ))}

      {/* Train Curve */}
      <polyline fill="none" stroke="#059669" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" points={trainPoints} />

      {/* Validation Curve */}
      <polyline fill="none" stroke="#0D9488" strokeWidth="2" strokeDasharray="4 2" strokeLinecap="round" strokeLinejoin="round" points={valPoints} />
    </svg>
  );
};
