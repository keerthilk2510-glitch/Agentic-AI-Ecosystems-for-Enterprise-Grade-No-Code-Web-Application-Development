import React from 'react';
import { DATASET_INFO } from '../data/datasetMetrics';
import { ExtendedLeafTemplate, LEAF_TEMPLATES } from '../data/leafTemplates';

interface DatasetExplorerProps {
  onSelectTemplate: (template: ExtendedLeafTemplate) => void;
}

export const DatasetExplorer: React.FC<DatasetExplorerProps> = ({ onSelectTemplate }) => {
  return (
    <div className="space-y-8">
      {/* Overview Card (Bright Theme) */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-slate-100 pb-4 gap-2">
          <div>
            <span className="text-xs font-mono uppercase tracking-wider text-emerald-700 font-bold">
              Benchmark Real-Environment Corpus
            </span>
            <h2 className="text-xl font-bold tracking-tight text-slate-900 mt-0.5">
              {DATASET_INFO.name} Cotton Foliar Pathology Corpus
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Field-collected under natural agricultural conditions across commercial Gossypium cultivars.
            </p>
          </div>

          <div className="flex items-center gap-3 text-xs font-mono text-slate-700">
            <div className="bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
              <span className="text-slate-500 block text-[10px]">ORIGINAL RAW</span>
              <span className="font-bold text-slate-900 tabular-nums">{DATASET_INFO.originalImages.toLocaleString()}</span>
            </div>
            <div className="bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
              <span className="text-slate-500 block text-[10px]">AUGMENTED</span>
              <span className="font-bold text-emerald-700 tabular-nums">{DATASET_INFO.augmentedImages.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Data Splits Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
            <span className="text-xs uppercase font-mono text-slate-500 font-semibold block">Training Partition (70%)</span>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">4,900</span>
              <span className="text-xs text-slate-500">700 samples / class</span>
            </div>
            <div className="mt-2 h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-600 rounded-full" style={{ width: '70%' }} />
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
            <span className="text-xs uppercase font-mono text-slate-500 font-semibold block">Validation Partition (15%)</span>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">1,050</span>
              <span className="text-xs text-slate-500">150 samples / class</span>
            </div>
            <div className="mt-2 h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
              <div className="h-full bg-teal-500 rounded-full" style={{ width: '15%' }} />
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
            <span className="text-xs uppercase font-mono text-slate-500 font-semibold block">Test Partition (15%)</span>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">1,050</span>
              <span className="text-xs text-slate-500">150 samples / class</span>
            </div>
            <div className="mt-2 h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-500 rounded-full" style={{ width: '15%' }} />
            </div>
          </div>
        </div>
      </div>

      {/* Augmentation Engineering Pipeline */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
        <div className="border-b border-slate-100 pb-3">
          <h3 className="font-bold text-base text-slate-900">
            Data Augmentation Pipeline (TensorFlow / Albumentations)
          </h3>
          <p className="text-xs text-slate-500">
            Transforms applied to bridge domain gaps between variable real-world in-field farm conditions.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {DATASET_INFO.augmentationTechniques.map((tech, idx) => (
            <div key={idx} className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-1.5">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-xs text-slate-900">{tech.name}</h4>
                <span className="font-mono text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-semibold">
                  {tech.parameter}
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                {tech.purpose}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Condition Class Taxonomy & Botanical Reference */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
        <div className="border-b border-slate-100 pb-3">
          <h3 className="font-bold text-base text-slate-900">
            7 Target Condition Classes
          </h3>
          <p className="text-xs text-slate-500">
            Click any condition class to inspect and detect its real-environment specimen in the live console.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {LEAF_TEMPLATES.filter((_, i) => i % 2 === 0).map(tpl => (
            <div
              key={tpl.id}
              className="rounded-xl border border-slate-200 bg-slate-50/70 p-4 space-y-2 hover:border-slate-300 transition-colors"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 truncate">{tpl.label}</span>
                <span className="text-[11px] font-mono text-slate-600 font-semibold">{tpl.severity}</span>
              </div>
              <p className="text-xs text-emerald-700 font-serif italic line-clamp-1">{tpl.scientificName}</p>
              <p className="text-xs text-slate-600 line-clamp-2">{tpl.description}</p>
              <button
                onClick={() => onSelectTemplate(tpl)}
                className="mt-2 w-full rounded-lg bg-emerald-600 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 transition-colors cursor-pointer shadow-xs"
              >
                Inspect in Detection Console
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
