import React, { useState } from 'react';
import { ADVISORY_KNOWLEDGE_BASE } from '../data/advisoryKnowledgeBase';
import { ConditionClassId } from '../types/cotton';

interface AdvisoryPanelProps {
  currentClassId: ConditionClassId;
  onOpenReportModal: () => void;
}

export const AdvisoryPanel: React.FC<AdvisoryPanelProps> = ({
  currentClassId,
  onOpenReportModal
}) => {
  const [activeSection, setActiveSection] = useState<'symptoms' | 'cultural' | 'chemical' | 'biological' | 'ipm'>('symptoms');

  const advisory = ADVISORY_KNOWLEDGE_BASE[currentClassId];

  const severityTone =
    advisory.severity === 'Critical'
      ? 'bg-rose-50 text-rose-800 border-rose-300'
      : advisory.severity === 'High'
      ? 'bg-amber-50 text-amber-800 border-amber-300'
      : advisory.severity === 'Moderate'
      ? 'bg-orange-50 text-orange-800 border-orange-300'
      : advisory.severity === 'Low'
      ? 'bg-yellow-50 text-yellow-800 border-yellow-300'
      : 'bg-emerald-50 text-emerald-800 border-emerald-300';

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-6">
      {/* Header with Title and Severity Tag (Bright Theme) */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between border-b border-slate-100 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <span>{advisory.diseaseType}</span>
            <span aria-hidden="true">·</span>
            <span>Taxon: {advisory.casualAgent}</span>
          </div>

          <h2 className="mt-1 text-2xl font-bold tracking-tight text-slate-900">
            {advisory.commonName}
          </h2>
          <p className="text-sm font-serif italic text-emerald-700 mt-0.5">
            {advisory.scientificName}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className={`px-3 py-1.5 rounded-lg border text-xs font-semibold ${severityTone}`}>
            Severity: {advisory.severity} ({advisory.severityScore}/100)
          </div>
          <button
            onClick={onOpenReportModal}
            className="rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-700 transition-all cursor-pointer shadow-xs flex items-center gap-1.5"
          >
            <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M6 9V2h12v7" />
              <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" />
              <rect x="6" y="14" width="12" height="8" />
            </svg>
            Print Advisory Report
          </button>
        </div>
      </div>

      {/* Botanical Overview */}
      <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-4 text-xs text-slate-700 leading-relaxed">
        <span className="font-semibold text-slate-900 block mb-1">Etiological Profile:</span>
        <p>{advisory.botanicalDescription}</p>
        <div className="mt-2.5 pt-2.5 border-t border-slate-200/80 flex flex-wrap gap-x-6 gap-y-1 text-slate-600">
          <div>
            <strong className="text-slate-900">Economic Threshold (ETL):</strong> {advisory.economicThresholdLevel}
          </div>
          <div>
            <strong className="text-slate-900">Optimal Spraying Window:</strong> {advisory.optimalSprayingWindow}
          </div>
        </div>
      </div>

      {/* Advisory Section Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-1">
        <button
          onClick={() => setActiveSection('symptoms')}
          className={`px-3 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeSection === 'symptoms'
              ? 'border-emerald-600 text-emerald-800 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          Diagnostic Symptoms
        </button>
        <button
          onClick={() => setActiveSection('cultural')}
          className={`px-3 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeSection === 'cultural'
              ? 'border-emerald-600 text-emerald-800 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          Immediate Cultural Controls
        </button>
        <button
          onClick={() => setActiveSection('chemical')}
          className={`px-3 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeSection === 'chemical'
              ? 'border-emerald-600 text-emerald-800 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          Chemical Remedies ({advisory.chemicalRemedies.length})
        </button>
        <button
          onClick={() => setActiveSection('biological')}
          className={`px-3 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeSection === 'biological'
              ? 'border-emerald-600 text-emerald-800 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          Biological / Organic ({advisory.biologicalRemedies.length})
        </button>
        <button
          onClick={() => setActiveSection('ipm')}
          className={`px-3 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeSection === 'ipm'
              ? 'border-emerald-600 text-emerald-800 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          Long-Term IPM Strategy
        </button>
      </div>

      {/* Tab Content Display */}
      <div>
        {/* 1. Diagnostic Symptoms */}
        {activeSection === 'symptoms' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="rounded-xl border border-slate-200 bg-slate-50/50 p-4 space-y-3">
              <span className="text-xs uppercase font-mono tracking-wider text-slate-500 font-semibold block">
                Progression Stages
              </span>
              <div>
                <strong className="text-xs text-emerald-800 block mb-0.5">Early Detection Phase:</strong>
                <p className="text-xs text-slate-700 leading-relaxed">{advisory.symptoms.earlyStage}</p>
              </div>
              <div className="pt-2 border-t border-slate-200">
                <strong className="text-xs text-amber-800 block mb-0.5">Advanced / Field Shock Phase:</strong>
                <p className="text-xs text-slate-700 leading-relaxed">{advisory.symptoms.advancedStage}</p>
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 bg-slate-50/50 p-4 space-y-3">
              <span className="text-xs uppercase font-mono tracking-wider text-slate-500 font-semibold block">
                Key Foliar Pathology Markers
              </span>
              <ul className="space-y-2 text-xs text-slate-700">
                {advisory.symptoms.foliarMarkers.map((marker, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-emerald-600 font-bold mt-0.5">›</span>
                    <span>{marker}</span>
                  </li>
                ))}
              </ul>
              <div className="pt-2 border-t border-slate-200 text-xs text-slate-500">
                <span className="text-slate-700 font-medium">Susceptible Organs:</span>{' '}
                {advisory.symptoms.affectedParts.join(', ')}
              </div>
            </div>
          </div>
        )}

        {/* 2. Immediate Cultural Controls */}
        {activeSection === 'cultural' && (
          <div className="rounded-xl border border-slate-200 bg-slate-50/50 p-5 space-y-3">
            <span className="text-xs uppercase font-mono tracking-wider text-slate-500 font-semibold block mb-1">
              Immediate Field Actions & Sanitation Measures
            </span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {advisory.immediateCulturalControl.map((ctrl, idx) => (
                <div key={idx} className="rounded-lg border border-slate-200 bg-white p-3.5 text-xs text-slate-700 leading-relaxed shadow-2xs">
                  <div className="flex items-start gap-2">
                    <span className="font-mono text-emerald-700 font-bold">0{idx + 1}.</span>
                    <span>{ctrl}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 3. Chemical Remedies */}
        {activeSection === 'chemical' && (
          <div className="space-y-4">
            {advisory.chemicalRemedies.map((remedy, idx) => (
              <div
                key={idx}
                className="rounded-xl border border-slate-200 bg-white p-5 space-y-3 hover:border-slate-300 transition-colors shadow-2xs"
              >
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-100 pb-3">
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">{remedy.activeIngredient}</h4>
                    <span className="text-xs text-slate-500">
                      Representative Brands: {remedy.recommendedBrands.join(', ')}
                    </span>
                  </div>
                  <div className="text-xs font-mono text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200 self-start sm:self-auto font-semibold">
                    Pre-Harvest Interval (PHI): {remedy.safetyIntervalDays} days
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="rounded-lg bg-slate-50 p-2.5 border border-slate-200">
                    <span className="text-slate-500 block text-[11px] uppercase font-mono">Dosage Per Hectare</span>
                    <span className="font-semibold text-slate-900 mt-0.5 block">{remedy.dosagePerHectare}</span>
                  </div>
                  <div className="rounded-lg bg-slate-50 p-2.5 border border-slate-200">
                    <span className="text-slate-500 block text-[11px] uppercase font-mono">Dosage Per Acre</span>
                    <span className="font-semibold text-slate-900 mt-0.5 block">{remedy.dosagePerAcre}</span>
                  </div>
                  <div className="rounded-lg bg-slate-50 p-2.5 border border-slate-200">
                    <span className="text-slate-500 block text-[11px] uppercase font-mono">Carrier Water</span>
                    <span className="font-semibold text-slate-900 mt-0.5 block">{remedy.waterVolume}</span>
                  </div>
                </div>

                <p className="text-xs text-slate-700 pt-1">
                  <strong className="text-slate-900">Application Protocol:</strong> {remedy.applicationMode}
                </p>
              </div>
            ))}
          </div>
        )}

        {/* 4. Biological Remedies */}
        {activeSection === 'biological' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {advisory.biologicalRemedies.map((bio, idx) => (
              <div key={idx} className="rounded-xl border border-slate-200 bg-white p-4 space-y-2.5 shadow-2xs">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <h4 className="font-bold text-xs text-emerald-800">{bio.agentName}</h4>
                  <span className="text-[11px] text-slate-600 font-mono bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                    {bio.type}
                  </span>
                </div>
                <div className="text-xs text-slate-700 space-y-1.5 leading-relaxed">
                  <div>
                    <strong className="text-slate-900">Formulation & Rate:</strong> {bio.preparationMethod}
                  </div>
                  <div>
                    <strong className="text-slate-900">Mechanism of Action:</strong> {bio.applicationNotes}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 5. IPM Strategy */}
        {activeSection === 'ipm' && (
          <div className="rounded-xl border border-slate-200 bg-slate-50/50 p-5 space-y-3">
            <span className="text-xs uppercase font-mono tracking-wider text-slate-500 font-semibold block mb-1">
              Integrated Pest & Disease Management (IPM) Schedule
            </span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {advisory.preventionAndIPM.map((ipm, idx) => (
                <div key={idx} className="rounded-lg border border-slate-200 bg-white p-3.5 text-xs text-slate-700 leading-relaxed shadow-2xs">
                  <div className="flex items-start gap-2">
                    <span className="text-emerald-600 font-bold">•</span>
                    <span>{ipm}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
