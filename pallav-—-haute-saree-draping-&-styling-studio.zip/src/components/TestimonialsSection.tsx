import React, { useState } from 'react';
import { TESTIMONIALS } from '../data/drapingData';
import { Star, Sparkles, CheckCircle2, Quote } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const [filter, setFilter] = useState<'All' | 'Bridal' | 'Bridesmaids' | 'Masterclass'>('All');

  const filteredTestimonials = TESTIMONIALS.filter(t => {
    if (filter === 'All') return true;
    if (filter === 'Bridal') return t.occasion.includes('Wedding') || t.occasion.includes('Lagna');
    if (filter === 'Bridesmaids') return t.role.includes('Maid of Honor');
    if (filter === 'Masterclass') return t.occasion.includes('Masterclass');
    return true;
  });

  return (
    <section id="reviews" className="py-16 lg:py-24 bg-[#F0F5FA] border-b border-[#CBDCEE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#9E7418]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Client Praise & Stories</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1A30]">
            Loved by Brides & Saree Connoisseurs
          </h2>
          <p className="text-base text-[#384F6B] leading-relaxed">
            Read real accounts of how our 12-hour locked pleats survived mandap rituals, rain, sangeet performances, and all-night dancing.
          </p>

          {/* Filter Pills */}
          <div className="inline-flex p-1 bg-[#D8E6F5] rounded-lg mt-2">
            {(['All', 'Bridal', 'Bridesmaids', 'Masterclass'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setFilter(tab)}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                  filter === tab
                    ? 'bg-[#0D2444] text-[#FDFBF7] shadow-xs'
                    : 'text-[#384F6B] hover:text-[#0B1A30]'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredTestimonials.map((review) => (
            <div
              key={review.id}
              className="bg-white rounded-xl border border-[#CBDCEE] p-6 sm:p-8 space-y-4 shadow-xs flex flex-col justify-between"
            >
              <div className="space-y-3">
                {/* Top Row: Rating & Verified */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-[#D4AF37]">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#D4AF37]" />
                    ))}
                  </div>
                  
                  {review.verified && (
                    <div className="flex items-center gap-1 text-[11px] font-semibold text-[#1E562A] bg-[#EAF5EC] px-2 py-0.5 rounded">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Verified Client</span>
                    </div>
                  )}
                </div>

                {/* Saree & Occasion Tag */}
                <div className="text-[11px] text-[#475E7B] font-medium border-l-2 border-[#D4AF37] pl-2.5">
                  <span className="font-semibold text-[#0B1A30]">{review.occasion}</span> · {review.sareeType}
                </div>

                {/* Quote */}
                <p className="text-sm text-[#273B52] leading-relaxed italic">
                  "{review.quote}"
                </p>
              </div>

              {/* Client Info */}
              <div className="pt-4 border-t border-[#E1EDFA] flex items-center justify-between">
                <div>
                  <h4 className="font-serif text-base font-bold text-[#0B1A30]">
                    {review.clientName}
                  </h4>
                  <p className="text-xs text-[#556F8C]">
                    {review.role}
                  </p>
                </div>
                <span className="text-[11px] text-[#6A84A1]">
                  {review.location}
                </span>
              </div>

            </div>
          ))}
        </div>

        {/* Trust summary footer */}
        <div className="mt-12 text-center text-xs text-[#475E7B] flex items-center justify-center gap-2">
          <Quote className="w-4 h-4 text-[#D4AF37]" />
          <span>Over 450+ 5-star ratings on Google & WeddingWire for punctuality, comfort & zero pin tears.</span>
        </div>

      </div>
    </section>
  );
};
