import React from 'react';
import { MessageCircle, Phone, MapPin, Navigation } from 'lucide-react';
import { STUDIO_INFO } from '../data/drapingData';

interface FooterProps {
  onOpenBooking: () => void;
  onOpenQuiz: () => void;
  onOpenAdminBookings?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenBooking, onOpenAdminBookings }) => {
  return (
    <footer className="bg-[#081324] text-[#D8E6F5] border-t border-[#142A4A] pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-12 border-b border-[#142A4A]">
          
          {/* Brand Info */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex flex-col">
              <span className="font-serif text-3xl font-bold tracking-wider text-[#FDFBF7]">
                GEETHA SAREE DRAPING
              </span>
              <span className="text-[10px] tracking-[0.2em] uppercase text-[#D4AF37] font-semibold">
                Bridal, Kerala, Bharatanatyam & Traditional Drapes
              </span>
            </div>

            <p className="text-xs text-[#8EA8C7] leading-relaxed max-w-sm">
              Professional saree styling by Geetha. Prices start from <strong className="text-white">₹1,500</strong>. Master of Wedding Bridal (₹3,000), Kerala Style (₹2,500), Bharatanatyam Dance (₹4,000), Indian Saree (₹2,000), and Kacha Style (₹4,000).
            </p>

            <div className="pt-2 flex items-center gap-3">
              <button
                onClick={onOpenBooking}
                className="px-4 py-2 bg-[#D4AF37] hover:bg-[#B99326] text-[#081324] font-semibold text-xs rounded-lg transition-colors cursor-pointer"
              >
                Book with Geetha
              </button>
              <a
                href={STUDIO_INFO.directionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3.5 py-2 bg-[#0E2038] hover:bg-[#153054] text-[#D8E6F5] border border-[#21436E] font-medium text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Navigation className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Google Map</span>
              </a>
            </div>
          </div>

          {/* Draping Repertoire Links */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-serif text-sm font-bold text-[#FDFBF7] uppercase tracking-wider">
              Specialist Draping Styles
            </h4>
            <ul className="space-y-2 text-xs text-[#8EA8C7]">
              <li className="flex justify-between items-center pr-4">
                <a href="#styles" className="hover:text-[#D4AF37] transition-colors">Wedding Bridal Saree</a>
                <span className="text-[#D4AF37] font-semibold">₹3,000</span>
              </li>
              <li className="flex justify-between items-center pr-4">
                <a href="#styles" className="hover:text-[#D4AF37] transition-colors">Kerala Style Kasavu</a>
                <span className="text-[#D4AF37] font-semibold">₹2,500</span>
              </li>
              <li className="flex justify-between items-center pr-4">
                <a href="#styles" className="hover:text-[#D4AF37] transition-colors">Bharatanatyam Dance Drape</a>
                <span className="text-[#D4AF37] font-semibold">₹4,000</span>
              </li>
              <li className="flex justify-between items-center pr-4">
                <a href="#styles" className="hover:text-[#D4AF37] transition-colors">Indian Saree (Festive/Party)</a>
                <span className="text-[#D4AF37] font-semibold">₹2,000</span>
              </li>
              <li className="flex justify-between items-center pr-4">
                <a href="#styles" className="hover:text-[#D4AF37] transition-colors">Kacha Saree Style (Dhoti/Madisar)</a>
                <span className="text-[#D4AF37] font-semibold">₹4,000</span>
              </li>
              <li className="flex justify-between items-center pr-4">
                <a href="#styles" className="hover:text-[#D4AF37] transition-colors">Party & Festive Drape</a>
                <span className="text-[#84CA97] font-semibold">From ₹1,500</span>
              </li>
            </ul>
          </div>

          {/* Services & Offerings */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-serif text-sm font-bold text-[#FDFBF7] uppercase tracking-wider">
              Studio & Visits
            </h4>
            <ul className="space-y-2 text-xs text-[#8EA8C7]">
              <li><a href="#location" className="hover:text-[#D4AF37] transition-colors">Studio in Bangalore South</a></li>
              <li><a href="#services" className="hover:text-[#D4AF37] transition-colors">Bridal Couture Draping</a></li>
              <li><a href="#services" className="hover:text-[#D4AF37] transition-colors">Arangetram Stage Draping</a></li>
              <li><a href="#services" className="hover:text-[#D4AF37] transition-colors">9-Yard Kacha & Madisar</a></li>
              <li><a href="#services" className="hover:text-[#D4AF37] transition-colors">Kerala Wedding & Onam</a></li>
              <li><a href="#location" className="hover:text-[#D4AF37] transition-colors">On-Site Mandapam Visits</a></li>
            </ul>
          </div>

          {/* Contact Details with Exact Address */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-serif text-sm font-bold text-[#FDFBF7] uppercase tracking-wider">
              Contact & Live Location
            </h4>
            <div className="space-y-2 text-xs text-[#8EA8C7]">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span>
                  {STUDIO_INFO.addressLine1},<br />
                  <strong className="text-white">{STUDIO_INFO.landmark}</strong>,<br />
                  {STUDIO_INFO.locality}, {STUDIO_INFO.state} – {STUDIO_INFO.pincode}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <a href={`tel:${STUDIO_INFO.phone}`} className="font-bold text-white hover:text-[#D4AF37] tabular-nums">
                  {STUDIO_INFO.phone}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-[#84CA97] shrink-0" />
                <a 
                  href={`https://wa.me/${STUDIO_INFO.whatsappNumber}?text=Hello%20Geetha!%20I%20would%20like%20to%20book%20a%20saree%20draping%20session.`} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[#84CA97] hover:underline font-semibold"
                >
                  WhatsApp: 8050566063 Available
                </a>
              </div>
              <div className="flex items-center gap-2 pt-1">
                <Navigation className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <a 
                  href={STUDIO_INFO.directionsUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[#D4AF37] hover:underline"
                >
                  Open in Google Maps
                </a>
              </div>
            </div>

            <div className="pt-2 text-[11px] text-[#6985A5]">
              Studio Hours: 05:30 AM – 09:30 PM (Prior Appointment Recommended)
            </div>
          </div>

        </div>

        {/* Bottom Disclaimer & Copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-[#6985A5] gap-4">
          <div>
            © {new Date().getFullYear()} Geetha Saree Draping. Vittasandra Main Road, Bangalore South.
          </div>
          <div className="flex items-center gap-4 text-xs">
            <span>Saree Draping Starts from ₹1,500</span>
            <span aria-hidden="true">·</span>
            <span>Phone: 8050566063</span>
            <span aria-hidden="true">·</span>
            <a href="#faq" className="hover:text-[#D4AF37]">FAQ & Policies</a>
            {onOpenAdminBookings && (
              <>
                <span aria-hidden="true">·</span>
                <button
                  onClick={onOpenAdminBookings}
                  className="hover:text-[#84CA97] cursor-pointer text-[#84CA97] font-semibold flex items-center gap-1"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-[#84CA97] inline-block" />
                  <span>Supabase Bookings</span>
                </button>
              </>
            )}
          </div>
        </div>

      </div>
    </footer>
  );
};
