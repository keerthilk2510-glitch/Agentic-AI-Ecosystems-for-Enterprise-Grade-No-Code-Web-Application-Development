import React from 'react';
import { Sparkles, Check, Video, Users, Award, BookOpen, ArrowRight } from 'lucide-react';
import { MASTERCLASS_IMAGE } from '../data/drapingData';

interface MasterclassSectionProps {
  onBookMasterclass: () => void;
}

export const MasterclassSection: React.FC<MasterclassSectionProps> = ({ onBookMasterclass }) => {
  const modules = [
    {
      title: 'Module 1: The Geometry of Pleats',
      desc: 'Master the mathematical alignment of 1.5-inch uniform knife pleats, fan pleats, and box pleats across varying waist contours.'
    },
    {
      title: 'Module 2: Taming Difficult Fabrics',
      desc: 'Stop fighting stiff organza and slippery georgette. Learn temperature steam-pressing and friction-tucking methods.'
    },
    {
      title: 'Module 3: The 8-Minute Rapid Drape',
      desc: 'Step-by-step muscle memory sequence so you can step into any saree and head out the door in under 8 minutes without assistance.'
    },
    {
      title: 'Module 4: Pin-Safety & Heirloom Protection',
      desc: 'How to distribute pallu weight without ripping antique zari, poking your skin, or pulling delicate blouse stitching.'
    }
  ];

  return (
    <section id="masterclass" className="py-16 lg:py-24 bg-[#F0F5FA] border-b border-[#CBDCEE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          {/* Left Column: Visual Showcase */}
          <div className="lg:col-span-5 relative order-2 lg:order-1">
            <div className="relative rounded-2xl overflow-hidden border border-[#CBDCEE] shadow-xl bg-[#E2EDFA] aspect-[4/3] sm:aspect-[4/4]">
              <img
                src={MASTERCLASS_IMAGE}
                alt="Master stylist hands demonstrating precision knife pleat alignment on Banarasi silk saree"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center"
              />

              <div className="absolute inset-0 bg-gradient-to-t from-[#06111F]/85 via-transparent to-transparent flex flex-col justify-end p-6 text-white">
                <div className="space-y-1">
                  <span className="text-xs text-[#D8E6F5] font-semibold tracking-wider uppercase">
                    Hands-On Atelier Training
                  </span>
                  <h4 className="font-serif text-xl font-bold text-white">
                    Master the Art of the Six Yards
                  </h4>
                  <p className="text-xs text-[#CBDDF0]">
                    Learn the precise finger-tuck techniques used by red-carpet drapers.
                  </p>
                </div>
              </div>
            </div>

            {/* Floating badge */}
            <div className="absolute -bottom-4 -right-4 sm:-right-6 bg-white border border-[#CBDCEE] rounded-xl p-3.5 shadow-lg max-w-[220px] text-xs space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-[#0D2444]">
                <Award className="w-4 h-4 text-[#D4AF37]" />
                <span>Certificate Included</span>
              </div>
              <p className="text-[11px] text-[#475E7B]">
                Receive the official Geetha Saree Draping Masterclass Certificate & Handbook.
              </p>
            </div>
          </div>

          {/* Right Column: Syllabus & Booking */}
          <div className="lg:col-span-7 space-y-6 order-1 lg:order-2">
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#9E7418]">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Personalized Workshops</span>
              </div>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1A30]">
                1-on-1 Saree Draping Masterclass
              </h2>
              <p className="text-sm sm:text-base text-[#384F6B] leading-relaxed">
                Whether you are a bride preparing for your trousseau, a mother passing traditions to your daughter, or a diaspora woman wanting to feel confident at galas, our private masterclass empowers you to drape flawlessly.
              </p>
            </div>

            {/* Modules Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {modules.map((mod, i) => (
                <div key={i} className="bg-white p-4 rounded-xl border border-[#CBDCEE] space-y-1.5 shadow-xs">
                  <h4 className="font-serif text-base font-bold text-[#0B1A30] flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#1E562A] shrink-0" />
                    <span>{mod.title}</span>
                  </h4>
                  <p className="text-xs text-[#475E7B] leading-relaxed">
                    {mod.desc}
                  </p>
                </div>
              ))}
            </div>

            {/* Delivery format options */}
            <div className="flex flex-wrap gap-4 text-xs text-[#384F6B] pt-2">
              <div className="flex items-center gap-2 bg-[#E6EFF8] px-3 py-1.5 rounded-lg border border-[#CBDCEE]">
                <Users className="w-3.5 h-3.5 text-[#9E7418]" />
                <span>In-Studio 1-on-1 (Private Suite)</span>
              </div>
              <div className="flex items-center gap-2 bg-[#E6EFF8] px-3 py-1.5 rounded-lg border border-[#CBDCEE]">
                <Video className="w-3.5 h-3.5 text-[#9E7418]" />
                <span>Global Interactive Zoom (4K Dual Camera)</span>
              </div>
              <div className="flex items-center gap-2 bg-[#E6EFF8] px-3 py-1.5 rounded-lg border border-[#CBDCEE]">
                <BookOpen className="w-3.5 h-3.5 text-[#9E7418]" />
                <span>Includes Physical Styling Toolkit</span>
              </div>
            </div>

            {/* CTA */}
            <div className="pt-2">
              <button
                onClick={onBookMasterclass}
                className="px-6 py-3 bg-[#0D2444] hover:bg-[#07162B] text-white font-semibold text-xs sm:text-sm rounded-lg shadow-sm hover:shadow transition-all flex items-center gap-2 cursor-pointer border border-[#1B3E6E]"
              >
                <span>Reserve Your Private Masterclass with Geetha (₹4,500)</span>
                <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
