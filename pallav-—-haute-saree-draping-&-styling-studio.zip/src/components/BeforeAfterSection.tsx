import React, { useState } from 'react';
import { Check, X, Sparkles, Layers, ShieldCheck, Footprints, Clock } from 'lucide-react';
import { BEFORE_AFTER_DATA } from '../data/drapingData';

export const BeforeAfterSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'comparison' | 'detailed'>('comparison');

  const comparisonFeatures = [
    {
      aspect: 'Front Pleat Precision',
      diy: 'Uneven width (1" to 3"), loose center tuck prone to unraveling when walking',
      geetha: 'Exact 1.5-inch uniform knife pleats with internal dual-anchor lock',
      icon: Layers,
    },
    {
      aspect: 'Pallu Weight & Shoulder Anchor',
      diy: 'Single strained safety pin pulling on blouse seam; constantly slides backward',
      geetha: 'Balanced weight distribution with velvet magnetic guard & zero fabric pinch',
      icon: ShieldCheck,
    },
    {
      aspect: 'Floor Clearance & Hemline',
      diy: 'Dragging on carpet or revealing petticoat unpredictably when taking steps',
      geetha: 'Pre-calibrated to exact heel height; 1.0 inch floating perimeter sweep',
      icon: Footprints,
    },
    {
      aspect: 'Event Longevity & Comfort',
      diy: 'Requires 3–4 bathroom adjustments throughout dinner and dancing',
      geetha: '12-Hour Locked-Pleat Guarantee. Zero adjustments through rituals & sangeet',
      icon: Clock,
    },
  ];

  return (
    <section className="py-16 lg:py-24 bg-[#EAF1F8] border-b border-[#CBDCEE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#9E7418]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>The Science of Precision Pleating</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1A30]">
            Before & After: The Geetha Transformation
          </h2>
          <p className="text-base text-[#384F6B] leading-relaxed">
            A saree is only as magnificent as its drape. See how our structural pleat engineering transforms six yards of silk into effortless royalty.
          </p>

          {/* Interactive Toggle */}
          <div className="inline-flex p-1 bg-[#D5E4F3] rounded-lg mt-2">
            <button
              onClick={() => setActiveTab('comparison')}
              className={`px-4 py-2 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                activeTab === 'comparison'
                  ? 'bg-[#0D2444] text-[#F0F6FC] shadow-xs'
                  : 'text-[#486382] hover:text-[#0B1A30]'
              }`}
            >
              Side-by-Side Comparison
            </button>
            <button
              onClick={() => setActiveTab('detailed')}
              className={`px-4 py-2 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                activeTab === 'detailed'
                  ? 'bg-[#0D2444] text-[#F0F6FC] shadow-xs'
                  : 'text-[#486382] hover:text-[#0B1A30]'
              }`}
            >
              Technical Specifications
            </button>
          </div>
        </div>

        {/* Tab 1: Side by Side Cards */}
        {activeTab === 'comparison' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
            
            {/* Left: Standard DIY Draping */}
            <div className="bg-white rounded-xl border border-[#CBDCEE] p-6 sm:p-8 space-y-6 shadow-xs relative">
              <div className="space-y-1 border-b border-[#E1ECF7] pb-4">
                <span className="text-xs uppercase tracking-wider font-semibold text-[#8B3B3B]">
                  Common Challenges
                </span>
                <h3 className="font-serif text-2xl font-bold text-[#2B1B1E]">
                  {BEFORE_AFTER_DATA.before.title}
                </h3>
                <p className="text-xs text-[#6B5A56]">
                  {BEFORE_AFTER_DATA.before.subtitle}
                </p>
              </div>

              <ul className="space-y-3.5 text-sm text-[#4E413E]">
                {BEFORE_AFTER_DATA.before.points.map((point, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-[#FBE9E9] text-[#9E2828] flex items-center justify-center shrink-0 mt-0.5">
                      <X className="w-3.5 h-3.5" />
                    </div>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>

              <div className="pt-4 border-t border-[#E1ECF7] text-xs text-[#7A6B68] flex items-center gap-2">
                <span className="font-medium text-[#9E2828]">Average re-adjustment:</span>
                <span>3 to 5 times per event</span>
              </div>
            </div>

            {/* Right: Geetha Couture Drape */}
            <div className="bg-gradient-to-br from-[#FFFFFF] to-[#EFF5FC] rounded-xl border-2 border-[#D4AF37] p-6 sm:p-8 space-y-6 shadow-md relative">
              <div className="absolute -top-3.5 right-6 bg-[#0D2444] text-[#D4AF37] text-xs font-semibold px-3 py-1 rounded-md tracking-wider uppercase border border-[#D4AF37]/50 shadow-xs">
                Signature Standard
              </div>

              <div className="space-y-1 border-b border-[#CBDCEE] pb-4">
                <span className="text-xs uppercase tracking-wider font-semibold text-[#9E7418]">
                  Precision Engineering
                </span>
                <h3 className="font-serif text-2xl font-bold text-[#0B1A30]">
                  {BEFORE_AFTER_DATA.after.title}
                </h3>
                <p className="text-xs text-[#486282]">
                  {BEFORE_AFTER_DATA.after.subtitle}
                </p>
              </div>

              <ul className="space-y-3.5 text-sm text-[#253A52]">
                {BEFORE_AFTER_DATA.after.points.map((point, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-[#E5F5E9] text-[#1E562A] flex items-center justify-center shrink-0 mt-0.5 font-bold">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                    <span className="font-medium">{point}</span>
                  </li>
                ))}
              </ul>

              <div className="pt-4 border-t border-[#CBDCEE] text-xs text-[#0D2444] flex items-center justify-between">
                <div className="flex items-center gap-1.5 font-semibold">
                  <ShieldCheck className="w-4 h-4 text-[#9E7418]" />
                  <span>100% Zero-Sag Guarantee</span>
                </div>
                <span className="text-[#876E1A] font-semibold">12-Hour Durability</span>
              </div>
            </div>

          </div>
        )}

        {/* Tab 2: Detailed Technical Comparison Matrix */}
        {activeTab === 'detailed' && (
          <div className="bg-white rounded-xl border border-[#CBDCEE] overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="bg-[#DCE9F6] border-b border-[#CBDCEE] text-xs uppercase tracking-wider text-[#142C4E]">
                    <th className="py-4 px-6 font-semibold">Drape Attribute</th>
                    <th className="py-4 px-6 font-semibold text-[#8B3B3B]">Casual DIY Draping</th>
                    <th className="py-4 px-6 font-semibold text-[#0D2444] bg-[#C8DEFA]">Geetha Master Drape</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E3EDF7]">
                  {comparisonFeatures.map((item, idx) => {
                    const IconComponent = item.icon;
                    return (
                      <tr key={idx} className="hover:bg-[#F2F7FC] transition-colors">
                        <td className="py-4 px-6 font-semibold text-[#0B1A30] flex items-center gap-2.5">
                          <IconComponent className="w-4 h-4 text-[#9E7418] shrink-0" />
                          <span>{item.aspect}</span>
                        </td>
                        <td className="py-4 px-6 text-[#5B6D82] text-xs sm:text-sm">
                          {item.diy}
                        </td>
                        <td className="py-4 px-6 font-medium text-[#1E562A] bg-[#EFF5FB] text-xs sm:text-sm">
                          {item.geetha}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
