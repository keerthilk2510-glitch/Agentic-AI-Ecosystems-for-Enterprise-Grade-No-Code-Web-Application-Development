import React, { useState } from 'react';
import { LOOKBOOK_ITEMS } from '../data/drapingData';
import { LookbookItem } from '../types';
import { Sparkles, Filter, Search, ArrowRight, Eye } from 'lucide-react';

interface LookbookGalleryProps {
  onSelectLookForBooking: (styleId: string) => void;
}

export const LookbookGallery: React.FC<LookbookGalleryProps> = ({ onSelectLookForBooking }) => {
  const [selectedOccasion, setSelectedOccasion] = useState<string>('All');
  const [selectedFabric, setSelectedFabric] = useState<string>('All');
  const [selectedComplexity, setSelectedComplexity] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeItemModal, setActiveItemModal] = useState<LookbookItem | null>(null);

  const occasionOptions: string[] = ['All', 'Bridal', 'Reception & Sangeet', 'Festive & Puja', 'Cocktail & Party'];
  const fabricOptions: string[] = ['All', 'Kanjeevaram / Banarasi Silk', 'Organza & Tissue', 'Georgette & Chiffon'];
  const complexityOptions: string[] = ['All', 'Classic Heritage', 'Modern / Fusion', 'Royal Traditional'];

  const filteredItems = LOOKBOOK_ITEMS.filter((item) => {
    const matchesOccasion = selectedOccasion === 'All' || item.occasion === selectedOccasion;
    const matchesFabric = selectedFabric === 'All' || item.fabric === selectedFabric;
    const matchesComplexity = selectedComplexity === 'All' || item.complexity === selectedComplexity;
    const matchesSearch = searchQuery === '' || 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.fabric.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesOccasion && matchesFabric && matchesComplexity && matchesSearch;
  });

  return (
    <section id="lookbook" className="py-16 lg:py-24 bg-[#EAF1F8] border-b border-[#CBDCEE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#9E7418]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Geetha Saree Draping Portfolio</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1A30]">
            The Draping Lookbook
          </h2>
          <p className="text-base text-[#384F6B] leading-relaxed">
            Explore real transformations styled by Geetha. Featuring Wedding Bridal (₹3,000), Kerala Style (₹2,500), Bharatanatyam Classical Dance (₹4,000), Indian Saree (₹2,000), and Kacha Style (₹4,000). Starting from ₹700.
          </p>
        </div>

        {/* Filter Controls Bar */}
        <div className="bg-white rounded-xl border border-[#CBDCEE] p-4 sm:p-6 mb-8 space-y-4 shadow-xs">
          
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            {/* Search Input */}
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-[#607D9F] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search by fabric, drape, or style keyword..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-[#F0F5FA] border border-[#CBDCEE] rounded-lg text-xs text-[#0B1A30] placeholder-[#607D9F] focus:outline-none focus:border-[#183760] transition-colors"
              />
            </div>

            {/* Total Results Counter */}
            <div className="text-xs text-[#475E7B] font-medium self-end md:self-auto">
              Showing <span className="font-semibold text-[#0B1A30]">{filteredItems.length}</span> signature looks
            </div>
          </div>

          {/* Filter Dropdowns / Pills */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-[#E1EDFA]">
            
            {/* Occasion Filter */}
            <div>
              <label className="block text-[11px] font-semibold text-[#384F6B] uppercase tracking-wider mb-1">
                Occasion
              </label>
              <select
                value={selectedOccasion}
                onChange={(e) => setSelectedOccasion(e.target.value)}
                className="w-full px-3 py-2 bg-[#F0F5FA] border border-[#CBDCEE] rounded-lg text-xs text-[#0B1A30] focus:outline-none focus:border-[#183760]"
              >
                {occasionOptions.map((occ) => (
                  <option key={occ} value={occ}>{occ}</option>
                ))}
              </select>
            </div>

            {/* Fabric Filter */}
            <div>
              <label className="block text-[11px] font-semibold text-[#384F6B] uppercase tracking-wider mb-1">
                Saree Fabric
              </label>
              <select
                value={selectedFabric}
                onChange={(e) => setSelectedFabric(e.target.value)}
                className="w-full px-3 py-2 bg-[#F0F5FA] border border-[#CBDCEE] rounded-lg text-xs text-[#0B1A30] focus:outline-none focus:border-[#183760]"
              >
                {fabricOptions.map((fab) => (
                  <option key={fab} value={fab}>{fab}</option>
                ))}
              </select>
            </div>

            {/* Complexity Filter */}
            <div>
              <label className="block text-[11px] font-semibold text-[#384F6B] uppercase tracking-wider mb-1">
                Drape Complexity
              </label>
              <select
                value={selectedComplexity}
                onChange={(e) => setSelectedComplexity(e.target.value)}
                className="w-full px-3 py-2 bg-[#F0F5FA] border border-[#CBDCEE] rounded-lg text-xs text-[#0B1A30] focus:outline-none focus:border-[#183760]"
              >
                {complexityOptions.map((comp) => (
                  <option key={comp} value={comp}>{comp}</option>
                ))}
              </select>
            </div>

          </div>

          {/* Active filter reset button if filtered */}
          {(selectedOccasion !== 'All' || selectedFabric !== 'All' || selectedComplexity !== 'All' || searchQuery !== '') && (
            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-[#556F8C]">Filters applied</span>
              <button
                onClick={() => {
                  setSelectedOccasion('All');
                  setSelectedFabric('All');
                  setSelectedComplexity('All');
                  setSearchQuery('');
                }}
                className="text-[#183760] hover:underline font-semibold cursor-pointer"
              >
                Reset All Filters
              </button>
            </div>
          )}

        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((look) => (
            <div
              key={look.id}
              className="bg-white rounded-xl border border-[#CBDCEE] overflow-hidden shadow-xs hover:shadow-md hover:border-[#1E467B] transition-all flex flex-col group"
            >
              {/* Image Showcase */}
              <div className="relative aspect-[4/3] bg-[#E2EDFA] overflow-hidden">
                <img
                  src={look.image}
                  alt={look.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                />

                <div className="absolute top-3 left-3 bg-[#0B1A30]/90 text-[#FDFBF7] text-[11px] font-semibold px-2.5 py-1 rounded-md backdrop-blur-xs">
                  {look.occasion}
                </div>

                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-[11px] text-white bg-black/60 backdrop-blur-xs px-2.5 py-1 rounded-md">
                  <span className="truncate">{look.fabric}</span>
                  <span className="text-[#D4AF37] font-medium">{look.complexity}</span>
                </div>
              </div>

              {/* Card Meta */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-1.5">
                  <h3 className="font-serif text-lg font-bold text-[#0B1A30] group-hover:text-[#183760] transition-colors">
                    {look.title}
                  </h3>
                  <p className="text-xs text-[#475E7B] line-clamp-2 leading-relaxed">
                    {look.description}
                  </p>
                </div>

                {/* Technical styling detail */}
                <div className="text-[11px] text-[#334A65] bg-[#F0F5FA] p-2.5 rounded-md border border-[#CBDCEE] space-y-1">
                  <div>
                    <span className="font-semibold text-[#0B1A30]">Pallu: </span>
                    <span>{look.palluStyle}</span>
                  </div>
                </div>

                {/* Action buttons */}
                <div className="flex items-center justify-between gap-3 pt-2 border-t border-[#E1EDFA]">
                  <button
                    onClick={() => setActiveItemModal(look)}
                    className="text-xs font-semibold text-[#183760] hover:text-[#0B1A30] flex items-center gap-1 cursor-pointer py-1"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Quick Look</span>
                  </button>

                  <button
                    onClick={() => onSelectLookForBooking(look.styleId)}
                    className="px-3.5 py-1.5 text-xs font-semibold text-white bg-[#0D2444] hover:bg-[#07162B] rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs whitespace-nowrap border border-[#1B3E6E]"
                  >
                    <span>Book Drape</span>
                    <ArrowRight className="w-3 h-3 text-[#D4AF37]" />
                  </button>
                </div>
              </div>

            </div>
          ))}
        </div>

        {/* Empty state if nothing matches */}
        {filteredItems.length === 0 && (
          <div className="text-center py-12 bg-white rounded-xl border border-[#CBDCEE] p-8 space-y-3">
            <Filter className="w-8 h-8 text-[#9E7418] mx-auto opacity-60" />
            <h3 className="font-serif text-xl font-bold text-[#0B1A30]">No Looks Match This Filter</h3>
            <p className="text-xs text-[#475E7B] max-w-sm mx-auto">
              Try adjusting your occasion, fabric selection, or search keywords to view our complete draping gallery.
            </p>
            <button
              onClick={() => {
                setSelectedOccasion('All');
                setSelectedFabric('All');
                setSelectedComplexity('All');
                setSearchQuery('');
              }}
              className="px-4 py-2 bg-[#0D2444] text-white rounded-lg text-xs font-semibold cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}

        {/* Lookbook Detail Modal */}
        {activeItemModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-150">
            <div className="bg-[#F8FAFD] rounded-xl border border-[#CBDCEE] max-w-xl w-full p-6 space-y-5 shadow-2xl relative max-h-[90vh] overflow-y-auto">
              
              <div className="relative aspect-[16/10] bg-[#E2EDFA] rounded-lg overflow-hidden border border-[#CBDCEE]">
                <img
                  src={activeItemModal.image}
                  alt={activeItemModal.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center"
                />
              </div>

              <div className="space-y-1">
                <div className="text-xs font-semibold text-[#9E7418] uppercase tracking-wider">
                  {activeItemModal.occasion} · {activeItemModal.complexity}
                </div>
                <h3 className="font-serif text-2xl font-bold text-[#0B1A30]">
                  {activeItemModal.title}
                </h3>
              </div>

              <p className="text-sm text-[#384F6B] leading-relaxed">
                {activeItemModal.description}
              </p>

              <div className="bg-[#EDF4FB] p-4 rounded-lg border border-[#CBDCEE] space-y-2 text-xs">
                <div>
                  <span className="font-semibold text-[#0B1A30]">Fabric Specification: </span>
                  <span className="text-[#384F6B]">{activeItemModal.fabric}</span>
                </div>
                <div>
                  <span className="font-semibold text-[#0B1A30]">Pallu Placement: </span>
                  <span className="text-[#384F6B]">{activeItemModal.palluStyle}</span>
                </div>
                <div>
                  <span className="font-semibold text-[#0B1A30]">Pleat Engineering: </span>
                  <span className="text-[#384F6B]">{activeItemModal.pleatDetails}</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#CBDCEE]">
                <button
                  onClick={() => setActiveItemModal(null)}
                  className="px-4 py-2 text-xs font-semibold text-[#475E7B] hover:text-[#0B1A30] cursor-pointer"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    const styleId = activeItemModal.styleId;
                    setActiveItemModal(null);
                    onSelectLookForBooking(styleId);
                  }}
                  className="px-5 py-2.5 text-xs font-semibold text-white bg-[#0D2444] hover:bg-[#07162B] rounded-lg shadow-sm flex items-center gap-2 cursor-pointer border border-[#1B3E6E]"
                >
                  <span>Book This Look</span>
                  <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
                </button>
              </div>

            </div>
          </div>
        )}

      </div>
    </section>
  );
};
