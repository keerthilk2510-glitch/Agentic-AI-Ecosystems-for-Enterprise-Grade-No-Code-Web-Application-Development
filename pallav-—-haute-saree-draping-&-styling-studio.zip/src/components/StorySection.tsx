import React from 'react';
import { Sparkles, Heart, ShieldCheck, Compass, MapPin, Phone } from 'lucide-react';
import { STUDIO_INFO } from '../data/drapingData';

export const StorySection: React.FC = () => {
  return (
    <section id="craft" className="py-16 lg:py-24 bg-[#EAF1F8] border-b border-[#CBDCEE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          {/* Left Column: Brand Story */}
          <div className="lg:col-span-7 space-y-6">
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#9E7418]">
                <Sparkles className="w-3.5 h-3.5" />
                <span>About Geetha Saree Draping</span>
              </div>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1A30]">
                Meet Master Draper Geetha
              </h2>
              <p className="text-base text-[#384F6B] leading-relaxed">
                With over 15 years of dedicated artistry, Geetha transforms the sacred six and nine yards into effortless royalty for brides, classical dancers, and festive wearers.
              </p>
            </div>

            <div className="space-y-4 text-sm text-[#334A65] leading-relaxed">
              <p>
                Located on <strong className="text-[#0B1A30]">Vittasandra Main Road (near Keerthi Chicken Center), Bangalore South</strong>, Geetha specializes in authentic regional drapes and high-precision event styling.
              </p>
              <p>
                From classical <strong className="text-[#0B1A30]">Bharatanatyam stage drapes (₹4,000)</strong> that endure energetic footwork and arangetram performances, to traditional <strong className="text-[#0B1A30]">Kacha/Madisar drapes (₹4,000)</strong> and pristine <strong className="text-[#0B1A30]">Kerala Kasavu sarees (₹2,500)</strong>, Geetha’s draping technique ensures you feel weightless, elegant, and secure all day.
              </p>
              <p>
                For brides, our <strong className="text-[#0B1A30]">Wedding Bridal Saree Draping (₹3,000)</strong> locks heavy Kanjeevarams and Banarasi zari sarees into place for 12+ hours with zero slippage or pin strain. Saree draping <strong className="text-[#1E562A]">starts from just ₹1,500</strong>!
              </p>
            </div>

            {/* Core Values / Commitments */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <div className="bg-white p-4 rounded-xl border border-[#CBDCEE] space-y-1.5 shadow-xs">
                <Heart className="w-5 h-5 text-[#9E7418]" />
                <h4 className="font-serif text-base font-bold text-[#0B1A30]">Dance Stage Hold</h4>
                <p className="text-[11px] text-[#475E7B] leading-normal">
                  Arangetram-grade anchors tested for dynamic stage movements and postures.
                </p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-[#CBDCEE] space-y-1.5 shadow-xs">
                <ShieldCheck className="w-5 h-5 text-[#1E562A]" />
                <h4 className="font-serif text-base font-bold text-[#0B1A30]">100% Zari Protection</h4>
                <p className="text-[11px] text-[#475E7B] leading-normal">
                  Silicone-beaded Japanese pins that never rip, pull or damage pure gold threads.
                </p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-[#CBDCEE] space-y-1.5 shadow-xs">
                <Compass className="w-5 h-5 text-[#9E7418]" />
                <h4 className="font-serif text-base font-bold text-[#0B1A30]">Bangalore South</h4>
                <p className="text-[11px] text-[#475E7B] leading-normal">
                  Vittasandra Main Road studio + on-site mandapam visits across Bangalore.
                </p>
              </div>
            </div>

          </div>

          {/* Right Column: Rates & Studio Info Box */}
          <div className="lg:col-span-5">
            <div className="bg-white rounded-2xl border-2 border-[#D4AF37]/60 p-6 sm:p-8 space-y-6 shadow-md">
              <div className="flex items-center justify-between border-b border-[#E1EDFA] pb-3">
                <h3 className="font-serif text-2xl font-bold text-[#0B1A30]">
                  Styling Rates & Studio
                </h3>
                <span className="text-xs font-bold text-[#1E562A] bg-[#EAF5EC] px-2.5 py-0.5 rounded">
                  Starts from ₹1,500
                </span>
              </div>

              <div className="space-y-3.5 text-xs text-[#384F6B]">
                <div className="flex items-center justify-between border-b border-[#EAF2FA] pb-2">
                  <div>
                    <span className="font-bold text-[#0B1A30] block">Party & Festive Saree Draping</span>
                    <span className="text-[11px] text-[#556F8C]">Neat 15-min pleats for guests & celebrations</span>
                  </div>
                  <span className="font-serif text-lg font-bold text-[#1E562A] tabular-nums">From ₹1,500</span>
                </div>

                <div className="flex items-center justify-between border-b border-[#EAF2FA] pb-2">
                  <div>
                    <span className="font-bold text-[#0B1A30] block">Indian Saree Draping</span>
                    <span className="text-[11px] text-[#556F8C]">Classic Nivi, Reception & Sangeet styling</span>
                  </div>
                  <span className="font-serif text-lg font-bold text-[#0D2444] tabular-nums">₹2,000</span>
                </div>

                <div className="flex items-center justify-between border-b border-[#EAF2FA] pb-2">
                  <div>
                    <span className="font-bold text-[#0B1A30] block">Kerala Style Saree Draping</span>
                    <span className="text-[11px] text-[#556F8C]">Kasavu & Set Mundu with Kara symmetry</span>
                  </div>
                  <span className="font-serif text-lg font-bold text-[#0D2444] tabular-nums">₹2,500</span>
                </div>

                <div className="flex items-center justify-between border-b border-[#EAF2FA] pb-2">
                  <div>
                    <span className="font-bold text-[#0B1A30] block">Wedding Bridal Saree Draping</span>
                    <span className="text-[11px] text-[#556F8C]">12-hour locked pleats, veil setting & touch-up kit</span>
                  </div>
                  <span className="font-serif text-lg font-bold text-[#0D2444] tabular-nums">₹3,000</span>
                </div>

                <div className="flex items-center justify-between border-b border-[#EAF2FA] pb-2">
                  <div>
                    <span className="font-bold text-[#0B1A30] block">Bharatanatyam Dance Drape</span>
                    <span className="text-[11px] text-[#556F8C]">Fan pleats & pyjama katcham stage stability</span>
                  </div>
                  <span className="font-serif text-lg font-bold text-[#0D2444] tabular-nums">₹4,000</span>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-bold text-[#0B1A30] block">Kacha Saree Style Draping</span>
                    <span className="text-[11px] text-[#556F8C]">Traditional Dhoti, 9-yard Madisar & Nauvari</span>
                  </div>
                  <span className="font-serif text-lg font-bold text-[#0D2444] tabular-nums">₹4,000</span>
                </div>
              </div>

              {/* Studio Location Card */}
              <div className="bg-[#EDF4FB] p-4 rounded-xl border border-[#CBDCEE] text-xs text-[#334A65] space-y-1.5">
                <div className="flex items-center gap-1.5 font-bold text-[#0B1A30]">
                  <MapPin className="w-3.5 h-3.5 text-[#9E7418]" />
                  <span>{STUDIO_INFO.fullAddress}</span>
                </div>
                <div className="flex items-center gap-1.5 font-bold text-[#1E562A]">
                  <Phone className="w-3.5 h-3.5" />
                  <a href={`tel:${STUDIO_INFO.phone}`} className="hover:underline">
                    Call: {STUDIO_INFO.phone}
                  </a>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
