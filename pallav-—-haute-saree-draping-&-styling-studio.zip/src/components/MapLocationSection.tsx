import React from 'react';
import { MapPin, Phone, MessageCircle, Navigation, Clock, ShieldCheck, Sparkles, ExternalLink } from 'lucide-react';
import { STUDIO_INFO } from '../data/drapingData';

interface MapLocationSectionProps {
  onOpenBooking: () => void;
}

export const MapLocationSection: React.FC<MapLocationSectionProps> = ({ onOpenBooking }) => {
  return (
    <section id="location" className="py-16 lg:py-24 bg-[#EAF1F8] border-b border-[#CBDCEE] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#9E7418]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Studio Location & Contact</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1A30]">
            Visit Geetha Saree Draping Studio
          </h2>
          <p className="text-base text-[#384F6B] leading-relaxed">
            Located conveniently on <strong className="text-[#0B1A30]">Vittasandra Main Road</strong>, near <strong className="text-[#0B1A30]">Keerthi Chicken Center</strong>, Bangalore South. We provide private in-studio styling and on-site visits across Bangalore.
          </p>
        </div>

        {/* Live Location Grid: Map + Contact Details Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left Column: Live Google Map Embed */}
          <div className="lg:col-span-7 flex flex-col">
            <div className="bg-white rounded-2xl border-2 border-[#183760]/30 overflow-hidden shadow-lg flex-1 flex flex-col min-h-[380px] sm:min-h-[440px] relative">
              
              {/* Map Header Bar */}
              <div className="bg-[#0B1A30] text-[#FDFBF7] px-4 py-2.5 text-xs flex items-center justify-between z-10">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#D4AF37]" />
                  <span className="font-semibold">Live Google Map Location</span>
                </div>
                <span className="text-[11px] text-[#CBDDF0]">Bangalore South, Karnataka</span>
              </div>

              {/* Responsive Google Maps Iframe */}
              <div className="relative w-full flex-1">
                <iframe
                  title="Geetha Saree Draping Live Google Map"
                  src={STUDIO_INFO.mapEmbedUrl}
                  width="100%"
                  height="100%"
                  style={{ border: 0, minHeight: '340px' }}
                  allowFullScreen={false}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full h-full"
                />

                {/* Map Floating Pin Overlay */}
                <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-md border border-[#CBDCEE] p-3 rounded-xl shadow-lg max-w-[260px] text-xs space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-[#0B1A30]">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#1E562A] inline-block animate-ping" />
                    <span>Geetha Saree Draping</span>
                  </div>
                  <p className="text-[11px] text-[#475E7B]">
                    Vittasandra Main Road (Near Keerthi Chicken Center)
                  </p>
                  <a
                    href={STUDIO_INFO.directionsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#183760] hover:underline pt-0.5"
                  >
                    <span>Get Live Directions</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {/* Bottom bar of map */}
              <div className="bg-[#F0F5FA] px-4 py-3 border-t border-[#CBDCEE] flex flex-wrap items-center justify-between text-xs gap-3">
                <div className="flex items-center gap-2 text-[#334A65]">
                  <Navigation className="w-3.5 h-3.5 text-[#9E7418]" />
                  <span>Landmark: Near Keerthi Chicken Center, Vittasandra Main Rd</span>
                </div>
                <a
                  href={STUDIO_INFO.directionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 bg-[#0D2444] hover:bg-[#07162B] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-xs border border-[#1B3E6E]"
                >
                  <Navigation className="w-3 h-3 text-[#D4AF37]" />
                  <span>Navigate via Google Maps</span>
                </a>
              </div>

            </div>
          </div>

          {/* Right Column: Contact Details & Quick Action Card */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            
            {/* Main Contact Card */}
            <div className="bg-white rounded-2xl border-2 border-[#D4AF37] p-6 sm:p-7 space-y-5 shadow-lg relative flex-1">
              
              <div className="space-y-1 border-b border-[#E1EDFA] pb-3">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#9E7418]">
                  Verified Studio Details
                </span>
                <h3 className="font-serif text-2xl font-bold text-[#0B1A30]">
                  Geetha Saree Draping
                </h3>
                <p className="text-xs text-[#556F8C]">
                  Bridal, Traditional & Classical Dance Specialist · Starts from ₹1,500
                </p>
              </div>

              {/* Key Contact Items */}
              <div className="space-y-3.5 text-xs text-[#384F6B]">
                
                {/* Phone Number */}
                <div className="flex items-start gap-3 bg-[#F0F5FA] p-3 rounded-xl border border-[#CBDCEE]">
                  <div className="w-9 h-9 rounded-lg bg-[#0D2444] text-[#D4AF37] flex items-center justify-center shrink-0">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-[#556F8C] uppercase tracking-wider block font-semibold">
                      Direct Phone Number (Call Geetha)
                    </span>
                    <a
                      href={`tel:${STUDIO_INFO.phone}`}
                      className="text-base font-bold text-[#0B1A30] hover:text-[#183760] transition-colors tabular-nums"
                    >
                      {STUDIO_INFO.phone}
                    </a>
                    <span className="text-[11px] text-[#1E562A] block font-medium">
                      ● Active for Calls & Instant Inquiries
                    </span>
                  </div>
                </div>

                {/* WhatsApp Booking */}
                <div className="flex items-start gap-3 bg-[#EAF5EC] p-3 rounded-xl border border-[#C5DEC8]">
                  <div className="w-9 h-9 rounded-lg bg-[#1E562A] text-white flex items-center justify-center shrink-0">
                    <MessageCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-[#1E562A] uppercase tracking-wider block font-semibold">
                      WhatsApp Booking Available
                    </span>
                    <a
                      href={`https://wa.me/${STUDIO_INFO.whatsappNumber}?text=Hello%20Geetha!%20I%20would%20like%20to%20book%20a%20saree%20draping%20session.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm font-bold text-[#1E562A] hover:underline"
                    >
                      +91 {STUDIO_INFO.phone}
                    </a>
                    <span className="text-[11px] text-[#2F6B3C] block">
                      Send your saree photos & event date for instant confirmation.
                    </span>
                  </div>
                </div>

                {/* Exact Address */}
                <div className="flex items-start gap-3 bg-[#F0F5FA] p-3 rounded-xl border border-[#CBDCEE]">
                  <div className="w-9 h-9 rounded-lg bg-[#183760] text-white flex items-center justify-center shrink-0">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-[#556F8C] uppercase tracking-wider block font-semibold">
                      Studio Address
                    </span>
                    <p className="text-xs font-semibold text-[#0B1A30] leading-snug">
                      {STUDIO_INFO.addressLine1}
                    </p>
                    <p className="text-xs text-[#183760] font-bold">
                      {STUDIO_INFO.landmark}
                    </p>
                    <p className="text-xs text-[#475E7B]">
                      {STUDIO_INFO.locality}, {STUDIO_INFO.state} – {STUDIO_INFO.pincode}
                    </p>
                  </div>
                </div>

                {/* Timings */}
                <div className="flex items-start gap-3 bg-[#F0F5FA] p-3 rounded-xl border border-[#CBDCEE]">
                  <div className="w-9 h-9 rounded-lg bg-[#0D2444] text-[#D4AF37] flex items-center justify-center shrink-0">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-[#556F8C] uppercase tracking-wider block font-semibold">
                      Studio Working Hours
                    </span>
                    <span className="text-xs font-semibold text-[#0B1A30]">
                      Monday – Sunday: 05:30 AM – 09:30 PM
                    </span>
                    <span className="text-[11px] text-[#556F8C] block">
                      Early morning Muhurtham & arangetram slots available on appointment.
                    </span>
                  </div>
                </div>

              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <a
                  href={`tel:${STUDIO_INFO.phone}`}
                  className="py-3 px-4 bg-[#0D2444] hover:bg-[#07162B] text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-2 shadow-sm transition-colors text-center border border-[#1B3E6E]"
                >
                  <Phone className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Call 8050566063</span>
                </a>

                <a
                  href={`https://wa.me/${STUDIO_INFO.whatsappNumber}?text=Hello%20Geetha!%20I%20would%20like%20to%20book%20saree%20draping.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-3 px-4 bg-[#1E562A] hover:bg-[#164420] text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-2 shadow-sm transition-colors text-center"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp Booking</span>
                </a>
              </div>

            </div>

            {/* Bangalore South Service Coverage */}
            <div className="bg-[#EDF4FB] rounded-xl border border-[#CBDCEE] p-4 text-xs text-[#384F6B] space-y-1.5">
              <div className="flex items-center gap-2 font-bold text-[#0B1A30]">
                <ShieldCheck className="w-4 h-4 text-[#1E562A]" />
                <span>On-Site Mandapam & Home Visits Across Bangalore:</span>
              </div>
              <p className="text-[11px] text-[#475E7B]">
                We travel to wedding halls and homes in Vittasandra, Electronic City Phase 1 & 2, Begur, Hosa Road, Singasandra, Bommanahalli, HSR Layout, Koramangala, and all of Bangalore South.
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
