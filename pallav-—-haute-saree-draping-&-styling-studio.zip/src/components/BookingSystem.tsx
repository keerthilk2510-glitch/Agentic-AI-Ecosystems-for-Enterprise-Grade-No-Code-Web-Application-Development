import React, { useState, useEffect } from 'react';
import { SERVICE_PACKAGES, DRAPING_STYLES } from '../data/drapingData';
import { saveAppointment, AppointmentRecord } from '../lib/supabase';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  MapPin, 
  User, 
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft, 
  Sparkles, 
  ShieldCheck, 
  MessageCircle,
  Copy,
  Check,
  Database,
  Loader2
} from 'lucide-react';

interface BookingSystemProps {
  initialServiceId?: string;
  initialStyleId?: string;
  onClose?: () => void;
  onOpenAdminBookings?: () => void;
}

export const BookingSystem: React.FC<BookingSystemProps> = ({ 
  initialServiceId, 
  initialStyleId,
  onClose,
  onOpenAdminBookings
}) => {
  const [step, setStep] = useState<number>(1);
  const [serviceId, setServiceId] = useState<string>(initialServiceId || SERVICE_PACKAGES[0].id);
  const [styleId, setStyleId] = useState<string>(initialStyleId || DRAPING_STYLES[0].id);
  const [date, setDate] = useState<string>('2026-10-18');
  const [timeSlot, setTimeSlot] = useState<string>('08:30 AM');
  const [locationType, setLocationType] = useState<'studio' | 'onsite'>('onsite');
  const [address, setAddress] = useState<string>('Vittasandra Main Road, near Keerthi Chicken Center');
  const [cityArea, setCityArea] = useState<string>('Bangalore South, Karnataka');
  const [guestCount, setGuestCount] = useState<number>(1);
  const [clientName, setClientName] = useState<string>('Keerthi Lakshmi');
  const [email, setEmail] = useState<string>('keerthi@example.com');
  const [phone, setPhone] = useState<string>('8050566063');
  const [sareeFabric, setSareeFabric] = useState<string>('Heavy Kanjeevaram Silk with Gold Zari');
  const [sareeLength, setSareeLength] = useState<string>('6 meters (standard bridal)');
  const [heightFootwear, setHeightFootwear] = useState<string>("5 ft 5 in with 2.5-inch heels");
  const [specialNotes, setSpecialNotes] = useState<string>('Muhurtham ritual at 10:00 AM. Need pleats set by 9:15 AM sharp.');
  const [includePrePleating, setIncludePrePleating] = useState<boolean>(true);
  const [isConfirmed, setIsConfirmed] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [supabaseSaved, setSupabaseSaved] = useState<boolean>(false);
  const [bookingRef, setBookingRef] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    if (initialServiceId) setServiceId(initialServiceId);
    if (initialStyleId) setStyleId(initialStyleId);
  }, [initialServiceId, initialStyleId]);

  const selectedService = SERVICE_PACKAGES.find(s => s.id === serviceId) || SERVICE_PACKAGES[0];
  const selectedStyle = DRAPING_STYLES.find(s => s.id === styleId) || DRAPING_STYLES[0];

  // Pricing calculation in Rupees (INR)
  const basePriceINR = selectedService.priceINR * (serviceId === 'basic-guest-draping' ? guestCount : 1);
  const travelFeeINR = locationType === 'onsite' ? 300 : 0;
  const prePleatFeeINR = includePrePleating ? 350 : 0;
  const totalPriceINR = basePriceINR + travelFeeINR + prePleatFeeINR;
  const advanceDepositINR = Math.round(totalPriceINR * 0.3); // 30% advance deposit

  const timeSlots = [
    { label: 'Early Muhurtham / Temple Slot (05:30 AM - 07:00 AM)', value: '06:00 AM' },
    { label: 'Morning Ritual Slot (08:00 AM - 09:30 AM)', value: '08:30 AM' },
    { label: 'Mid-Morning / Reception Slot (10:30 AM - 12:00 PM)', value: '10:30 AM' },
    { label: 'Afternoon Arangetram / Prep Slot (02:00 PM - 03:30 PM)', value: '02:00 PM' },
    { label: 'Evening Sangeet / Stage Slot (04:30 PM - 06:00 PM)', value: '04:30 PM' },
    { label: 'Night Reception Slot (06:30 PM - 08:00 PM)', value: '06:30 PM' },
  ];

  const handleConfirmBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const ref = `GEETHA-${Math.floor(100000 + Math.random() * 900000)}`;
    setBookingRef(ref);

    const appointmentPayload: AppointmentRecord = {
      booking_ref: ref,
      service_id: serviceId,
      service_name: selectedService.name,
      style_id: styleId,
      style_name: selectedStyle.name,
      date,
      time_slot: timeSlot,
      location_type: locationType,
      address: locationType === 'onsite' ? address : 'Geetha Studio, Vittasandra Main Road',
      city_area: cityArea,
      guest_count: guestCount,
      client_name: clientName,
      email,
      phone,
      saree_fabric: sareeFabric,
      saree_length: sareeLength,
      height_footwear: heightFootwear,
      special_notes: specialNotes,
      include_pre_pleating: includePrePleating,
      total_price: totalPriceINR,
      advance_deposit: advanceDepositINR,
      status: 'confirmed',
    };

    // Save to Supabase backend
    const result = await saveAppointment(appointmentPayload);
    setSupabaseSaved(result.success);
    setIsSubmitting(false);
    setIsConfirmed(true);
  };

  const copyBookingDetails = () => {
    const text = `Geetha Saree Draping Confirmation: ${bookingRef}\nService: ${selectedService.name}\nStyle: ${selectedStyle.name}\nDate: ${date} at ${timeSlot}\nLocation: ${locationType === 'onsite' ? address : 'Geetha Studio, Vittasandra Main Road'}\nClient: ${clientName} (${phone})\nTotal: ₹${totalPriceINR} (30% Deposit: ₹${advanceDepositINR})`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const whatsappMessage = encodeURIComponent(
    `Hello Geetha Saree Draping! I have submitted appointment ref ${bookingRef} for ${selectedService.name} (${selectedStyle.name}) on ${date} at ${timeSlot}. Total: ₹${totalPriceINR}. Looking forward to our session at Vittasandra Main Road!`
  );

  return (
    <div id="booking" className="py-16 lg:py-24 bg-[#EAF1F8] border-b border-[#CBDCEE]">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-10">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#9E7418]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Geetha Saree Draping Reservation</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1A30]">
            Book Your Saree Draping Session
          </h2>
          <p className="text-xs sm:text-sm text-[#384F6B] leading-relaxed">
            Specialist in Wedding Bridal (₹3,000), Kerala Style (₹2,500), Bharatanatyam (₹4,000), Indian Saree (₹2,000), and Kacha Saree Style (₹4,000). Starts from ₹1,500!
          </p>
        </div>

        {/* Booking Card */}
        <div className="bg-white rounded-2xl border border-[#CBDCEE] shadow-lg overflow-hidden">
          
          {/* Step Progress Bar */}
          {!isConfirmed && (
            <div className="bg-[#DCE8F5] border-b border-[#CBDCEE] px-6 py-4">
              <div className="flex items-center justify-between max-w-2xl mx-auto text-xs font-semibold">
                {[
                  { num: 1, label: 'Service' },
                  { num: 2, label: 'Style' },
                  { num: 3, label: 'Date & Time' },
                  { num: 4, label: 'Location' },
                  { num: 5, label: 'Review & Pay' },
                ].map((s) => (
                  <div key={s.num} className="flex items-center gap-2">
                    <span 
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                        step === s.num
                          ? 'bg-[#0D2444] text-[#FDFBF7]'
                          : step > s.num
                          ? 'bg-[#1E562A] text-white'
                          : 'bg-[#C5D8EC] text-[#475E7B]'
                      }`}
                    >
                      {step > s.num ? '✓' : s.num}
                    </span>
                    <span className={`hidden sm:inline ${step === s.num ? 'text-[#0B1A30]' : 'text-[#556F8C]'}`}>
                      {s.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Form Content */}
          <div className="p-6 sm:p-10">
            
            {/* STEP 1: Select Service */}
            {!isConfirmed && step === 1 && (
              <div className="space-y-6">
                <div className="space-y-1">
                  <h3 className="font-serif text-2xl font-bold text-[#2B0F12]">
                    1. Select Saree Draping Service
                  </h3>
                  <p className="text-xs text-[#6B5752]">
                    Choose the styling service that suits your celebration.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {SERVICE_PACKAGES.map((pkg) => (
                    <div
                      key={pkg.id}
                      onClick={() => setServiceId(pkg.id)}
                      className={`p-5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
                        serviceId === pkg.id
                          ? 'bg-[#FBF7EE] border-[#3A1518] shadow-sm ring-1 ring-[#3A1518]'
                          : 'bg-white border-[#E0D3C1] hover:border-[#9E7418]'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] uppercase tracking-wider font-semibold text-[#9E7418]">
                            {pkg.badge}
                          </span>
                          <span className="font-serif text-xl font-bold text-[#3A1518] tabular-nums">
                            ₹{pkg.priceINR.toLocaleString('en-IN')}
                          </span>
                        </div>
                        <h4 className="font-serif text-lg font-bold text-[#2B0F12]">
                          {pkg.name}
                        </h4>
                        <p className="text-xs text-[#5E4C48] line-clamp-2">
                          {pkg.tagline}
                        </p>
                      </div>

                      <div className="flex items-center justify-between text-xs text-[#7A6763] pt-2 border-t border-[#EFE5D5]">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-[#9E7418]" />
                          {pkg.durationMinutes} mins
                        </span>
                        <span className="text-[#3A1518] font-bold">
                          {serviceId === pkg.id ? '● Selected' : 'Select'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {serviceId === 'basic-guest-draping' && (
                  <div className="p-4 bg-[#F8F2E6] rounded-xl border border-[#DFCEB9] flex items-center justify-between">
                    <div>
                      <span className="text-xs font-semibold text-[#2B0F12] block">Number of Guests / Saree Wearers (₹700 each):</span>
                      <span className="text-[11px] text-[#695854]">Styling time is ~15 minutes per person.</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => setGuestCount(Math.max(1, guestCount - 1))}
                        className="w-8 h-8 rounded-lg bg-white border border-[#D9CBB7] text-sm font-bold text-[#3A1518] cursor-pointer"
                      >
                        -
                      </button>
                      <span className="text-sm font-bold tabular-nums text-[#3A1518]">{guestCount}</span>
                      <button
                        type="button"
                        onClick={() => setGuestCount(guestCount + 1)}
                        className="w-8 h-8 rounded-lg bg-white border border-[#D9CBB7] text-sm font-bold text-[#3A1518] cursor-pointer"
                      >
                        +
                      </button>
                    </div>
                  </div>
                )}

                <div className="flex justify-end pt-4">
                  <button
                    onClick={() => setStep(2)}
                    className="px-6 py-2.5 bg-[#3A1518] text-white text-xs sm:text-sm font-semibold rounded-lg flex items-center gap-2 cursor-pointer shadow-xs hover:bg-[#250B0D]"
                  >
                    <span>Proceed to Drape Style</span>
                    <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 2: Choose Drape Style */}
            {!isConfirmed && step === 2 && (
              <div className="space-y-6">
                <div className="space-y-1">
                  <h3 className="font-serif text-2xl font-bold text-[#2B0F12]">
                    2. Select Saree Draping Style
                  </h3>
                  <p className="text-xs text-[#6B5752]">
                    Choose the exact silhouette you wish to wear for your event.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {DRAPING_STYLES.map((style) => (
                    <div
                      key={style.id}
                      onClick={() => setStyleId(style.id)}
                      className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
                        styleId === style.id
                          ? 'bg-[#FBF7EE] border-[#3A1518] shadow-sm ring-1 ring-[#3A1518]'
                          : 'bg-white border-[#E0D3C1] hover:border-[#9E7418]'
                      }`}
                    >
                      <div className="aspect-[4/3] rounded-lg overflow-hidden bg-[#F5EFE3] mb-1 relative">
                        <img 
                          src={style.image} 
                          alt={style.name} 
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover" 
                        />
                        <div className="absolute top-2 left-2 bg-[#3A1518]/90 text-[#D4AF37] text-[10px] font-bold px-2 py-0.5 rounded">
                          ₹{style.priceINR.toLocaleString('en-IN')}
                        </div>
                      </div>
                      <div>
                        <div className="text-[10px] uppercase font-semibold text-[#9E7418]">
                          {style.region}
                        </div>
                        <h4 className="font-serif text-base font-bold text-[#2B0F12]">
                          {style.name}
                        </h4>
                        <p className="text-[11px] text-[#63514D] line-clamp-2 mt-1">
                          {style.subtitle}
                        </p>
                      </div>

                      <div className="text-[11px] text-[#7B6763] pt-2 border-t border-[#EFE5D5] flex items-center justify-between">
                        <span className="font-semibold text-[#1E562A]">₹{style.priceINR.toLocaleString('en-IN')}</span>
                        <span className="font-semibold text-[#3A1518]">
                          {styleId === style.id ? '✓ Selected' : 'Choose'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-4">
                  <button
                    onClick={() => setStep(1)}
                    className="px-4 py-2 border border-[#D9CBB7] text-xs font-semibold text-[#4F3E3A] rounded-lg flex items-center gap-1.5 cursor-pointer hover:bg-[#F8F2E6]"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>

                  <button
                    onClick={() => setStep(3)}
                    className="px-6 py-2.5 bg-[#3A1518] text-white text-xs sm:text-sm font-semibold rounded-lg flex items-center gap-2 cursor-pointer shadow-xs hover:bg-[#250B0D]"
                  >
                    <span>Proceed to Date & Slot</span>
                    <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: Date & Time Slot Picker */}
            {!isConfirmed && step === 3 && (
              <div className="space-y-6">
                <div className="space-y-1">
                  <h3 className="font-serif text-2xl font-bold text-[#2B0F12]">
                    3. Select Date & Arrival Slot
                  </h3>
                  <p className="text-xs text-[#6B5752]">
                    We recommend booking Geetha to arrive at least 1.5 to 2 hours before your photography or muhurtham time.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                  
                  {/* Date Input */}
                  <div className="md:col-span-5 space-y-4 bg-[#FBF8F1] p-5 rounded-xl border border-[#DFCEB9]">
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#3A1518]">
                      Event Date:
                    </label>
                    <input
                      type="date"
                      value={date}
                      min="2026-10-01"
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full px-3 py-2.5 bg-white border border-[#D9CBB7] rounded-lg text-sm text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                    />

                    <div className="text-[11px] text-[#786661] space-y-1 pt-2">
                      <div className="flex items-center gap-1.5 text-[#1E562A] font-semibold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Dedicated Slot Exclusivity</span>
                      </div>
                      <p>Geetha personally manages your session with zero overlapping delays.</p>
                    </div>
                  </div>

                  {/* Time Slots Radio Group */}
                  <div className="md:col-span-7 space-y-3">
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#3A1518]">
                      Available Slots on {date}:
                    </label>
                    <div className="space-y-2">
                      {timeSlots.map((slot) => (
                        <label
                          key={slot.value}
                          className={`flex items-center justify-between p-3 rounded-lg border text-xs cursor-pointer transition-all ${
                            timeSlot === slot.value
                              ? 'bg-[#FAF2E1] border-[#3A1518] font-semibold text-[#2B0F12]'
                              : 'bg-white border-[#E0D3C1] text-[#54433F] hover:border-[#9E7418]'
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <input
                              type="radio"
                              name="timeSlot"
                              checked={timeSlot === slot.value}
                              onChange={() => setTimeSlot(slot.value)}
                              className="text-[#3A1518] focus:ring-[#9E7418]"
                            />
                            <span>{slot.label}</span>
                          </div>
                          <span className="text-[#1E562A] font-bold text-[11px]">Available</span>
                        </label>
                      ))}
                    </div>
                  </div>

                </div>

                <div className="flex items-center justify-between pt-4">
                  <button
                    onClick={() => setStep(2)}
                    className="px-4 py-2 border border-[#D9CBB7] text-xs font-semibold text-[#4F3E3A] rounded-lg flex items-center gap-1.5 cursor-pointer hover:bg-[#F8F2E6]"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>

                  <button
                    onClick={() => setStep(4)}
                    className="px-6 py-2.5 bg-[#3A1518] text-white text-xs sm:text-sm font-semibold rounded-lg flex items-center gap-2 cursor-pointer shadow-xs hover:bg-[#250B0D]"
                  >
                    <span>Proceed to Location</span>
                    <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 4: Location & Logistics */}
            {!isConfirmed && step === 4 && (
              <div className="space-y-6">
                <div className="space-y-1">
                  <h3 className="font-serif text-2xl font-bold text-[#2B0F12]">
                    4. Location: Studio or On-Site Visit
                  </h3>
                  <p className="text-xs text-[#6B5752]">
                    Visit Geetha's studio or have her travel on-site to your wedding hall, stage auditorium, hotel, or home.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Studio Option */}
                  <div
                    onClick={() => setLocationType('studio')}
                    className={`p-5 rounded-xl border cursor-pointer transition-all space-y-2 ${
                      locationType === 'studio'
                        ? 'bg-[#FBF7EE] border-[#3A1518] ring-1 ring-[#3A1518]'
                        : 'bg-white border-[#E0D3C1] hover:border-[#9E7418]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs uppercase font-semibold text-[#9E7418]">No Travel Fee</span>
                      <span className="text-xs font-bold text-[#1E562A]">₹0 Extra</span>
                    </div>
                    <h4 className="font-serif text-lg font-bold text-[#2B0F12]">
                      At Geetha Saree Draping Studio
                    </h4>
                    <p className="text-xs text-[#614E4A]">
                      Vittasandra Main Road (Near Keerthi Chicken Center), Bangalore South. Private dressing suite with multi-angle mirrors & steam station.
                    </p>
                  </div>

                  {/* On-Site Concierge */}
                  <div
                    onClick={() => setLocationType('onsite')}
                    className={`p-5 rounded-xl border cursor-pointer transition-all space-y-2 ${
                      locationType === 'onsite'
                        ? 'bg-[#FBF7EE] border-[#3A1518] ring-1 ring-[#3A1518]'
                        : 'bg-white border-[#E0D3C1] hover:border-[#9E7418]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs uppercase font-semibold text-[#9E7418]">On-Site Visit</span>
                      <span className="text-xs font-bold text-[#3A1518]">+₹300 Travel Fee</span>
                    </div>
                    <h4 className="font-serif text-lg font-bold text-[#2B0F12]">
                      At Mandapam / Hotel / Home
                    </h4>
                    <p className="text-xs text-[#614E4A]">
                      Geetha travels directly to your venue with complete kit: silicone pins, magnetic cushions, and mobile steamer.
                    </p>
                  </div>
                </div>

                {locationType === 'onsite' && (
                  <div className="bg-[#FAF5EB] p-5 rounded-xl border border-[#DFCEB9] space-y-4">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-[#3A1518]">
                      On-Site Venue Details
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div className="sm:col-span-2">
                        <label className="block text-[11px] font-semibold text-[#574440] mb-1">
                          Mandapam / Hotel / Residence Address
                        </label>
                        <input
                          type="text"
                          value={address}
                          onChange={(e) => setAddress(e.target.value)}
                          placeholder="e.g., Sri Krishna Kalyana Mandapam, Room 204"
                          className="w-full px-3 py-2 bg-white border border-[#D9CBB7] rounded-lg text-xs text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-[#574440] mb-1">
                          City / Locality Area
                        </label>
                        <input
                          type="text"
                          value={cityArea}
                          onChange={(e) => setCityArea(e.target.value)}
                          placeholder="e.g., T. Nagar / Chennai"
                          className="w-full px-3 py-2 bg-white border border-[#D9CBB7] rounded-lg text-xs text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Pre-Pleating Addon Option */}
                <div className="bg-[#FFFDF9] p-4 rounded-xl border border-[#D9CBB7] flex items-center justify-between">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-[#3A1518]">Add Pre-Pleating Service (+ ₹350)</span>
                      <span className="text-[10px] bg-[#E9F3EB] text-[#1E562A] font-semibold px-2 py-0.5 rounded">Quick 10-Min Drape</span>
                    </div>
                    <p className="text-[11px] text-[#695854]">
                      We pre-crease and iron-set the waist pleats in advance for ultra-fast wear on event morning.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={includePrePleating}
                    onChange={(e) => setIncludePrePleating(e.target.checked)}
                    className="w-5 h-5 rounded text-[#3A1518] focus:ring-[#9E7418] cursor-pointer"
                  />
                </div>

                <div className="flex items-center justify-between pt-4">
                  <button
                    onClick={() => setStep(3)}
                    className="px-4 py-2 border border-[#D9CBB7] text-xs font-semibold text-[#4F3E3A] rounded-lg flex items-center gap-1.5 cursor-pointer hover:bg-[#F8F2E6]"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>

                  <button
                    onClick={() => setStep(5)}
                    className="px-6 py-2.5 bg-[#3A1518] text-white text-xs sm:text-sm font-semibold rounded-lg flex items-center gap-2 cursor-pointer shadow-xs hover:bg-[#250B0D]"
                  >
                    <span>Review & Confirm</span>
                    <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 5: Customer Details, Saree Specs & Confirmation */}
            {!isConfirmed && step === 5 && (
              <form onSubmit={handleConfirmBooking} className="space-y-6">
                <div className="space-y-1">
                  <h3 className="font-serif text-2xl font-bold text-[#2B0F12]">
                    5. Saree Specifications & Client Details
                  </h3>
                  <p className="text-xs text-[#6B5752]">
                    Finalize your booking with Geetha Saree Draping.
                  </p>
                </div>

                {/* Saree & Physique Specifications */}
                <div className="bg-[#FAF5EB] p-5 rounded-xl border border-[#DFCEB9] space-y-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#3A1518]">
                    Garment Details
                  </h4>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block text-[11px] font-semibold text-[#574440] mb-1">
                        Saree Fabric Type
                      </label>
                      <input
                        type="text"
                        value={sareeFabric}
                        onChange={(e) => setSareeFabric(e.target.value)}
                        placeholder="e.g., Pure Kanjeevaram, Kerala Kasavu, Silk Dance Saree"
                        className="w-full px-3 py-2 bg-white border border-[#D9CBB7] rounded-lg text-xs text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-[#574440] mb-1">
                        Saree Length / Cut
                      </label>
                      <select
                        value={sareeLength}
                        onChange={(e) => setSareeLength(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-[#D9CBB7] rounded-lg text-xs text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                      >
                        <option value="5.5 meters (standard)">5.5 meters (Standard saree)</option>
                        <option value="6 meters (bridal)">6.0 meters (Heavy bridal / Kanjeevaram)</option>
                        <option value="9 meters (Kacha/Madisar/Nauvari)">9.0 meters (Kacha style / Madisar / Nauvari)</option>
                        <option value="Kerala Set Mundu (Two Piece)">Kerala Set Mundu (Two Piece)</option>
                        <option value="Bharatanatyam Costume Saree">Bharatanatyam Costume Saree</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-[#574440] mb-1">
                        Client Height & Footwear
                      </label>
                      <input
                        type="text"
                        value={heightFootwear}
                        onChange={(e) => setHeightFootwear(e.target.value)}
                        placeholder="e.g., 5 ft 4 in with 2.5-inch heels"
                        className="w-full px-3 py-2 bg-white border border-[#D9CBB7] rounded-lg text-xs text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-[#574440] mb-1">
                        Special Requests (Jewelry, Belts, Veil)
                      </label>
                      <input
                        type="text"
                        value={specialNotes}
                        onChange={(e) => setSpecialNotes(e.target.value)}
                        placeholder="e.g., Oddiyanam waist belt, head veil, temple jewelry"
                        className="w-full px-3 py-2 bg-white border border-[#D9CBB7] rounded-lg text-xs text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                      />
                    </div>
                  </div>
                </div>

                {/* Client Contact Info */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-[#574440] mb-1">
                      Full Name
                    </label>
                    <input
                      type="text"
                      value={clientName}
                      onChange={(e) => setClientName(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#D9CBB7] rounded-lg text-xs text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-[#574440] mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#D9CBB7] rounded-lg text-xs text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-[#574440] mb-1">
                      Mobile / WhatsApp Number
                    </label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#D9CBB7] rounded-lg text-xs text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                      required
                    />
                  </div>
                </div>

                {/* Transparent Summary in Rupees */}
                <div className="bg-[#FAF3E4] rounded-xl border border-[#D9C5A8] p-5 space-y-3">
                  <div className="flex items-center justify-between text-xs font-semibold text-[#3A1518] border-b border-[#E8D9C0] pb-2">
                    <span>Summary of Services</span>
                    <span>Rate (INR)</span>
                  </div>

                  <div className="space-y-1.5 text-xs text-[#52413D]">
                    <div className="flex justify-between">
                      <span>{selectedService.name} ({selectedStyle.name})</span>
                      <span className="font-semibold tabular-nums">₹{basePriceINR.toLocaleString('en-IN')}</span>
                    </div>

                    {locationType === 'onsite' && (
                      <div className="flex justify-between">
                        <span>On-site Mobile Visit Fee</span>
                        <span className="font-semibold tabular-nums">₹{travelFeeINR}</span>
                      </div>
                    )}

                    {includePrePleating && (
                      <div className="flex justify-between">
                        <span>Pre-Pleating & Box-Crease Prep</span>
                        <span className="font-semibold tabular-nums">₹{prePleatFeeINR}</span>
                      </div>
                    )}

                    <div className="flex justify-between pt-2 border-t border-[#E8D9C0] font-bold text-sm text-[#2B0F12]">
                      <span>Total Service Amount</span>
                      <span className="tabular-nums">₹{totalPriceINR.toLocaleString('en-IN')}</span>
                    </div>

                    <div className="flex justify-between text-xs font-semibold text-[#1E562A] pt-1">
                      <span>30% Advance Deposit to Lock Date & Slot</span>
                      <span className="tabular-nums">₹{advanceDepositINR.toLocaleString('en-IN')}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <button
                    type="button"
                    onClick={() => setStep(4)}
                    className="px-4 py-2 border border-[#D9CBB7] text-xs font-semibold text-[#4F3E3A] rounded-lg flex items-center gap-1.5 cursor-pointer hover:bg-[#F8F2E6]"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-7 py-3 bg-[#0D2444] hover:bg-[#07162B] text-white text-xs sm:text-sm font-semibold rounded-lg flex items-center gap-2 cursor-pointer shadow-md transition-all border border-[#1B3E6E] disabled:opacity-75"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin text-[#D4AF37]" />
                        <span>Saving to Supabase Database...</span>
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
                        <span>Confirm Booking with Geetha (₹{advanceDepositINR} Advance)</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}

            {/* CONFIRMATION SCREEN */}
            {isConfirmed && (
              <div className="text-center py-6 sm:py-8 space-y-6 max-w-xl mx-auto">
                <div className="w-16 h-16 rounded-full bg-[#E5F5E9] text-[#1E562A] flex items-center justify-center mx-auto border-2 border-[#A8DBB4] shadow-sm">
                  <CheckCircle2 className="w-8 h-8" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-xs uppercase tracking-wider font-semibold text-[#9E7418]">
                      Booking Reference #{bookingRef}
                    </span>
                    <span className="text-[11px] text-[#1E562A] font-semibold bg-[#EAF5EC] px-2 py-0.5 rounded flex items-center gap-1">
                      <Database className="w-3 h-3" />
                      <span>Saved to Supabase</span>
                    </span>
                  </div>
                  <h3 className="font-serif text-3xl font-bold text-[#0B1A30]">
                    Your Saree Draping Session is Confirmed!
                  </h3>
                  <p className="text-xs sm:text-sm text-[#384F6B] leading-relaxed">
                    Thank you, <span className="font-semibold text-[#0B1A30]">{clientName}</span>. Your booking data has been stored in our Supabase backend and Geetha has reserved your slot for <span className="font-semibold text-[#0B1A30]">{date} at {timeSlot}</span>.
                  </p>
                </div>

                {/* Receipt Card */}
                <div className="bg-[#F0F5FA] p-5 rounded-xl border border-[#CBDCEE] text-left text-xs space-y-2.5">
                  <div className="flex justify-between border-b border-[#CBDCEE] pb-2 font-semibold text-[#0B1A30]">
                    <span>Geetha Saree Draping Appointment</span>
                    <button
                      onClick={copyBookingDetails}
                      className="text-[#183760] hover:underline flex items-center gap-1 cursor-pointer font-medium"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-[#1E562A]" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'Copied!' : 'Copy Summary'}</span>
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 text-[#334A65]">
                    <div>
                      <span className="font-semibold text-[#0B1A30] block">Service:</span>
                      <span>{selectedService.name}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-[#0B1A30] block">Style Selected:</span>
                      <span>{selectedStyle.name}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-[#0B1A30] block">Location:</span>
                      <span>{locationType === 'onsite' ? `${address}, ${cityArea}` : 'Geetha Studio, Vittasandra Main Rd'}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-[#0B1A30] block">Contact:</span>
                      <span>{phone}</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-[#CBDCEE] flex justify-between font-bold text-[#0B1A30]">
                    <span>Total Amount:</span>
                    <span className="tabular-nums">₹{totalPriceINR.toLocaleString('en-IN')} (Advance Deposit: ₹{advanceDepositINR})</span>
                  </div>
                </div>

                {/* Instant Actions */}
                <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                  <a
                    href={`https://wa.me/918050566063?text=${whatsappMessage}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full sm:w-auto px-5 py-2.5 bg-[#E9F3EB] hover:bg-[#D4E8D8] text-[#1E562A] border border-[#C5DEC8] font-semibold text-xs rounded-lg flex items-center justify-center gap-2"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Notify Geetha on WhatsApp (8050566063)</span>
                  </a>

                  {onOpenAdminBookings && (
                    <button
                      onClick={onOpenAdminBookings}
                      className="w-full sm:w-auto px-4 py-2.5 bg-[#E2EDFA] hover:bg-[#D4E4F5] border border-[#CBDCEE] text-[#0B1A30] font-semibold text-xs rounded-lg flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Database className="w-3.5 h-3.5 text-[#1E562A]" />
                      <span>View in Supabase Database</span>
                    </button>
                  )}

                  <button
                    onClick={() => {
                      setIsConfirmed(false);
                      setStep(1);
                    }}
                    className="w-full sm:w-auto px-4 py-2.5 bg-white border border-[#CBDCEE] text-[#334A65] font-semibold text-xs rounded-lg hover:bg-[#F0F5FA] cursor-pointer"
                  >
                    <span>Book Another Saree</span>
                  </button>
                </div>

              </div>
            )}

          </div>

        </div>

      </div>
    </div>
  );
};
