import React, { useState, useEffect } from 'react';
import { 
  AppointmentRecord, 
  fetchAppointments, 
  updateAppointment, 
  updateAppointmentStatus, 
  deleteAppointment,
  saveAppointment,
  SUPABASE_SQL_SETUP_SCRIPT
} from '../lib/supabase';
import { SERVICE_PACKAGES, DRAPING_STYLES, STUDIO_INFO } from '../data/drapingData';
import { 
  Database, 
  RefreshCw, 
  Search, 
  Filter, 
  Calendar, 
  Clock, 
  Phone, 
  MapPin, 
  User, 
  Edit3, 
  Trash2, 
  XCircle, 
  CheckCircle2, 
  AlertCircle, 
  ArrowLeft, 
  Plus, 
  Copy, 
  Check, 
  MessageCircle, 
  FileText, 
  Sparkles,
  ExternalLink,
  ChevronDown,
  Layers,
  Save,
  X
} from 'lucide-react';

interface AdminPanelProps {
  onBackToWebsite: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onBackToWebsite }) => {
  const [appointments, setAppointments] = useState<AppointmentRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [styleFilter, setStyleFilter] = useState<string>('All');
  
  // Modals
  const [editingAppointment, setEditingAppointment] = useState<AppointmentRecord | null>(null);
  const [cancellingRef, setCancellingRef] = useState<string | null>(null);
  const [cancelReason, setCancelReason] = useState<string>('Client requested cancellation');
  const [deletingRef, setDeletingRef] = useState<string | null>(null);
  const [isManualBookingOpen, setIsManualBookingOpen] = useState<boolean>(false);
  const [showSqlSetup, setShowSqlSetup] = useState<boolean>(false);
  const [copiedSql, setCopiedSql] = useState<boolean>(false);
  const [copiedSummary, setCopiedSummary] = useState<string | null>(null);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  // Manual booking form state
  const [manualClientName, setManualClientName] = useState('');
  const [manualPhone, setManualPhone] = useState('');
  const [manualServiceId, setManualServiceId] = useState(SERVICE_PACKAGES[0].id);
  const [manualStyleId, setManualStyleId] = useState(DRAPING_STYLES[0].id);
  const [manualDate, setManualDate] = useState('2026-10-20');
  const [manualTime, setManualTime] = useState('08:30 AM');
  const [manualLocation, setManualLocation] = useState<'studio' | 'onsite'>('studio');
  const [manualAddress, setManualAddress] = useState('Vittasandra Main Road Studio');
  const [manualNotes, setManualNotes] = useState('');

  const loadAppointments = async () => {
    setLoading(true);
    const data = await fetchAppointments();
    setAppointments(data);
    setLoading(false);
  };

  useEffect(() => {
    loadAppointments();
  }, []);

  const showNotification = (msg: string) => {
    setActionSuccessMsg(msg);
    setTimeout(() => setActionSuccessMsg(null), 3500);
  };

  // Status Changer
  const handleStatusChange = async (ref: string, newStatus: 'confirmed' | 'in_progress' | 'completed' | 'cancelled') => {
    const res = await updateAppointmentStatus(ref, newStatus);
    if (res.success) {
      setAppointments(prev => prev.map(a => a.booking_ref === ref ? { ...a, status: newStatus } : a));
      showNotification(`Order ${ref} status updated to "${newStatus.replace('_', ' ').toUpperCase()}".`);
    }
  };

  // Cancel order handler
  const confirmCancelOrder = async () => {
    if (!cancellingRef) return;
    const target = appointments.find(a => a.booking_ref === cancellingRef);
    const notes = target?.special_notes ? `${target.special_notes} [Cancelled: ${cancelReason}]` : `[Cancelled: ${cancelReason}]`;
    const res = await updateAppointmentStatus(cancellingRef, 'cancelled', notes);
    if (res.success) {
      setAppointments(prev => prev.map(a => a.booking_ref === cancellingRef ? { ...a, status: 'cancelled', special_notes: notes } : a));
      showNotification(`Order ${cancellingRef} has been cancelled.`);
    }
    setCancellingRef(null);
  };

  // Permanent Delete
  const confirmDeleteOrder = async () => {
    if (!deletingRef) return;
    const res = await deleteAppointment(deletingRef);
    if (res.success) {
      setAppointments(prev => prev.filter(a => a.booking_ref !== deletingRef && a.id !== deletingRef));
      showNotification(`Order ${deletingRef} permanently removed.`);
    }
    setDeletingRef(null);
  };

  // Save Edits
  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAppointment) return;

    const res = await updateAppointment(editingAppointment.booking_ref, editingAppointment);
    if (res.success) {
      setAppointments(prev => prev.map(a => a.booking_ref === editingAppointment.booking_ref ? editingAppointment : a));
      showNotification(`Order ${editingAppointment.booking_ref} updated successfully.`);
      setEditingAppointment(null);
    }
  };

  // Manual Booking
  const handleCreateManualBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    const pkg = SERVICE_PACKAGES.find(p => p.id === manualServiceId) || SERVICE_PACKAGES[0];
    const style = DRAPING_STYLES.find(s => s.id === manualStyleId) || DRAPING_STYLES[0];
    const ref = `GEETHA-${Math.floor(100000 + Math.random() * 900000)}`;

    const newRecord: AppointmentRecord = {
      booking_ref: ref,
      service_id: pkg.id,
      service_name: pkg.name,
      style_id: style.id,
      style_name: style.name,
      date: manualDate,
      time_slot: manualTime,
      location_type: manualLocation,
      address: manualLocation === 'onsite' ? manualAddress : STUDIO_INFO.fullAddress,
      city_area: 'Bangalore South',
      guest_count: 1,
      client_name: manualClientName,
      email: '',
      phone: manualPhone,
      saree_fabric: 'Silk / Traditional Weave',
      saree_length: '6 meters',
      height_footwear: '',
      special_notes: manualNotes ? `[Manual Booking] ${manualNotes}` : '[Manual Booking by Geetha]',
      include_pre_pleating: false,
      total_price: pkg.priceINR,
      advance_deposit: Math.round(pkg.priceINR * 0.3),
      status: 'confirmed'
    };

    const res = await saveAppointment(newRecord);
    if (res.success) {
      setAppointments(prev => [newRecord, ...prev]);
      showNotification(`Manual booking ${ref} created and saved to database!`);
      setIsManualBookingOpen(false);
      setManualClientName('');
      setManualPhone('');
      setManualNotes('');
    }
  };

  const copySql = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_SETUP_SCRIPT.trim());
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2000);
  };

  const copyAppointmentText = (appt: AppointmentRecord) => {
    const text = `Order Ref: ${appt.booking_ref}\nClient: ${appt.client_name} (${appt.phone})\nService: ${appt.service_name} (${appt.style_name})\nDate: ${appt.date} at ${appt.time_slot}\nLocation: ${appt.location_type === 'onsite' ? appt.address : 'Studio Vittasandra Main Rd'}\nTotal: ₹${appt.total_price} (30% Adv: ₹${appt.advance_deposit})\nStatus: ${appt.status || 'confirmed'}`;
    navigator.clipboard.writeText(text);
    setCopiedSummary(appt.booking_ref);
    setTimeout(() => setCopiedSummary(null), 2000);
  };

  // Filtered Appointments
  const filteredAppointments = appointments.filter(appt => {
    const matchesSearch = searchQuery === '' || 
      appt.client_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      appt.phone.includes(searchQuery) ||
      appt.booking_ref.toLowerCase().includes(searchQuery.toLowerCase()) ||
      appt.style_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (appt.address && appt.address.toLowerCase().includes(searchQuery.toLowerCase()));

    const status = (appt.status || 'confirmed').toLowerCase();
    const matchesStatus = statusFilter === 'All' || 
      (statusFilter === 'Confirmed' && (status === 'confirmed' || !status)) ||
      (statusFilter === 'In Progress' && status === 'in_progress') ||
      (statusFilter === 'Completed' && status === 'completed') ||
      (statusFilter === 'Cancelled' && status === 'cancelled');

    const matchesStyle = styleFilter === 'All' || appt.style_name.toLowerCase().includes(styleFilter.toLowerCase());

    return matchesSearch && matchesStatus && matchesStyle;
  });

  // Calculate Metrics
  const totalOrders = appointments.length;
  const activeOrders = appointments.filter(a => (a.status || 'confirmed') !== 'cancelled');
  const completedOrders = appointments.filter(a => a.status === 'completed');
  const cancelledOrders = appointments.filter(a => a.status === 'cancelled');
  const totalRevenue = activeOrders.reduce((sum, a) => sum + Number(a.total_price || 0), 0);
  const totalAdvance = activeOrders.reduce((sum, a) => sum + Number(a.advance_deposit || 0), 0);

  return (
    <div className="min-h-screen bg-[#F0F5FA] text-[#132235] font-sans">
      
      {/* Top Admin Header */}
      <header className="sticky top-0 z-40 bg-[#081324] text-[#FDFBF7] border-b border-[#142A4A] shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          <div className="flex items-center gap-4">
            <button
              onClick={onBackToWebsite}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0E2038] hover:bg-[#153054] text-[#D8E6F5] text-xs font-semibold rounded-lg transition-colors border border-[#21436E] cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4 text-[#D4AF37]" />
              <span>Back to Website</span>
            </button>

            <div className="flex flex-col">
              <span className="font-serif text-xl sm:text-2xl font-bold tracking-wider text-[#FDFBF7]">
                GEETHA SAREE DRAPING
              </span>
              <span className="text-[10px] tracking-[0.2em] uppercase text-[#D4AF37] font-semibold -mt-1 flex items-center gap-1.5">
                <span>Studio Management & Order Dashboard</span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#84CA97] inline-block animate-pulse" />
                <span className="text-[#84CA97] font-mono text-[9px]">Supabase Live</span>
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={loadAppointments}
              disabled={loading}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 bg-[#0E2038] hover:bg-[#153054] text-xs font-semibold rounded-lg border border-[#21436E] cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-[#D4AF37] ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>

            <button
              onClick={() => setIsManualBookingOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-[#D4AF37] hover:bg-[#B99326] text-[#2B0F12] text-xs font-bold rounded-lg shadow-sm cursor-pointer transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>New Booking</span>
            </button>
          </div>

        </div>
      </header>

      {/* Main Admin Content Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        
        {/* Floating Notification Toast */}
        {actionSuccessMsg && (
          <div className="bg-[#1E562A] text-white p-3.5 rounded-xl shadow-lg flex items-center justify-between text-xs animate-in fade-in slide-in-from-top-2 duration-150">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#84CA97]" />
              <span className="font-medium">{actionSuccessMsg}</span>
            </div>
            <button onClick={() => setActionSuccessMsg(null)} className="p-1 hover:opacity-80">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Top Analytics / Overview Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5 sm:gap-4">
          
          <div className="bg-white p-4 rounded-xl border border-[#DFCEB9] space-y-1 shadow-xs">
            <span className="text-[11px] text-[#7B6763] font-semibold uppercase tracking-wider block">
              Total Orders
            </span>
            <div className="flex items-baseline justify-between">
              <span className="font-serif text-2xl sm:text-3xl font-bold text-[#2B0F12] tabular-nums">
                {totalOrders}
              </span>
              <span className="text-[11px] text-[#1E562A] font-semibold bg-[#EAF5EC] px-1.5 py-0.5 rounded">
                Database All
              </span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-[#DFCEB9] space-y-1 shadow-xs">
            <span className="text-[11px] text-[#7B6763] font-semibold uppercase tracking-wider block">
              Active Bookings
            </span>
            <div className="flex items-baseline justify-between">
              <span className="font-serif text-2xl sm:text-3xl font-bold text-[#1E562A] tabular-nums">
                {activeOrders.length}
              </span>
              <span className="text-[10px] text-[#7B6763]">
                {completedOrders.length} Completed
              </span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-[#DFCEB9] space-y-1 shadow-xs">
            <span className="text-[11px] text-[#7B6763] font-semibold uppercase tracking-wider block">
              Estimated Total Value
            </span>
            <div className="flex items-baseline justify-between">
              <span className="font-serif text-2xl sm:text-3xl font-bold text-[#3A1518] tabular-nums">
                ₹{totalRevenue.toLocaleString('en-IN')}
              </span>
              <span className="text-[10px] text-[#9E7418] font-semibold">
                INR
              </span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-[#DFCEB9] space-y-1 shadow-xs">
            <span className="text-[11px] text-[#7B6763] font-semibold uppercase tracking-wider block">
              Advance Collected
            </span>
            <div className="flex items-baseline justify-between">
              <span className="font-serif text-2xl sm:text-3xl font-bold text-[#9E7418] tabular-nums">
                ₹{totalAdvance.toLocaleString('en-IN')}
              </span>
              <span className="text-[10px] text-[#1E562A] font-semibold">
                30% Adv
              </span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-[#DFCEB9] space-y-1 shadow-xs col-span-2 lg:col-span-1">
            <span className="text-[11px] text-[#7B6763] font-semibold uppercase tracking-wider block">
              Cancelled Orders
            </span>
            <div className="flex items-baseline justify-between">
              <span className="font-serif text-2xl sm:text-3xl font-bold text-[#8B3B3B] tabular-nums">
                {cancelledOrders.length}
              </span>
              <span className="text-[10px] text-[#8B3B3B]">
                Cancelled
              </span>
            </div>
          </div>

        </div>

        {/* Search & Filter Toolbar */}
        <div className="bg-white rounded-xl border border-[#DFCEB9] p-4 sm:p-5 space-y-4 shadow-xs">
          
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            
            {/* Search Input */}
            <div className="relative flex-1 max-w-lg">
              <Search className="w-4 h-4 text-[#8C7A75] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by client name, phone (8050566063), booking ref, or address..."
                className="w-full pl-10 pr-4 py-2.5 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-xs text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8C7A75] hover:text-[#2B0F12]"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Quick Link to Supabase Table & SQL */}
            <div className="flex items-center gap-2 self-end md:self-auto">
              <button
                onClick={() => setShowSqlSetup(!showSqlSetup)}
                className="px-3 py-1.5 bg-[#FAF5EB] hover:bg-[#F2E8D5] text-[#3A1518] text-xs font-semibold rounded-lg border border-[#D9CBB7] flex items-center gap-1.5 cursor-pointer"
              >
                <Database className="w-3.5 h-3.5 text-[#9E7418]" />
                <span>{showSqlSetup ? 'Hide SQL Script' : 'Supabase SQL Setup'}</span>
              </button>

              <a
                href="https://supabase.com/dashboard/project/rjxalknfpqhslkmwqwch/editor"
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 bg-[#1E562A] hover:bg-[#164420] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <span>Supabase Web Dashboard</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

          </div>

          {/* Status Tabs & Style Filter */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-[#F2EAE0]">
            
            {/* Status Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
              {['All', 'Confirmed', 'In Progress', 'Completed', 'Cancelled'].map(st => (
                <button
                  key={st}
                  onClick={() => setStatusFilter(st)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                    statusFilter === st
                      ? 'bg-[#3A1518] text-white shadow-xs'
                      : 'bg-[#FAF6EE] text-[#5C4A45] hover:text-[#2B0F12] border border-[#E8DEC9]'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>

            {/* Style Selector */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-[#7B6763] font-medium whitespace-nowrap">Filter Style:</span>
              <select
                value={styleFilter}
                onChange={(e) => setStyleFilter(e.target.value)}
                className="px-3 py-1.5 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-xs text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
              >
                <option value="All">All Styles</option>
                <option value="Wedding Bridal">Wedding Bridal (₹3,000)</option>
                <option value="Kerala">Kerala Style (₹2,500)</option>
                <option value="Bharatanatyam">Bharatanatyam (₹4,000)</option>
                <option value="Indian Saree">Indian Saree (₹2,000)</option>
                <option value="Kacha">Kacha Saree Style (₹4,000)</option>
                <option value="Festive">Party & Festive (From ₹1,500)</option>
              </select>
            </div>

          </div>

        </div>

        {/* SQL Script Display */}
        {showSqlSetup && (
          <div className="bg-[#1E1E1E] text-[#D4D4D4] p-5 rounded-2xl shadow-xl text-xs space-y-3 font-mono border border-[#3A3A3A] animate-in fade-in">
            <div className="flex items-center justify-between text-[#E8D9C0]">
              <div className="space-y-0.5">
                <span className="font-bold text-[#D4AF37] block">Supabase SQL Editor Script:</span>
                <span className="text-[11px] text-[#A69487]">Run this once in your Supabase SQL Editor to enable full Read, Insert, Update, and Delete policies.</span>
              </div>
              <button
                onClick={copySql}
                className="flex items-center gap-1.5 bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded-lg text-xs font-sans cursor-pointer transition-colors"
              >
                {copiedSql ? <Check className="w-3.5 h-3.5 text-[#1E562A]" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSql ? 'Copied SQL Script!' : 'Copy SQL'}</span>
              </button>
            </div>
            <pre className="text-[11px] leading-relaxed whitespace-pre-wrap max-h-56 overflow-y-auto bg-black/40 p-3 rounded-lg border border-white/5">
              {SUPABASE_SQL_SETUP_SCRIPT.trim()}
            </pre>
          </div>
        )}

        {/* Bookings List / Table */}
        <div className="space-y-4">
          
          <div className="flex items-center justify-between text-xs text-[#7B6763]">
            <span>
              Showing <strong className="text-[#2B0F12]">{filteredAppointments.length}</strong> of {totalOrders} bookings
            </span>
            {loading && (
              <span className="flex items-center gap-1 text-[#9E7418]">
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Syncing with Supabase...</span>
              </span>
            )}
          </div>

          {filteredAppointments.length === 0 ? (
            <div className="bg-white rounded-2xl border border-[#DFCEB9] p-12 text-center space-y-3 shadow-xs">
              <Database className="w-10 h-10 text-[#9E7418] mx-auto opacity-50" />
              <h4 className="font-serif text-xl font-bold text-[#2B0F12]">
                No Appointments Found
              </h4>
              <p className="text-xs text-[#786661] max-w-sm mx-auto">
                No orders match your filter criteria. Try resetting the filters or create a new booking using the "New Booking" button above.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setStatusFilter('All');
                  setStyleFilter('All');
                }}
                className="px-4 py-2 bg-[#3A1518] text-white text-xs font-semibold rounded-lg cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            filteredAppointments.map((appt) => {
              const status = (appt.status || 'confirmed').toLowerCase();
              const isCancelled = status === 'cancelled';
              const isCompleted = status === 'completed';
              const isInProgress = status === 'in_progress';

              const whatsappClientMsg = encodeURIComponent(
                `Hello ${appt.client_name}! This is Geetha from Geetha Saree Draping (Vittasandra Main Road). Regarding your appointment (${appt.booking_ref}) for ${appt.service_name} on ${appt.date} at ${appt.time_slot}. Please let me know if you need any assistance!`
              );

              return (
                <div
                  key={appt.id || appt.booking_ref}
                  className={`bg-white rounded-2xl border p-5 sm:p-6 transition-all shadow-xs space-y-4 ${
                    isCancelled
                      ? 'border-[#E8C8C8] bg-[#FDF9F9] opacity-85'
                      : isCompleted
                      ? 'border-[#C8E0CD] bg-[#FBFDFB]'
                      : 'border-[#DFCEB9] hover:border-[#9E7418]'
                  }`}
                >
                  {/* Card Top Row: Client Name, Ref, Status Badge, and Total */}
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#F2EAE0] pb-3">
                    
                    <div className="flex flex-wrap items-center gap-2.5">
                      <h4 className="font-serif text-lg sm:text-xl font-bold text-[#2B0F12]">
                        {appt.client_name}
                      </h4>
                      <span className="font-mono text-[11px] bg-[#FAF5EB] text-[#7B6763] px-2 py-0.5 rounded border border-[#E8DEC9]">
                        #{appt.booking_ref}
                      </span>

                      {/* Status Selector Dropdown */}
                      <div className="relative inline-block">
                        <select
                          value={status}
                          onChange={(e) => handleStatusChange(appt.booking_ref, e.target.value as any)}
                          className={`text-xs font-bold px-2.5 py-1 rounded-md cursor-pointer border focus:outline-none ${
                            isCancelled
                              ? 'bg-[#FBEAEA] text-[#9E2828] border-[#E8A5A5]'
                              : isCompleted
                              ? 'bg-[#E5F5E9] text-[#1E562A] border-[#A8DBB4]'
                              : isInProgress
                              ? 'bg-[#FAF0DE] text-[#9E7418] border-[#E8D099]'
                              : 'bg-[#FAF5EB] text-[#3A1518] border-[#DFCEB9]'
                          }`}
                        >
                          <option value="confirmed">Confirmed</option>
                          <option value="in_progress">In Progress</option>
                          <option value="completed">Completed</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </div>
                    </div>

                    {/* Price and Advance */}
                    <div className="flex items-baseline gap-2">
                      <span className="text-xs text-[#7B6763]">Total:</span>
                      <span className="font-serif text-xl font-bold text-[#2B0F12] tabular-nums">
                        ₹{Number(appt.total_price || 0).toLocaleString('en-IN')}
                      </span>
                      <span className="text-[11px] text-[#1E562A] font-semibold bg-[#EAF5EC] px-2 py-0.5 rounded">
                        Adv: ₹{Number(appt.advance_deposit || 0).toLocaleString('en-IN')}
                      </span>
                    </div>

                  </div>

                  {/* Main Details Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs text-[#52413D]">
                    
                    <div className="space-y-1">
                      <span className="text-[10px] text-[#7B6763] font-bold uppercase tracking-wider block">
                        Service & Style
                      </span>
                      <p className="font-semibold text-[#2B0F12] text-sm">
                        {appt.service_name}
                      </p>
                      <p className="text-[11px] text-[#9E7418]">
                        {appt.style_name}
                      </p>
                    </div>

                    <div className="space-y-1">
                      <span className="text-[10px] text-[#7B6763] font-bold uppercase tracking-wider block">
                        Date & Time Slot
                      </span>
                      <div className="flex items-center gap-1.5 font-semibold text-[#2B0F12]">
                        <Calendar className="w-3.5 h-3.5 text-[#9E7418]" />
                        <span>{appt.date}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-[11px] text-[#786661]">
                        <Clock className="w-3 h-3 text-[#9E7418]" />
                        <span>{appt.time_slot}</span>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <span className="text-[10px] text-[#7B6763] font-bold uppercase tracking-wider block">
                        Client Phone & Contact
                      </span>
                      <div className="flex items-center gap-1.5 font-bold text-[#1E562A]">
                        <Phone className="w-3.5 h-3.5" />
                        <a href={`tel:${appt.phone}`} className="hover:underline">
                          {appt.phone}
                        </a>
                      </div>
                      {appt.email && (
                        <p className="text-[11px] text-[#786661] truncate">
                          {appt.email}
                        </p>
                      )}
                    </div>

                    <div className="space-y-1">
                      <span className="text-[10px] text-[#7B6763] font-bold uppercase tracking-wider block">
                        Location / Venue
                      </span>
                      <div className="flex items-center gap-1.5 font-semibold text-[#2B0F12]">
                        <MapPin className="w-3.5 h-3.5 text-[#9E7418]" />
                        <span className="capitalize">{appt.location_type === 'onsite' ? 'On-Site Visit' : 'Studio (Vittasandra)'}</span>
                      </div>
                      <p className="text-[11px] text-[#786661] line-clamp-1">
                        {appt.address}
                      </p>
                    </div>

                  </div>

                  {/* Saree & Garment Specifications */}
                  {(appt.saree_fabric || appt.special_notes || appt.height_footwear) && (
                    <div className="bg-[#FAF6EE] p-3 rounded-xl border border-[#ECE0CE] text-xs text-[#55433F] space-y-1">
                      {appt.saree_fabric && (
                        <div>
                          <strong className="text-[#3A1518]">Fabric & Length: </strong>
                          <span>{appt.saree_fabric} ({appt.saree_length || 'Standard'})</span>
                        </div>
                      )}
                      {appt.height_footwear && (
                        <div>
                          <strong className="text-[#3A1518]">Height & Heels: </strong>
                          <span>{appt.height_footwear}</span>
                        </div>
                      )}
                      {appt.special_notes && (
                        <div>
                          <strong className="text-[#3A1518]">Special Notes / Instructions: </strong>
                          <span className="italic">{appt.special_notes}</span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Action Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#F2EAE0]">
                    
                    {/* Customer Contact Links */}
                    <div className="flex items-center gap-2">
                      <a
                        href={`https://wa.me/${appt.phone.replace(/[^0-9]/g, '')}?text=${whatsappClientMsg}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 bg-[#E9F3EB] hover:bg-[#D4E8D8] text-[#1E562A] text-xs font-semibold rounded-lg border border-[#C5DEC8] flex items-center gap-1.5 transition-colors"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>WhatsApp Client</span>
                      </a>

                      <a
                        href={`tel:${appt.phone}`}
                        className="px-3 py-1.5 bg-[#FAF5EB] hover:bg-[#EFE5D3] text-[#3A1518] text-xs font-semibold rounded-lg border border-[#D9CBB7] flex items-center gap-1.5 transition-colors"
                      >
                        <Phone className="w-3.5 h-3.5 text-[#9E7418]" />
                        <span>Call</span>
                      </a>

                      <button
                        onClick={() => copyAppointmentText(appt)}
                        className="px-3 py-1.5 bg-white hover:bg-[#FAF5EB] text-[#574440] text-xs font-medium rounded-lg border border-[#D9CBB7] flex items-center gap-1.5 cursor-pointer"
                      >
                        {copiedSummary === appt.booking_ref ? <Check className="w-3.5 h-3.5 text-[#1E562A]" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedSummary === appt.booking_ref ? 'Copied' : 'Copy Slip'}</span>
                      </button>
                    </div>

                    {/* Manage / Edit / Cancel / Delete Actions */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setEditingAppointment({ ...appt })}
                        className="px-3 py-1.5 bg-white hover:bg-[#FAF5EB] text-[#3A1518] text-xs font-semibold rounded-lg border border-[#D9CBB7] flex items-center gap-1.5 cursor-pointer transition-colors"
                      >
                        <Edit3 className="w-3.5 h-3.5 text-[#9E7418]" />
                        <span>Edit Order</span>
                      </button>

                      {!isCancelled && (
                        <button
                          onClick={() => setCancellingRef(appt.booking_ref)}
                          className="px-3 py-1.5 bg-[#FDF2F2] hover:bg-[#FBE4E4] text-[#9E2828] text-xs font-semibold rounded-lg border border-[#E8BDBD] flex items-center gap-1.5 cursor-pointer transition-colors"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Cancel Order</span>
                        </button>
                      )}

                      <button
                        onClick={() => setDeletingRef(appt.booking_ref)}
                        className="p-1.5 text-[#A67B78] hover:text-[#9E2828] hover:bg-[#FBEAEA] rounded-lg transition-colors cursor-pointer"
                        title="Delete permanently from database"
                        aria-label="Delete permanently"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                  </div>

                </div>
              );
            })
          )}

        </div>

      </main>

      {/* EDIT MODAL */}
      {editingAppointment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-[#FFFDF9] rounded-2xl border border-[#D9C8B2] max-w-2xl w-full p-6 sm:p-8 space-y-5 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between border-b border-[#E8DEC9] pb-3">
              <div className="space-y-0.5">
                <span className="text-xs font-semibold uppercase tracking-wider text-[#9E7418]">
                  Editing Booking #{editingAppointment.booking_ref}
                </span>
                <h3 className="font-serif text-2xl font-bold text-[#2B0F12]">
                  Manage Order Details
                </h3>
              </div>
              <button
                onClick={() => setEditingAppointment(null)}
                className="p-1 text-[#7A6763] hover:text-[#2B0F12]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4 text-xs">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Client Full Name</label>
                  <input
                    type="text"
                    value={editingAppointment.client_name}
                    onChange={(e) => setEditingAppointment({ ...editingAppointment, client_name: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Phone Number</label>
                  <input
                    type="tel"
                    value={editingAppointment.phone}
                    onChange={(e) => setEditingAppointment({ ...editingAppointment, phone: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Appointment Date</label>
                  <input
                    type="date"
                    value={editingAppointment.date}
                    onChange={(e) => setEditingAppointment({ ...editingAppointment, date: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Time Slot</label>
                  <input
                    type="text"
                    value={editingAppointment.time_slot}
                    onChange={(e) => setEditingAppointment({ ...editingAppointment, time_slot: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Status</label>
                  <select
                    value={editingAppointment.status || 'confirmed'}
                    onChange={(e) => setEditingAppointment({ ...editingAppointment, status: e.target.value })}
                    className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                  >
                    <option value="confirmed">Confirmed</option>
                    <option value="in_progress">In Progress</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Location Type</label>
                  <select
                    value={editingAppointment.location_type}
                    onChange={(e) => setEditingAppointment({ ...editingAppointment, location_type: e.target.value })}
                    className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                  >
                    <option value="studio">Studio (Vittasandra Main Road)</option>
                    <option value="onsite">On-Site Visit (Home / Mandapam)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Address / Venue Details</label>
                <input
                  type="text"
                  value={editingAppointment.address}
                  onChange={(e) => setEditingAppointment({ ...editingAppointment, address: e.target.value })}
                  className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Total Price (₹)</label>
                  <input
                    type="number"
                    value={editingAppointment.total_price}
                    onChange={(e) => setEditingAppointment({ ...editingAppointment, total_price: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Advance Deposit (₹)</label>
                  <input
                    type="number"
                    value={editingAppointment.advance_deposit}
                    onChange={(e) => setEditingAppointment({ ...editingAppointment, advance_deposit: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Special Notes / Draper Notes</label>
                <textarea
                  rows={3}
                  value={editingAppointment.special_notes}
                  onChange={(e) => setEditingAppointment({ ...editingAppointment, special_notes: e.target.value })}
                  className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E8DEC9]">
                <button
                  type="button"
                  onClick={() => setEditingAppointment(null)}
                  className="px-4 py-2 border border-[#D9CBB7] text-xs font-semibold rounded-lg text-[#5C4A45] hover:bg-[#FAF5EB] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#3A1518] hover:bg-[#250B0D] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Save className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Save Changes to Supabase</span>
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* CANCEL CONFIRMATION MODAL */}
      {cancellingRef && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl border border-[#DFCEB9] max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-2 text-[#9E2828]">
              <XCircle className="w-6 h-6" />
              <h4 className="font-serif text-xl font-bold text-[#2B0F12]">Cancel Appointment?</h4>
            </div>
            
            <p className="text-xs text-[#5C4A45] leading-relaxed">
              Are you sure you want to cancel order <strong className="text-[#2B0F12]">#{cancellingRef}</strong>? The status will be marked as "Cancelled" in the database.
            </p>

            <div>
              <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Reason for cancellation (optional):</label>
              <select
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-xs text-[#2B0F12]"
              >
                <option value="Client requested cancellation">Client requested cancellation</option>
                <option value="Client rescheduled to future date">Client rescheduled to future date</option>
                <option value="Slot unavailable / emergency">Slot unavailable / emergency</option>
                <option value="Duplicate or test booking">Duplicate or test booking</option>
              </select>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setCancellingRef(null)}
                className="px-4 py-2 border border-[#D9CBB7] text-xs font-semibold rounded-lg text-[#5C4A45] cursor-pointer"
              >
                Keep Order
              </button>
              <button
                onClick={confirmCancelOrder}
                className="px-4 py-2 bg-[#9E2828] hover:bg-[#801F1F] text-white text-xs font-semibold rounded-lg cursor-pointer"
              >
                Confirm Cancellation
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PERMANENT DELETE CONFIRMATION MODAL */}
      {deletingRef && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl border border-[#DFCEB9] max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-2 text-[#9E2828]">
              <Trash2 className="w-6 h-6" />
              <h4 className="font-serif text-xl font-bold text-[#2B0F12]">Permanent Deletion</h4>
            </div>
            
            <p className="text-xs text-[#5C4A45] leading-relaxed">
              This will permanently delete record <strong className="text-[#2B0F12]">#{deletingRef}</strong> from your Supabase database. This action cannot be undone.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setDeletingRef(null)}
                className="px-4 py-2 border border-[#D9CBB7] text-xs font-semibold rounded-lg text-[#5C4A45] cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={confirmDeleteOrder}
                className="px-4 py-2 bg-[#9E2828] hover:bg-[#801F1F] text-white text-xs font-semibold rounded-lg cursor-pointer"
              >
                Delete Permanently
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MANUAL BOOKING MODAL */}
      {isManualBookingOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-[#FFFDF9] rounded-2xl border border-[#D9C8B2] max-w-xl w-full p-6 sm:p-8 space-y-5 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between border-b border-[#E8DEC9] pb-3">
              <div className="space-y-0.5">
                <span className="text-xs font-semibold uppercase tracking-wider text-[#9E7418]">
                  Phone / Walk-In Client
                </span>
                <h3 className="font-serif text-2xl font-bold text-[#2B0F12]">
                  Create Manual Booking
                </h3>
              </div>
              <button
                onClick={() => setIsManualBookingOpen(false)}
                className="p-1 text-[#7A6763] hover:text-[#2B0F12]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateManualBooking} className="space-y-3.5 text-xs">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Client Name</label>
                  <input
                    type="text"
                    value={manualClientName}
                    onChange={(e) => setManualClientName(e.target.value)}
                    placeholder="e.g., Ananya Sharma"
                    required
                    className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Phone Number</label>
                  <input
                    type="tel"
                    value={manualPhone}
                    onChange={(e) => setManualPhone(e.target.value)}
                    placeholder="e.g., 8050566063"
                    required
                    className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Service Package</label>
                  <select
                    value={manualServiceId}
                    onChange={(e) => setManualServiceId(e.target.value)}
                    className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                  >
                    {SERVICE_PACKAGES.map(p => (
                      <option key={p.id} value={p.id}>
                        {p.name} (₹{p.priceINR})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Drape Style</label>
                  <select
                    value={manualStyleId}
                    onChange={(e) => setManualStyleId(e.target.value)}
                    className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                  >
                    {DRAPING_STYLES.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} (₹{s.priceINR})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Event Date</label>
                  <input
                    type="date"
                    value={manualDate}
                    onChange={(e) => setManualDate(e.target.value)}
                    required
                    className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Time Slot</label>
                  <input
                    type="text"
                    value={manualTime}
                    onChange={(e) => setManualTime(e.target.value)}
                    placeholder="e.g., 08:30 AM"
                    required
                    className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Location</label>
                <div className="flex gap-4 mb-2">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      name="manualLoc"
                      checked={manualLocation === 'studio'}
                      onChange={() => setManualLocation('studio')}
                    />
                    <span>At Studio (Vittasandra Main Rd)</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      name="manualLoc"
                      checked={manualLocation === 'onsite'}
                      onChange={() => setManualLocation('onsite')}
                    />
                    <span>On-Site Visit (Mandapam/Home)</span>
                  </label>
                </div>

                {manualLocation === 'onsite' && (
                  <input
                    type="text"
                    value={manualAddress}
                    onChange={(e) => setManualAddress(e.target.value)}
                    placeholder="Venue / Mandapam Address"
                    className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                  />
                )}
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#54433F] mb-1">Special Notes / Fabric</label>
                <textarea
                  rows={2}
                  value={manualNotes}
                  onChange={(e) => setManualNotes(e.target.value)}
                  placeholder="e.g., Pure Kanjeevaram, morning wedding ceremony"
                  className="w-full px-3 py-2 bg-[#FAF6EE] border border-[#D9CBB7] rounded-lg text-[#2B0F12] focus:outline-none focus:border-[#9E7418]"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E8DEC9]">
                <button
                  type="button"
                  onClick={() => setIsManualBookingOpen(false)}
                  className="px-4 py-2 border border-[#D9CBB7] text-xs font-semibold rounded-lg text-[#5C4A45] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#3A1518] hover:bg-[#250B0D] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Plus className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Create Booking & Save</span>
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
};
