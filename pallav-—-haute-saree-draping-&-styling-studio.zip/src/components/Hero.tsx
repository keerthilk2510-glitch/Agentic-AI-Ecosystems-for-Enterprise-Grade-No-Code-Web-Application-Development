import React from 'react';
import { Calendar, ArrowRight, ShieldCheck, Clock, Sparkles, HeartHandshake, MapPin, Phone, MessageCircle } from 'lucide-react';
import { HERO_IMAGE, STUDIO_INFO } from '../data/drapingData';

interface HeroProps {
  onOpenBooking: () => void;
  onExploreStyles: () => void;
  onOpenQuiz: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking, onExploreStyles, onOpenQuiz }) => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-[#F0F5FA] via-[#E6F0FA] to-[#DCEDFC] pt-8 pb-16 lg:pt-14 lg:pb-24 border-b border-[#CBDCEE]">
      {/* Decorative luxury background pattern */}
      <div 
        className="absolute inset-0 opacity-[0.035] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(#183760 1px, transparent 1px)`,
          backgroundSize: '24px 24px'
        }}
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          {/* Left Column: Headlines & Call to Actions */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Subtle editorial kicker */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-[#9E7418]">
              <span>Geetha Saree Draping</span>
              <span aria-hidden="true">·</span>
              <span className="text-[#1E562A] font-bold">Starts from ₹1,500</span>
              <span aria-hidden="true">·</span>
              <span>Vittasandra Main Road, Bangalore South</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#0B1A30] leading-[1.12] text-balance">
              Elegance, Draped to <span className="italic font-normal text-[#9E7418]">Perfection.</span>
            </h1>

            {/* Sub-headline */}
            <p className="text-base sm:text-lg text-[#384F6B] leading-relaxed max-w-2xl">
              Transform your six yards into a masterpiece with <strong className="text-[#0B1A30]">Geetha Saree Draping</strong>. Professional saree styling for weddings, celebrations, classical dance, and everyday grace. Located on <span className="font-semibold text-[#0B1A30]">Vittasandra Main Road, near Keerthi Chicken Center, Bangalore South</span>.
            </p>

            {/* Saree Draping Styles & Rates Highlight Box */}
            <div className="bg-[#E1EDFA] p-4 rounded-xl border border-[#99BEE3] max-w-2xl shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#0B1A30]">
                  Specialist Styles & Rates:
                </span>
                <span className="text-xs font-bold text-[#1E562A] bg-[#EAF5EC] px-2 py-0.5 rounded">
                  Starts from ₹1,500
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
                <div className="bg-white/95 p-2.5 rounded-lg border border-[#CBDCEE] shadow-2xs">
                  <span className="text-[10px] text-[#556F8C] block font-medium">Wedding Bridal</span>
                  <span className="font-bold text-[#0B1A30] text-base tabular-nums">₹3,000</span>
                </div>
                <div className="bg-white/95 p-2.5 rounded-lg border border-[#CBDCEE] shadow-2xs">
                  <span className="text-[10px] text-[#556F8C] block font-medium">Kerala Style</span>
                  <span className="font-bold text-[#0B1A30] text-base tabular-nums">₹2,500</span>
                </div>
                <div className="bg-white/95 p-2.5 rounded-lg border border-[#CBDCEE] shadow-2xs">
                  <span className="text-[10px] text-[#556F8C] block font-medium">Bharatanatyam</span>
                  <span className="font-bold text-[#0B1A30] text-base tabular-nums">₹4,000</span>
                </div>
                <div className="bg-white/95 p-2.5 rounded-lg border border-[#CBDCEE] shadow-2xs">
                  <span className="text-[10px] text-[#556F8C] block font-medium">Indian Saree</span>
                  <span className="font-bold text-[#0B1A30] text-base tabular-nums">₹2,000</span>
                </div>
                <div className="bg-white/95 p-2.5 rounded-lg border border-[#CBDCEE] shadow-2xs">
                  <span className="text-[10px] text-[#556F8C] block font-medium">Kacha Saree Style</span>
                  <span className="font-bold text-[#0B1A30] text-base tabular-nums">₹4,000</span>
                </div>
                <div className="bg-white/95 p-2.5 rounded-lg border border-[#CBDCEE] bg-[#EAF5EC]/70 shadow-2xs">
                  <span className="text-[10px] text-[#1E562A] block font-bold">Party / Festive Drape</span>
                  <span className="font-bold text-[#1E562A] text-base tabular-nums">From ₹1,500</span>
                </div>
              </div>
            </div>

            {/* Quick Contact & Location Ribbon */}
            <div className="flex flex-wrap items-center gap-3 text-xs bg-white/80 backdrop-blur-xs p-3 rounded-lg border border-[#CBDCEE]">
              <div className="flex items-center gap-1.5 font-semibold text-[#0B1A30]">
                <MapPin className="w-4 h-4 text-[#9E7418]" />
                <span>Vittasandra Main Road (Near Keerthi Chicken Center)</span>
              </div>
              <span className="text-[#D4AF37] hidden sm:inline">·</span>
              <a 
                href={`tel:${STUDIO_INFO.phone}`} 
                className="flex items-center gap-1 font-bold text-[#0B1A30] hover:text-[#183760]"
              >
                <Phone className="w-3.5 h-3.5 text-[#183760]" />
                <span>8050566063</span>
              </a>
              <span className="text-[#D4AF37] hidden sm:inline">·</span>
              <a
                href={`https://wa.me/${STUDIO_INFO.whatsappNumber}?text=Hello%20Geetha!%20I%20would%20like%20to%20book%20a%20saree%20draping%20appointment.`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-[#1E562A] font-semibold hover:underline"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp Booking Available</span>
              </a>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3.5 pt-1">
              <button
                onClick={onOpenBooking}
                className="px-6 py-3.5 bg-[#0D2444] hover:bg-[#07162B] text-[#FDFBF7] font-semibold text-sm sm:text-base rounded-lg shadow-md hover:shadow-lg transition-all flex items-center gap-2.5 cursor-pointer border border-[#1B3E6E] group"
              >
                <Calendar className="w-5 h-5 text-[#D4AF37]" />
                <span>Book a Stylist (From ₹1,500)</span>
                <ArrowRight className="w-4 h-4 text-[#D4AF37] group-hover:translate-x-1 transition-transform" />
              </button>

              <a
                href="#location"
                className="px-5 py-3.5 bg-white hover:bg-[#EAF1F8] text-[#0B1A30] font-semibold text-sm rounded-lg border border-[#CBDCEE] shadow-xs hover:border-[#1E467B] transition-all flex items-center gap-2 cursor-pointer"
              >
                <MapPin className="w-4 h-4 text-[#9E7418]" />
                <span>Live Map & Directions</span>
              </a>

              <a
                href={`tel:${STUDIO_INFO.phone}`}
                className="px-5 py-3.5 bg-[#EAF5EC] hover:bg-[#D7EED9] text-[#1E562A] font-semibold text-sm rounded-lg border border-[#C5DEC8] shadow-xs transition-all flex items-center gap-2 cursor-pointer"
              >
                <Phone className="w-4 h-4" />
                <span>Call 8050566063</span>
              </a>
            </div>

            {/* Trust Badges */}
            <div className="pt-6 border-t border-[#CBDCEE] grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs text-[#384F6B]">
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 font-semibold text-[#0B1A30]">
                  <ShieldCheck className="w-4 h-4 text-[#9E7418]" />
                  <span>12-Hour Hold</span>
                </div>
                <p className="text-[11px] text-[#556F8C] leading-tight">Zero-sag pleats and pinless magnetic comfort.</p>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-1.5 font-semibold text-[#0B1A30]">
                  <Clock className="w-4 h-4 text-[#9E7418]" />
                  <span>15–20 Min Speed</span>
                </div>
                <p className="text-[11px] text-[#556F8C] leading-tight">Rapid precision styling with zero delays.</p>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-1.5 font-semibold text-[#0B1A30]">
                  <Sparkles className="w-4 h-4 text-[#9E7418]" />
                  <span>From ₹1,500</span>
                </div>
                <p className="text-[11px] text-[#556F8C] leading-tight">Transparent pricing with no hidden charges.</p>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-1.5 font-semibold text-[#0B1A30]">
                  <HeartHandshake className="w-4 h-4 text-[#9E7418]" />
                  <span>On-Site Visits</span>
                </div>
                <p className="text-[11px] text-[#556F8C] leading-tight">Bangalore South & Electronic City zones.</p>
              </div>
            </div>

          </div>

          {/* Right Column: Visual Focal Point */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Decorative framing element */}
              <div className="absolute -inset-3 bg-gradient-to-tr from-[#D4AF37]/20 to-[#183760]/15 rounded-2xl filter blur-sm -z-10" />

              {/* Main Image Container */}
              <div className="relative rounded-xl overflow-hidden border border-[#CBDCEE] shadow-xl bg-[#E2EDFA] aspect-[4/5] sm:aspect-[3/4]">
                <img
                  src={HERO_IMAGE}
                  alt="Wedding Bridal Kanjeevaram Saree draped by Geetha Saree Draping"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center transform hover:scale-[1.02] transition-transform duration-700"
                />

                {/* Scrim at bottom for text clarity */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#06111F]/85 via-transparent to-transparent flex flex-col justify-end p-6 text-white">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs text-[#CBDDF0]">
                      <span>Wedding Bridal Drape</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-bold text-[#D4AF37]">₹3,000</span>
                    </div>
                    <p className="font-serif text-lg sm:text-xl font-bold text-[#FFFDF8]">
                      Master-pleated 9-fold fan with gold border alignment
                    </p>
                    <p className="text-xs text-[#CBDDF0]">
                      Geetha Saree Draping · Vittasandra Main Road
                    </p>
                  </div>
                </div>
              </div>

              {/* Floating studio address card */}
              <div className="absolute -bottom-5 -left-4 sm:-left-6 bg-white/95 backdrop-blur-md border border-[#CBDCEE] rounded-lg p-3.5 shadow-lg max-w-[260px] text-xs space-y-1">
                <div className="flex items-center gap-1.5 font-semibold text-[#0B1A30]">
                  <MapPin className="w-3.5 h-3.5 text-[#1E562A]" />
                  <span>Vittasandra Main Road</span>
                </div>
                <p className="text-[11px] text-[#475E7B] leading-snug">
                  Near Keerthi Chicken Center, Bangalore South. Call <strong>8050566063</strong>.
                </p>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
