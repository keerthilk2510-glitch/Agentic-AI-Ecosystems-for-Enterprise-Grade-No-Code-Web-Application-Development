import React, { useState, useEffect } from 'react';
import { X, Database, CheckCircle2, Clock, Phone, MapPin, Calendar, RefreshCw, Copy, Check, AlertCircle } from 'lucide-react';
import { fetchAppointments, AppointmentRecord, SUPABASE_SQL_SETUP_SCRIPT, supabaseUrl } from '../lib/supabase';

interface AdminBookingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenFullAdmin?: () => void;
}

export const AdminBookingsModal: React.FC<AdminBookingsModalProps> = ({ isOpen, onClose, onOpenFullAdmin }) => {
  const [appointments, setAppointments] = useState<AppointmentRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [copiedSql, setCopiedSql] = useState<boolean>(false);
  const [showSql, setShowSql] = useState<boolean>(false);

  const loadData = async () => {
    setLoading(true);
    const data = await fetchAppointments();
    setAppointments(data);
    setLoading(false);
  };

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const copySql = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_SETUP_SCRIPT.trim());
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-[#F8FAFD] rounded-2xl border border-[#CBDCEE] max-w-4xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[#CBDCEE] pb-4 shrink-0">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-[#1E562A] animate-pulse" />
              <span className="text-xs uppercase tracking-wider font-semibold text-[#1E562A]">
                Supabase Backend Connected
              </span>
              <span className="text-xs text-[#183760] bg-[#E2EDFA] px-2 py-0.5 rounded font-mono border border-[#CBDCEE]">
                Project: rjxalknfpqhslkmwqwch
              </span>
            </div>
            <h3 className="font-serif text-2xl font-bold text-[#0B1A30]">
              Live Appointment Bookings
            </h3>
            <p className="text-xs text-[#475E7B]">
              All client bookings submitted through the website are automatically saved to your Supabase database.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-[#556F8C] hover:text-[#0B1A30] rounded-lg hover:bg-[#E2EDFA] transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs shrink-0 bg-[#FAF5EB] p-3 rounded-xl border border-[#DFCEB9]">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-[#2B0F12]">
              Total Bookings: <span className="tabular-nums text-[#3A1518]">{appointments.length}</span>
            </span>
            <button
              onClick={loadData}
              disabled={loading}
              className="flex items-center gap-1.5 text-[#9E7418] hover:text-[#523B0B] font-semibold cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh Live</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            {onOpenFullAdmin && (
              <button
                onClick={onOpenFullAdmin}
                className="px-3 py-1 bg-[#3A1518] hover:bg-[#250B0D] text-white rounded-lg font-semibold cursor-pointer shadow-xs"
              >
                Open Full Admin Dashboard
              </button>
            )}
            <button
              onClick={() => setShowSql(!showSql)}
              className="px-3 py-1 bg-white hover:bg-[#F8F2E6] text-[#3A1518] border border-[#D9CBB7] rounded-lg font-medium cursor-pointer"
            >
              {showSql ? 'Hide SQL Setup' : 'Supabase Table SQL Guide'}
            </button>
            <a
              href="https://supabase.com/dashboard/project/rjxalknfpqhslkmwqwch/editor"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1 bg-[#1E562A] hover:bg-[#164420] text-white rounded-lg font-medium cursor-pointer flex items-center gap-1"
            >
              <span>Open Supabase Dashboard</span>
              <Database className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* SQL Script Accordion */}
        {showSql && (
          <div className="bg-[#1E1E1E] text-[#D4D4D4] p-4 rounded-xl text-xs space-y-3 shrink-0 max-h-48 overflow-y-auto font-mono">
            <div className="flex items-center justify-between text-[#E8D9C0]">
              <span className="font-semibold text-[#D4AF37]">Supabase SQL Table Migration:</span>
              <button
                onClick={copySql}
                className="flex items-center gap-1 bg-white/10 hover:bg-white/20 text-white px-2 py-1 rounded text-[11px] cursor-pointer"
              >
                {copiedSql ? <Check className="w-3 h-3 text-[#1E562A]" /> : <Copy className="w-3 h-3" />}
                <span>{copiedSql ? 'Copied SQL!' : 'Copy SQL'}</span>
              </button>
            </div>
            <pre className="text-[11px] leading-relaxed whitespace-pre-wrap">
              {SUPABASE_SQL_SETUP_SCRIPT.trim()}
            </pre>
          </div>
        )}

        {/* Appointments List */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-1">
          {loading ? (
            <div className="py-12 text-center text-xs text-[#7B6763] space-y-2">
              <RefreshCw className="w-6 h-6 animate-spin mx-auto text-[#9E7418]" />
              <p>Connecting to Supabase and fetching appointments...</p>
            </div>
          ) : appointments.length === 0 ? (
            <div className="py-12 text-center bg-white rounded-xl border border-[#DFCEB9] p-8 space-y-2">
              <Database className="w-8 h-8 text-[#9E7418] mx-auto opacity-50" />
              <h4 className="font-serif text-lg font-bold text-[#2B0F12]">No Bookings Yet</h4>
              <p className="text-xs text-[#7A6763] max-w-sm mx-auto">
                Whenever someone fills out the booking form on your website, it will immediately appear here and in your Supabase table!
              </p>
            </div>
          ) : (
            appointments.map((appt, i) => (
              <div
                key={appt.id || appt.booking_ref || i}
                className="bg-white p-4 rounded-xl border border-[#DFCEB9] space-y-2.5 shadow-xs hover:border-[#9E7418] transition-colors text-xs"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#F2EAE0] pb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-[#3A1518] text-sm">
                      {appt.client_name}
                    </span>
                    <span className="bg-[#EAF5EC] text-[#1E562A] font-semibold px-2 py-0.5 rounded text-[10px]">
                      {appt.booking_ref}
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="font-serif font-bold text-sm text-[#2B0F12] tabular-nums">
                      ₹{Number(appt.total_price || 0).toLocaleString('en-IN')}
                    </span>
                    <span className="text-[10px] text-[#7B6763]">
                      (30% Adv: ₹{Number(appt.advance_deposit || 0).toLocaleString('en-IN')})
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 text-[11px] text-[#5C4A45]">
                  <div>
                    <span className="font-semibold text-[#2B0F12] block">Service & Style:</span>
                    <span className="truncate block">{appt.service_name} · {appt.style_name}</span>
                  </div>
                  <div>
                    <span className="font-semibold text-[#2B0F12] block">Date & Time:</span>
                    <span>{appt.date} at {appt.time_slot}</span>
                  </div>
                  <div>
                    <span className="font-semibold text-[#2B0F12] block">Contact Phone:</span>
                    <a href={`tel:${appt.phone}`} className="text-[#1E562A] font-bold hover:underline">
                      {appt.phone}
                    </a>
                  </div>
                  <div>
                    <span className="font-semibold text-[#2B0F12] block">Location:</span>
                    <span className="truncate block">{appt.location_type === 'onsite' ? appt.address || 'On-site' : 'Studio'}</span>
                  </div>
                </div>

                {(appt.saree_fabric || appt.special_notes) && (
                  <div className="bg-[#FAF5EB] p-2.5 rounded-lg border border-[#EDE2D0] text-[11px] text-[#695854] space-y-0.5">
                    {appt.saree_fabric && (
                      <div><strong className="text-[#3A1518]">Fabric:</strong> {appt.saree_fabric} ({appt.saree_length || 'standard'})</div>
                    )}
                    {appt.special_notes && (
                      <div><strong className="text-[#3A1518]">Notes:</strong> {appt.special_notes}</div>
                    )}
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-[#E8DEC9] flex items-center justify-between text-xs text-[#7B6763] shrink-0">
          <span>Supabase Table: <code className="bg-[#F1E8D7] px-1 py-0.5 rounded text-[#3A1518]">appointments</code></span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#3A1518] text-white rounded-lg font-semibold cursor-pointer hover:bg-[#250B0D]"
          >
            Close Viewer
          </button>
        </div>

      </div>
    </div>
  );
};
