import React, { useState } from 'react';
import { DRAPING_STYLES } from '../data/drapingData';
import { DrapingStyle } from '../types';
import { Sparkles, Clock, Check, ArrowRight, X, Info } from 'lucide-react';

interface StylesShowcaseProps {
  onSelectStyleForBooking: (styleId: string) => void;
}

export const StylesShowcase: React.FC<StylesShowcaseProps> = ({ onSelectStyleForBooking }) => {
  const [filter, setFilter] = useState<'All' | 'Wedding Bridal' | 'Kerala & Regional' | 'Classical & Dance' | 'Indian Saree'>('All');
  const [selectedStyleModal, setSelectedStyleModal] = useState<DrapingStyle | null>(null);

  const filteredStyles = DRAPING_STYLES.filter((style) => {
    if (filter === 'All') return true;
    if (filter === 'Wedding Bridal') return style.id === 'wedding-bridal' || style.occasion.includes('Bridal');
    if (filter === 'Kerala & Regional') return style.id === 'kerala-style' || style.id === 'kacha-saree-style';
    if (filter === 'Classical & Dance') return style.id === 'bharatanatyam-dance';
    if (filter === 'Indian Saree') return style.id === 'indian-saree-classic' || style.id === 'basic-guest-draping' || style.id === 'contemporary-belted';
    return true;
  });

  return (
    <section id="styles" className="py-16 lg:py-24 bg-[#F0F5FA] border-b border-[#CBDCEE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="space-y-3 max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#9E7418]">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Geetha Draping Repertoire</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1A30]">
              Specialist Saree Draping Styles
            </h2>
            <p className="text-base text-[#384F6B] leading-relaxed">
              We specialize in Wedding Bridal (₹3,000), Kerala Style (₹2,500), Bharatanatyam Classical Dance (₹4,000), Indian Saree (₹2,000), and Kacha Saree Style (₹4,000). Saree draping starts from just <strong className="text-[#1E562A]">₹1,500</strong> at our Vittasandra Main Road studio, Bangalore South!
            </p>
          </div>

          {/* Interactive Filter Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-[#D8E6F5] rounded-lg self-start md:self-auto overflow-x-auto max-w-full">
            {(['All', 'Wedding Bridal', 'Kerala & Regional', 'Classical & Dance', 'Indian Saree'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setFilter(tab)}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer whitespace-nowrap ${
                  filter === tab
                    ? 'bg-[#0D2444] text-[#FDFBF7] shadow-xs'
                    : 'text-[#384F6B] hover:text-[#0B1A30]'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Styles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredStyles.map((style) => (
            <div
              key={style.id}
              className="bg-white rounded-xl border border-[#CBDCEE] overflow-hidden shadow-xs hover:shadow-md hover:border-[#1E467B] transition-all flex flex-col justify-between group"
            >
              {/* Top part with image */}
              <div>
                <div className="relative aspect-[4/3] bg-[#E2EDFA] overflow-hidden">
                  <img
                    src={style.image}
                    alt={style.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                  />
                  
                  {/* Price Tag Badge */}
                  <div className="absolute top-3 left-3 bg-[#0B1A30]/95 backdrop-blur-xs text-[#D4AF37] text-xs font-bold px-3 py-1 rounded-md shadow-xs">
                    ₹{style.priceINR.toLocaleString('en-IN')}
                  </div>

                  <div className="absolute bottom-3 right-3 bg-white/95 backdrop-blur-xs text-[#0B1A30] text-[11px] font-semibold px-2.5 py-1 rounded-md flex items-center gap-1 shadow-xs border border-[#CBDCEE]">
                    <Clock className="w-3 h-3 text-[#9E7418]" />
                    <span>{style.durationMins} mins</span>
                  </div>
                </div>

                {/* Content Body */}
                <div className="p-6 space-y-4">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs text-[#475E7B] font-medium">
                      <span>{style.region}</span>
                      <span className="text-[#1E562A] font-semibold">₹{style.priceINR.toLocaleString('en-IN')}</span>
                    </div>
                    <h3 className="font-serif text-xl font-bold text-[#0B1A30] group-hover:text-[#183760] transition-colors">
                      {style.name}
                    </h3>
                    <p className="text-xs text-[#475E7B] line-clamp-2 leading-relaxed">
                      {style.description}
                    </p>
                  </div>

                  {/* Features Highlights */}
                  <div className="space-y-1.5 pt-2 border-t border-[#E1EDFA]">
                    {style.features.slice(0, 2).map((feat, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-[#334A65]">
                        <Check className="w-3.5 h-3.5 text-[#1E562A] shrink-0" />
                        <span className="truncate">{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="px-6 pb-6 pt-2 border-t border-[#E1EDFA] flex items-center justify-between gap-3">
                <button
                  onClick={() => setSelectedStyleModal(style)}
                  className="text-xs font-semibold text-[#183760] hover:text-[#0B1A30] flex items-center gap-1 cursor-pointer py-1.5"
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>View Details</span>
                </button>

                <button
                  onClick={() => onSelectStyleForBooking(style.id)}
                  className="px-3.5 py-2 text-xs font-semibold text-white bg-[#0D2444] hover:bg-[#07162B] rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs whitespace-nowrap border border-[#1B3E6E]"
                >
                  <span>Book for ₹{style.priceINR.toLocaleString('en-IN')}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#D4AF37]" />
                </button>
              </div>

            </div>
          ))}
        </div>

        {/* Modal for In-Depth Style Specifications */}
        {selectedStyleModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-150">
            <div className="bg-[#F8FAFD] rounded-xl border border-[#CBDCEE] max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
              
              <button
                onClick={() => setSelectedStyleModal(null)}
                className="absolute top-5 right-5 p-1.5 text-[#475E7B] hover:text-[#0B1A30] rounded-lg hover:bg-[#E2EDFA] transition-colors cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="space-y-1">
                <div className="flex items-center justify-between pr-8">
                  <span className="text-xs uppercase tracking-wider font-semibold text-[#9E7418]">
                    {selectedStyleModal.region} · {selectedStyleModal.complexity}
                  </span>
                  <span className="text-lg font-serif font-bold text-[#1E562A] bg-[#EAF5EC] px-2.5 py-0.5 rounded-md">
                    ₹{selectedStyleModal.priceINR.toLocaleString('en-IN')}
                  </span>
                </div>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#0B1A30]">
                  {selectedStyleModal.name}
                </h3>
                <p className="text-xs text-[#475E7B] italic">
                  {selectedStyleModal.subtitle}
                </p>
              </div>

              <p className="text-sm text-[#334A65] leading-relaxed">
                {selectedStyleModal.description}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-[#EDF4FB] p-4 rounded-lg border border-[#CBDCEE] text-xs">
                <div>
                  <span className="font-semibold text-[#0B1A30] block mb-1">Pleat Setup:</span>
                  <span className="text-[#384F6B]">{selectedStyleModal.pleatCount}</span>
                </div>
                <div>
                  <span className="font-semibold text-[#0B1A30] block mb-1">Session Duration:</span>
                  <span className="text-[#384F6B]">{selectedStyleModal.durationMins} minutes</span>
                </div>
                <div className="sm:col-span-2">
                  <span className="font-semibold text-[#0B1A30] block mb-1">Best Suited Fabrics:</span>
                  <span className="text-[#384F6B]">{selectedStyleModal.fabrics.join(', ')}</span>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#0B1A30]">Geetha’s Styling Standard</h4>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[#384F6B]">
                  {selectedStyleModal.features.map((feat, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <Check className="w-3.5 h-3.5 text-[#1E562A] shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-[#FAF0DE] border-l-4 border-[#D4AF37] p-3.5 rounded-r text-xs text-[#4F3E16]">
                <strong className="block font-semibold mb-0.5">Styling Recommendation:</strong>
                {selectedStyleModal.stylingTips}
              </div>

              <div className="pt-4 border-t border-[#CBDCEE] flex items-center justify-end gap-3">
                <button
                  onClick={() => setSelectedStyleModal(null)}
                  className="px-4 py-2 text-xs font-semibold text-[#475E7B] hover:text-[#0B1A30] cursor-pointer"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    const id = selectedStyleModal.id;
                    setSelectedStyleModal(null);
                    onSelectStyleForBooking(id);
                  }}
                  className="px-5 py-2.5 text-xs font-semibold text-white bg-[#0D2444] hover:bg-[#07162B] rounded-lg shadow-sm flex items-center gap-2 cursor-pointer border border-[#1B3E6E]"
                >
                  <span>Book for ₹{selectedStyleModal.priceINR.toLocaleString('en-IN')}</span>
                  <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
                </button>
              </div>

            </div>
          </div>
        )}

      </div>
    </section>
  );
};
