import React, { useState } from 'react';
import { Menu, X, Sparkles, MessageCircle, Calendar, Phone, MapPin, ShieldCheck, Database } from 'lucide-react';
import { STUDIO_INFO } from '../data/drapingData';

interface NavbarProps {
  onOpenBooking: (serviceId?: string) => void;
  onOpenQuiz: () => void;
  onOpenAdminBookings?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenBooking, onOpenQuiz, onOpenAdminBookings }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { name: 'Styles', href: '#styles' },
    { name: 'Services & Pricing', href: '#services' },
    { name: 'Lookbook', href: '#lookbook' },
    { name: 'Location & Map', href: '#location' },
    { name: 'Our Craft', href: '#craft' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'FAQ', href: '#faq' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#F0F5FA]/95 backdrop-blur-md border-b border-[#CBDCEE] transition-all">
      {/* Top micro announcement bar */}
      <div className="bg-[#0B1A30] text-[#F0F6FC] py-1.5 px-4 text-xs font-medium text-center flex items-center justify-center gap-3 flex-wrap">
        <span className="font-semibold text-[#D4AF37]">✨ Saree Draping Starts from ₹1,500</span>
        <span className="text-[#D4AF37]">·</span>
        <span>Wedding Bridal ₹3,000 · Kerala Style ₹2,500 · Bharatanatyam ₹4,000 · Indian Saree ₹2,000 · Kacha Saree ₹4,000</span>
        <span className="text-[#D4AF37]">·</span>
        <span className="hidden sm:inline">📍 Vittasandra Main Rd (near Keerthi Chicken Center), Bangalore South</span>
        <span className="text-[#D4AF37]">·</span>
        <button 
          onClick={onOpenQuiz} 
          className="text-[#D4AF37] hover:underline cursor-pointer inline-flex items-center gap-1 font-semibold"
        >
          <Sparkles className="w-3 h-3" />
          Find Your Drape Quiz
        </button>
        {onOpenAdminBookings && (
          <>
            <span className="text-[#D4AF37]">·</span>
            <button
              onClick={onOpenAdminBookings}
              className="text-[#84CA97] hover:underline cursor-pointer inline-flex items-center gap-1 font-medium text-[11px]"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#84CA97] inline-block animate-pulse" />
              <span>Supabase Database</span>
            </button>
          </>
        )}
      </div>

      {/* Main Top Bar strictly fulfilling 3-zone contract */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Zone 1: Single text wordmark */}
        <a href="#" className="flex flex-col group">
          <span className="font-serif text-2xl sm:text-3xl font-bold tracking-wider text-[#0B1A30] group-hover:text-[#183760] transition-colors">
            GEETHA SAREE DRAPING
          </span>
          <span className="text-[10px] tracking-[0.2em] uppercase text-[#475E7B] font-semibold -mt-1">
            Vittasandra Main Road, Bangalore South · Starts from ₹1,500
          </span>
        </a>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-[#2F445E]">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="hover:text-[#0B1A30] transition-colors tracking-wide py-1 border-b border-transparent hover:border-[#D4AF37]"
            >
              {link.name}
            </a>
          ))}
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2.5">
          <a
            href={`tel:${STUDIO_INFO.phone}`}
            aria-label="Call Geetha"
            className="hidden sm:flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#0B1A30] bg-[#E2EDFA] rounded-lg hover:bg-[#D4E4F5] transition-colors border border-[#CBDCEE]"
          >
            <Phone className="w-3.5 h-3.5 text-[#183760]" />
            <span className="whitespace-nowrap font-bold tabular-nums">{STUDIO_INFO.phone}</span>
          </a>

          <a
            href={`https://wa.me/${STUDIO_INFO.whatsappNumber}?text=Hello%20Geetha!%20I%20would%20like%20to%20inquire%20about%20saree%20draping%20availability.`}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Chat on WhatsApp"
            className="hidden md:flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#18281F] bg-[#E9F3EB] rounded-lg hover:bg-[#D4E8D8] transition-colors border border-[#C5DEC8]"
          >
            <MessageCircle className="w-4 h-4 text-[#1E562A]" />
            <span className="whitespace-nowrap">WhatsApp</span>
          </a>

          <button
            onClick={() => onOpenBooking()}
            className="flex items-center gap-2 px-4 sm:px-5 py-2.5 text-xs sm:text-sm font-semibold tracking-wide text-[#FDFBF7] bg-[#0D2444] hover:bg-[#07162B] rounded-lg shadow-sm hover:shadow transition-all whitespace-nowrap cursor-pointer border border-[#1B3E6E]"
          >
            <Calendar className="w-4 h-4 text-[#D4AF37]" />
            <span>Book a Stylist</span>
          </button>

          {onOpenAdminBookings && (
            <button
              onClick={onOpenAdminBookings}
              className="hidden lg:flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#1E562A] bg-[#EAF5EC] hover:bg-[#D4EBD7] rounded-lg transition-colors border border-[#BDDEC1] cursor-pointer"
              title="Admin Panel — Manage, edit, cancel and view all Supabase bookings"
            >
              <ShieldCheck className="w-4 h-4 text-[#1E562A]" />
              <span>Admin Panel</span>
            </button>
          )}

          {/* Mobile menu trigger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg text-[#0B1A30] hover:bg-[#E2EDFA] lg:hidden cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#E8F1FA] border-b border-[#CBDCEE] px-6 py-5 space-y-4 shadow-lg animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="flex flex-col space-y-3">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-base font-medium text-[#0B1A30] hover:text-[#183760] py-1 border-b border-[#D8E6F5]"
              >
                {link.name}
              </a>
            ))}
          </div>

          <div className="pt-2 flex flex-col gap-2.5">
            <a
              href={`tel:${STUDIO_INFO.phone}`}
              className="w-full py-2.5 text-xs font-semibold text-center text-[#0B1A30] bg-white rounded-lg border border-[#CBDCEE] flex items-center justify-center gap-2"
            >
              <Phone className="w-4 h-4 text-[#183760]" />
              Call Geetha: {STUDIO_INFO.phone}
            </a>

            <a
              href={`https://wa.me/${STUDIO_INFO.whatsappNumber}?text=Hello%20Geetha!%20I%20would%20like%20to%20inquire%20about%20saree%20draping.`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 text-xs font-semibold text-center text-[#1E562A] bg-[#E9F3EB] rounded-lg border border-[#C5DEC8] flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4" />
              WhatsApp Booking Available
            </a>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenQuiz();
              }}
              className="w-full py-2.5 text-xs font-semibold text-[#0B1A30] bg-[#D8E8F8] rounded-lg hover:bg-[#C9DEF3] flex items-center justify-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-[#9E7418]" />
              Find Your Signature Drape (30s Quiz)
            </button>

            {onOpenAdminBookings && (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAdminBookings();
                }}
                className="w-full py-2.5 text-xs font-semibold text-[#1E562A] bg-[#EAF5EC] hover:bg-[#D4EBD7] rounded-lg border border-[#BDDEC1] flex items-center justify-center gap-2 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4 text-[#1E562A]" />
                <span>Admin Panel (Manage Supabase Orders)</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
