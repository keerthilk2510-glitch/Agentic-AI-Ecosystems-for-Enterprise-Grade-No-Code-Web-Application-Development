import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';

export const WhatsAppWidget: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-40 flex items-center gap-3">
      {/* Tooltip speech bubble */}
      {showTooltip && (
        <div className="hidden sm:flex items-center gap-2 bg-white text-[#0B1A30] text-xs font-medium py-2 px-3 rounded-lg shadow-lg border border-[#CBDCEE] animate-in fade-in slide-in-from-right-2">
          <span>Need rapid styling advice or date check?</span>
          <button
            onClick={() => setShowTooltip(false)}
            className="text-[#607D9F] hover:text-[#0B1A30] p-0.5 cursor-pointer"
            aria-label="Close tooltip"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Floating Button */}
      <a
        href="https://wa.me/918050566063?text=Hello%20Geetha!%20I%20would%20like%20to%20inquire%20about%20saree%20draping%20at%20Vittasandra%20Main%20Road."
        target="_blank"
        rel="noopener noreferrer"
        onMouseEnter={() => setShowTooltip(true)}
        aria-label="Direct WhatsApp Concierge 8050566063"
        className="w-13 h-13 rounded-full bg-[#1E562A] hover:bg-[#164420] text-white flex items-center justify-center shadow-xl hover:scale-105 transition-all border-2 border-white cursor-pointer group"
      >
        <MessageCircle className="w-6 h-6 text-white" />
      </a>
    </div>
  );
};
