import React from 'react';
import { SERVICE_PACKAGES } from '../data/drapingData';
import { Check, Sparkles, Clock, ArrowRight } from 'lucide-react';

interface ServicesPricingProps {
  onSelectPackageForBooking: (packageId: string) => void;
}

export const ServicesPricing: React.FC<ServicesPricingProps> = ({ onSelectPackageForBooking }) => {
  return (
    <section id="services" className="py-16 lg:py-24 bg-[#F0F5FA] border-b border-[#CBDCEE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="space-y-3 max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#9E7418]">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Transparent Pricing Packages</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1A30]">
              Saree Draping Services & Pricing
            </h2>
            <p className="text-base text-[#384F6B] leading-relaxed">
              Affordable, professional saree draping by Geetha. Prices start from <strong className="text-[#1E562A]">₹1,500</strong> with dedicated rates for Wedding Bridal (₹3,000), Kerala Style (₹2,500), Bharatanatyam (₹4,000), Indian Saree (₹2,000), and Kacha Saree Style (₹4,000). Located on Vittasandra Main Road, Bangalore South.
            </p>
          </div>

          <div className="bg-[#E1ECF7] px-4 py-2 rounded-lg border border-[#99BEE3] text-xs text-[#0B1A30] font-semibold self-start md:self-auto shadow-2xs">
            💰 Saree Draping Starts from ₹1,500 · Call 8050566063
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICE_PACKAGES.map((pkg) => {
            const isSignature = pkg.popular;

            return (
              <div
                key={pkg.id}
                className={`rounded-xl border transition-all flex flex-col justify-between relative ${
                  isSignature
                    ? 'bg-gradient-to-b from-[#FFFFFF] to-[#EFF5FC] border-2 border-[#D4AF37] shadow-lg scale-[1.01]'
                    : 'bg-white border-[#CBDCEE] shadow-xs hover:shadow-md hover:border-[#1E467B]'
                }`}
              >
                {/* Popular / Signature Tag */}
                {isSignature && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-[#0D2444] text-[#D4AF37] text-[11px] font-semibold tracking-wider uppercase px-3 py-1 rounded-md border border-[#D4AF37]/50 shadow-xs">
                    Specialist Styling
                  </div>
                )}

                {/* Top Section */}
                <div className="p-6 sm:p-7 space-y-5">
                  <div className="space-y-1">
                    <span className="text-[11px] uppercase tracking-wider font-semibold text-[#9E7418]">
                      {pkg.badge}
                    </span>
                    <h3 className="font-serif text-2xl font-bold text-[#0B1A30]">
                      {pkg.name}
                    </h3>
                    <p className="text-xs text-[#475E7B] leading-relaxed">
                      {pkg.tagline}
                    </p>
                  </div>

                  {/* Price & Duration in Rupees */}
                  <div className="pt-3 border-t border-[#E1EDFA] flex items-baseline justify-between">
                    <div>
                      <span className="font-serif text-3xl font-bold text-[#0B1A30] tabular-nums">
                        ₹{pkg.priceINR.toLocaleString('en-IN')}
                      </span>
                      <span className="text-xs text-[#556F8C] ml-1">/ person</span>
                    </div>

                    <div className="flex items-center gap-1 text-xs text-[#334A65] bg-[#F0F5FA] px-2.5 py-1 rounded-md border border-[#CBDCEE]">
                      <Clock className="w-3.5 h-3.5 text-[#9E7418]" />
                      <span>{pkg.durationMinutes} mins</span>
                    </div>
                  </div>

                  {/* Ideal For */}
                  <div className="text-[11px] text-[#334A65] bg-[#EAF2FA] p-2.5 rounded-lg border border-[#CBDCEE]">
                    <strong className="text-[#0B1A30] font-semibold">Best suited for: </strong>
                    {pkg.bestFor}
                  </div>

                  {/* Features List */}
                  <div className="space-y-2.5 pt-2">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-[#0B1A30]">
                      What's Included:
                    </div>
                    <ul className="space-y-2 text-xs text-[#384F6B]">
                      {pkg.features.map((feat, index) => (
                        <li key={index} className="flex items-start gap-2.5">
                          <Check className="w-3.5 h-3.5 text-[#1E562A] shrink-0 mt-0.5" />
                          <span className="leading-snug">{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Bottom Action */}
                <div className="p-6 sm:p-7 pt-0">
                  <button
                    onClick={() => onSelectPackageForBooking(pkg.id)}
                    className={`w-full py-3 px-4 rounded-lg font-semibold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      isSignature
                        ? 'bg-[#0D2444] hover:bg-[#07162B] text-[#FDFBF7] shadow-sm border border-[#1B3E6E]'
                        : 'bg-[#E2EDFA] hover:bg-[#D4E4F5] text-[#0B1A30] border border-[#CBDCEE]'
                    }`}
                  >
                    <span>Book for ₹{pkg.priceINR.toLocaleString('en-IN')}</span>
                    <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>

        {/* Group / Squad Note */}
        <div className="mt-12 bg-[#EAF2FA] border border-[#CBDCEE] rounded-xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <h4 className="font-serif text-xl font-bold text-[#0B1A30]">
              Booking for Bridesmaids, Dance Troupe or Family Group?
            </h4>
            <p className="text-xs text-[#475E7B]">
              We offer special group packages starting from ₹700 per person for guest draping, plus on-site visits directly to your marriage hall, dance auditorium, or hotel.
            </p>
          </div>
          <button
            onClick={() => onSelectPackageForBooking('basic-guest-draping')}
            className="px-5 py-2.5 text-xs font-semibold text-[#0B1A30] bg-white border border-[#CBDCEE] hover:border-[#183760] rounded-lg shadow-xs cursor-pointer whitespace-nowrap"
          >
            Inquire Group Draping
          </button>
        </div>

      </div>
    </section>
  );
};
