import React, { useState } from 'react';
import { FAQS } from '../data/drapingData';
import { ChevronDown, Sparkles, MessageCircle, Send, CheckCircle2, MapPin } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [openFaqId, setOpenFaqId] = useState<string>(FAQS[0].id);
  const [contactSubmitted, setContactSubmitted] = useState<boolean>(false);
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formMessage, setFormMessage] = useState('');

  const categories = ['All', 'Preparation & Safety', 'Services & Timing', 'Fabrics & Sizing', 'Travel & Booking'];

  const filteredFaqs = FAQS.filter(faq => {
    if (activeCategory === 'All') return true;
    return faq.category === activeCategory;
  });

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSubmitted(true);
    setTimeout(() => {
      setContactSubmitted(false);
      setFormName('');
      setFormEmail('');
      setFormPhone('');
      setFormMessage('');
    }, 4000);
  };

  return (
    <section id="faq" className="py-16 lg:py-24 bg-[#F0F5FA] border-b border-[#CBDCEE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#9E7418]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Answers & Inquiries</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1A30]">
            Frequently Asked Questions
          </h2>
          <p className="text-base text-[#384F6B] leading-relaxed">
            Everything you need to know about preparing your saree, booking our master stylists, and our pinless-feel guarantee.
          </p>

          {/* Category Tabs */}
          <div className="flex items-center justify-center gap-1.5 p-1 bg-[#D8E6F5] rounded-lg mt-2 overflow-x-auto max-w-full">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer whitespace-nowrap ${
                  activeCategory === cat
                    ? 'bg-[#0D2444] text-[#FDFBF7] shadow-xs'
                    : 'text-[#384F6B] hover:text-[#0B1A30]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* FAQs & Contact Form Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Left Column: FAQ Accordion */}
          <div className="lg:col-span-7 space-y-3">
            {filteredFaqs.map((faq) => {
              const isOpen = openFaqId === faq.id;
              return (
                <div
                  key={faq.id}
                  className="bg-white rounded-xl border border-[#CBDCEE] overflow-hidden transition-all shadow-xs"
                >
                  <button
                    onClick={() => setOpenFaqId(isOpen ? '' : faq.id)}
                    className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-[#F2F7FC] transition-colors"
                  >
                    <span className="font-serif text-base sm:text-lg font-bold text-[#0B1A30]">
                      {faq.question}
                    </span>
                    <ChevronDown
                      className={`w-4 h-4 text-[#9E7418] shrink-0 transition-transform duration-200 ${
                        isOpen ? 'rotate-180' : ''
                      }`}
                    />
                  </button>

                  {isOpen && (
                    <div className="px-5 pb-5 text-xs sm:text-sm text-[#384F6B] leading-relaxed border-t border-[#E1EDFA] pt-3 animate-in fade-in duration-150">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Right Column: Direct Contact & Quick WhatsApp Card */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Quick Contact Form */}
            <div className="bg-white rounded-2xl border border-[#CBDCEE] p-6 sm:p-8 space-y-5 shadow-sm">
              <div className="space-y-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#9E7418]">
                  Concierge Desk
                </span>
                <h3 className="font-serif text-2xl font-bold text-[#0B1A30]">
                  Send a Custom Inquiry
                </h3>
                <p className="text-xs text-[#556F8C]">
                  Need bridal troupe styling or a custom destination package? Leave a note.
                </p>
              </div>

              {contactSubmitted ? (
                <div className="p-5 bg-[#EAF5EC] border border-[#A8DBB4] rounded-xl text-center space-y-2 animate-in fade-in">
                  <CheckCircle2 className="w-8 h-8 text-[#1E562A] mx-auto" />
                  <h4 className="font-serif text-lg font-bold text-[#1E562A]">Inquiry Received</h4>
                  <p className="text-xs text-[#345B3C]">
                    Our atelier coordinator will reach out to you within 2 business hours via email or WhatsApp.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-3.5 text-xs">
                  <div>
                    <label className="block text-[11px] font-semibold text-[#384F6B] mb-1">Your Name</label>
                    <input
                      type="text"
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      placeholder="e.g., Deepika Verma"
                      required
                      className="w-full px-3 py-2 bg-[#F0F5FA] border border-[#CBDCEE] rounded-lg text-xs text-[#0B1A30] focus:outline-none focus:border-[#183760]"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-[#384F6B] mb-1">Email</label>
                      <input
                        type="email"
                        value={formEmail}
                        onChange={(e) => setFormEmail(e.target.value)}
                        placeholder="deepika@example.com"
                        required
                        className="w-full px-3 py-2 bg-[#F0F5FA] border border-[#CBDCEE] rounded-lg text-xs text-[#0B1A30] focus:outline-none focus:border-[#183760]"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-[#384F6B] mb-1">Mobile / WhatsApp</label>
                      <input
                        type="tel"
                        value={formPhone}
                        onChange={(e) => setFormPhone(e.target.value)}
                        placeholder="+91 8050566063"
                        required
                        className="w-full px-3 py-2 bg-[#F0F5FA] border border-[#CBDCEE] rounded-lg text-xs text-[#0B1A30] focus:outline-none focus:border-[#183760]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-[#384F6B] mb-1">Event Date & Message</label>
                    <textarea
                      rows={3}
                      value={formMessage}
                      onChange={(e) => setFormMessage(e.target.value)}
                      placeholder="Tell us about your wedding date, number of sarees, and special requirements..."
                      required
                      className="w-full px-3 py-2 bg-[#F0F5FA] border border-[#CBDCEE] rounded-lg text-xs text-[#0B1A30] focus:outline-none focus:border-[#183760]"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-[#0D2444] hover:bg-[#07162B] text-white font-semibold rounded-lg shadow-xs flex items-center justify-center gap-2 cursor-pointer transition-colors border border-[#1B3E6E]"
                  >
                    <Send className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Send Message to Stylist</span>
                  </button>
                </form>
              )}

              {/* Direct Instant WhatsApp Box */}
              <div className="pt-4 border-t border-[#E1EDFA]">
                <a
                  href="https://wa.me/918050566063?text=Hello%20Geetha!%20I%20have%20an%20urgent%20saree%20styling%20inquiry."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 bg-[#E9F3EB] hover:bg-[#D4E8D8] text-[#1E562A] font-semibold text-xs rounded-lg border border-[#C5DEC8] flex items-center justify-center gap-2 transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>WhatsApp Geetha (8050566063)</span>
                </a>
              </div>

            </div>

            {/* Studio Hours & Address */}
            <div className="bg-[#EDF4FB] p-5 rounded-xl border border-[#CBDCEE] space-y-2 text-xs text-[#334A65]">
              <div className="flex items-center gap-2 font-bold text-[#0B1A30]">
                <MapPin className="w-4 h-4 text-[#9E7418]" />
                <span>Geetha Saree Draping Studio:</span>
              </div>
              <p className="pl-6 text-[#556F8C] leading-relaxed">
                Vittasandra Main Road, Near Keerthi Chicken Center,<br />
                Bangalore South, Karnataka 560100.<br />
                Call: <a href="tel:8050566063" className="font-bold text-[#1E562A] hover:underline">8050566063</a> · Open 7 Days: 05:30 AM – 09:30 PM
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
