import React, { useState } from 'react';
import { X, Sparkles, ArrowRight, Check, RotateCcw } from 'lucide-react';
import { DRAPING_STYLES } from '../data/drapingData';
import { DrapingStyle } from '../types';

interface StyleRecommenderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectRecommendedStyle: (styleId: string) => void;
}

export const StyleRecommenderModal: React.FC<StyleRecommenderModalProps> = ({
  isOpen,
  onClose,
  onSelectRecommendedStyle
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [occasion, setOccasion] = useState<string>('Bridal');
  const [fabric, setFabric] = useState<string>('Silk');
  const [silhouette, setSilhouette] = useState<string>('Traditional');

  if (!isOpen) return null;

  const occasions = [
    { id: 'Bridal', label: 'Wedding Bridal / Muhurtham (₹3,000)', desc: 'Heavy Kanjeevaram / Zardozi, double drape, veil & 12-hour locked pleats' },
    { id: 'Dance', label: 'Bharatanatyam / Classical Stage (₹4,000)', desc: 'Stage-performance accordion fan pleats & pyjama katcham leg wrap' },
    { id: 'Kerala', label: 'Kerala Wedding / Temple / Onam (₹2,500)', desc: 'Kasavu & Set Mundu with symmetric gold zari kara alignment' },
    { id: 'Traditional', label: 'Kacha Saree Style / Madisar / Nauvari (₹4,000)', desc: 'Ancestral 9-yard kacha dhoti wrap with back kashta tuck' },
    { id: 'Reception', label: 'Indian Saree Draping (₹2,000)', desc: 'Classic Nivi, Reception, Sangeet & family festive functions' },
    { id: 'Guest', label: 'Basic / Guest Draping (Starts from ₹700)', desc: 'Quick 15-minute neat draping for guests and bridesmaids' }
  ];

  const fabrics = [
    { id: 'Silk', label: 'Pure Kanjeevaram / Banarasi Silk', desc: 'Heavy zari border, traditional wedding & bridal silk' },
    { id: 'Kasavu', label: 'Kerala Kasavu / Set Mundu Cotton & Silk', desc: 'Ivory base with pure gold or copper zari border' },
    { id: 'DanceSilk', label: 'Bharatanatyam Classical Dance Silk', desc: 'Specially woven contrast border silk for dance costumes' },
    { id: 'NineYard', label: '9-Yard Silk (Madisar / Paithani Nauvari)', desc: 'Long 9-meter weave required for kacha bifurcated drape' },
    { id: 'Fluid', label: 'Georgette / Chiffon / Organza', desc: 'Fluid or crisp party wear saree requiring anti-slip pins' },
  ];

  const silhouettes = [
    { id: 'Bridal', label: 'Royal Wedding Bridal Silhouette (₹3,000)', desc: '11 knife pleats, veil fixing & bridal emergency kit' },
    { id: 'Dance', label: 'Bharatanatyam Stage Costume (₹4,000)', desc: 'Dynamic fan pleats opening during aramandi sitting postures' },
    { id: 'Kerala', label: 'Kerala Kasavu Traditional (₹2,500)', desc: 'Crisp gold kara symmetry with jasmine veni alignment' },
    { id: 'Kacha', label: 'Kacha Dhoti / Madisar Style (₹4,000)', desc: 'Bifurcated leg drape with back kashta for ritual ease' },
    { id: 'Indian', label: 'Classic Indian Saree Drape (₹2,000)', desc: 'Sleek hourglass pleats for receptions and festive wear' },
    { id: 'Basic', label: 'Basic Guest Saree Drape (From ₹700)', desc: 'Fast and neat 15-minute turnaround for wedding attendees' }
  ];

  const getRecommendation = (): DrapingStyle => {
    if (occasion === 'Dance' || silhouette === 'Dance' || fabric === 'DanceSilk') {
      return DRAPING_STYLES.find(s => s.id === 'bharatanatyam-dance') || DRAPING_STYLES[2];
    }
    if (occasion === 'Kerala' || silhouette === 'Kerala' || fabric === 'Kasavu') {
      return DRAPING_STYLES.find(s => s.id === 'kerala-style') || DRAPING_STYLES[1];
    }
    if (occasion === 'Traditional' || silhouette === 'Kacha' || fabric === 'NineYard') {
      return DRAPING_STYLES.find(s => s.id === 'kacha-saree-style') || DRAPING_STYLES[3];
    }
    if (occasion === 'Guest' || silhouette === 'Basic') {
      return DRAPING_STYLES.find(s => s.id === 'basic-guest-draping') || DRAPING_STYLES[5];
    }
    if (occasion === 'Bridal' || silhouette === 'Bridal') {
      return DRAPING_STYLES.find(s => s.id === 'wedding-bridal') || DRAPING_STYLES[0];
    }
    return DRAPING_STYLES.find(s => s.id === 'indian-saree-classic') || DRAPING_STYLES[4];
  };

  const recommendedStyle = getRecommendation();

  const resetQuiz = () => {
    setCurrentStep(1);
    setOccasion('Bridal');
    setFabric('Silk');
    setSilhouette('Traditional');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-[#F8FAFD] rounded-2xl border border-[#CBDCEE] max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 text-[#556F8C] hover:text-[#0B1A30] rounded-lg hover:bg-[#E2EDFA] transition-colors cursor-pointer"
          aria-label="Close Quiz"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#9E7418]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>30-Second Drape Recommender</span>
          </div>
          <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#0B1A30]">
            Find Your Signature Drape
          </h3>
          <p className="text-xs text-[#475E7B]">
            Tell us about your celebration and saree fabric; we will calculate the most flattering drape geometry for you.
          </p>
        </div>

        {/* Steps */}
        {currentStep === 1 && (
          <div className="space-y-4 animate-in fade-in">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#0B1A30]">
              Step 1 of 3: What is the celebration occasion?
            </h4>
            <div className="space-y-2">
              {occasions.map(occ => (
                <div
                  key={occ.id}
                  onClick={() => setOccasion(occ.id)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all text-left ${
                    occasion === occ.id
                      ? 'bg-[#EFF5FC] border-[#0D2444] shadow-xs ring-1 ring-[#0D2444]'
                      : 'bg-white border-[#CBDCEE] hover:border-[#183760]'
                  }`}
                >
                  <div className="text-xs font-bold text-[#0B1A30]">{occ.label}</div>
                  <div className="text-[11px] text-[#475E7B]">{occ.desc}</div>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setCurrentStep(2)}
                className="px-5 py-2.5 bg-[#0D2444] hover:bg-[#07162B] text-white text-xs font-semibold rounded-lg flex items-center gap-2 cursor-pointer border border-[#1B3E6E]"
              >
                <span>Next: Saree Fabric</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#D4AF37]" />
              </button>
            </div>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-4 animate-in fade-in">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#0B1A30]">
              Step 2 of 3: What fabric is your saree?
            </h4>
            <div className="space-y-2">
              {fabrics.map(fab => (
                <div
                  key={fab.id}
                  onClick={() => setFabric(fab.id)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all text-left ${
                    fabric === fab.id
                      ? 'bg-[#EFF5FC] border-[#0D2444] shadow-xs ring-1 ring-[#0D2444]'
                      : 'bg-white border-[#CBDCEE] hover:border-[#183760]'
                  }`}
                >
                  <div className="text-xs font-bold text-[#0B1A30]">{fab.label}</div>
                  <div className="text-[11px] text-[#475E7B]">{fab.desc}</div>
                </div>
              ))}
            </div>

            <div className="flex justify-between pt-2">
              <button
                onClick={() => setCurrentStep(1)}
                className="px-4 py-2 border border-[#CBDCEE] text-xs font-semibold rounded-lg text-[#384F6B] hover:bg-[#F0F5FA] cursor-pointer"
              >
                Back
              </button>
              <button
                onClick={() => setCurrentStep(3)}
                className="px-5 py-2.5 bg-[#0D2444] hover:bg-[#07162B] text-white text-xs font-semibold rounded-lg flex items-center gap-2 cursor-pointer border border-[#1B3E6E]"
              >
                <span>Next: Preferred Silhouette</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#D4AF37]" />
              </button>
            </div>
          </div>
        )}

        {currentStep === 3 && (
          <div className="space-y-4 animate-in fade-in">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#0B1A30]">
              Step 3 of 3: Which silhouette vibe resonates with you?
            </h4>
            <div className="space-y-2">
              {silhouettes.map(sil => (
                <div
                  key={sil.id}
                  onClick={() => setSilhouette(sil.id)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all text-left ${
                    silhouette === sil.id
                      ? 'bg-[#EFF5FC] border-[#0D2444] shadow-xs ring-1 ring-[#0D2444]'
                      : 'bg-white border-[#CBDCEE] hover:border-[#183760]'
                  }`}
                >
                  <div className="text-xs font-bold text-[#0B1A30]">{sil.label}</div>
                  <div className="text-[11px] text-[#475E7B]">{sil.desc}</div>
                </div>
              ))}
            </div>

            <div className="flex justify-between pt-2">
              <button
                onClick={() => setCurrentStep(2)}
                className="px-4 py-2 border border-[#CBDCEE] text-xs font-semibold rounded-lg text-[#384F6B] hover:bg-[#F0F5FA] cursor-pointer"
              >
                Back
              </button>
              <button
                onClick={() => setCurrentStep(4)}
                className="px-5 py-2.5 bg-[#0D2444] hover:bg-[#07162B] text-white text-xs font-semibold rounded-lg flex items-center gap-2 cursor-pointer shadow-sm border border-[#1B3E6E]"
              >
                <span>View Recommended Drape</span>
                <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              </button>
            </div>
          </div>
        )}

        {/* RESULTS SCREEN */}
        {currentStep === 4 && (
          <div className="space-y-5 animate-in fade-in">
            <div className="bg-[#E1ECF7] p-5 rounded-xl border border-[#99BEE3] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#183760]">
                  98% Match for your {occasion} & {fabric}
                </span>
                <span className="text-[11px] text-[#1E562A] font-semibold bg-[#E5F5E9] px-2 py-0.5 rounded">
                  Top Recommended
                </span>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-20 h-20 rounded-lg overflow-hidden bg-white shrink-0 border border-[#CBDCEE]">
                  <img
                    src={recommendedStyle.image}
                    alt={recommendedStyle.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-serif text-xl font-bold text-[#0B1A30]">
                    {recommendedStyle.name}
                  </h4>
                  <p className="text-xs text-[#475E7B] italic">
                    {recommendedStyle.subtitle}
                  </p>
                  <p className="text-xs text-[#334A65] mt-1 line-clamp-2">
                    {recommendedStyle.description}
                  </p>
                </div>
              </div>

              <div className="pt-2 border-t border-[#CBDCEE] text-xs text-[#334A65] space-y-1">
                <div>
                  <span className="font-semibold text-[#0B1A30]">Pleat Setup: </span>
                  {recommendedStyle.pleatCount}
                </div>
                <div>
                  <span className="font-semibold text-[#0B1A30]">Stylist Secret: </span>
                  {recommendedStyle.stylingTips}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={resetQuiz}
                className="flex items-center gap-1.5 text-xs font-semibold text-[#475E7B] hover:text-[#0B1A30] cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Start Over</span>
              </button>

              <button
                onClick={() => {
                  onClose();
                  onSelectRecommendedStyle(recommendedStyle.id);
                }}
                className="px-5 py-2.5 bg-[#0D2444] hover:bg-[#07162B] text-white text-xs font-semibold rounded-lg flex items-center gap-2 cursor-pointer shadow-sm border border-[#1B3E6E]"
              >
                <span>Book This Drape</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#D4AF37]" />
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
