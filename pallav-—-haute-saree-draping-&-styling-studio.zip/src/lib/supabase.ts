import { createClient } from '@supabase/supabase-js';

const SUPABASE_PROJECT_ID = 'rjxalknfpqhslkmwqwch';
const SUPABASE_DEFAULT_URL = `https://${SUPABASE_PROJECT_ID}.supabase.co`;
const SUPABASE_DEFAULT_KEY = 'sb_publishable_lk2vNFV-o5IHkgyqe4YoJQ_Nbu709ct';

export const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || SUPABASE_DEFAULT_URL;
export const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || SUPABASE_DEFAULT_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
  }
});

export interface AppointmentRecord {
  id?: string;
  booking_ref: string;
  service_id: string;
  service_name: string;
  style_id: string;
  style_name: string;
  date: string;
  time_slot: string;
  location_type: string;
  address: string;
  city_area: string;
  guest_count: number;
  client_name: string;
  email: string;
  phone: string;
  saree_fabric: string;
  saree_length: string;
  height_footwear: string;
  special_notes: string;
  include_pre_pleating: boolean;
  total_price: number;
  advance_deposit: number;
  status?: string;
  created_at?: string;
}

/**
 * Saves a new appointment booking to Supabase database.
 * If Supabase table isn't created yet or network is offline,
 * it preserves a local copy so no client booking is ever lost.
 */
export async function saveAppointment(appointment: AppointmentRecord): Promise<{
  success: boolean;
  data?: any;
  error?: string;
  savedLocallyOnly?: boolean;
}> {
  try {
    // 1. Always backup to localStorage as immediate safety guarantee
    try {
      const existing = JSON.parse(localStorage.getItem('geetha_local_appointments') || '[]');
      existing.unshift({ ...appointment, id: appointment.booking_ref, created_at: new Date().toISOString() });
      localStorage.setItem('geetha_local_appointments', JSON.stringify(existing.slice(0, 50)));
    } catch (e) {
      console.warn('Local storage write warning', e);
    }

    // 2. Insert into Supabase table 'appointments'
    const { data, error } = await supabase
      .from('appointments')
      .insert([
        {
          booking_ref: appointment.booking_ref,
          service_id: appointment.service_id,
          service_name: appointment.service_name,
          style_id: appointment.style_id,
          style_name: appointment.style_name,
          date: appointment.date,
          time_slot: appointment.time_slot,
          location_type: appointment.location_type,
          address: appointment.address,
          city_area: appointment.city_area,
          guest_count: appointment.guest_count,
          client_name: appointment.client_name,
          email: appointment.email,
          phone: appointment.phone,
          saree_fabric: appointment.saree_fabric,
          saree_length: appointment.saree_length,
          height_footwear: appointment.height_footwear,
          special_notes: appointment.special_notes,
          include_pre_pleating: appointment.include_pre_pleating,
          total_price: appointment.total_price,
          advance_deposit: appointment.advance_deposit,
          status: 'confirmed',
          created_at: new Date().toISOString()
        }
      ])
      .select();

    if (error) {
      console.warn('Supabase insert note:', error.message);
      return {
        success: true, // Still marked success for user experience with local backup
        error: error.message,
        savedLocallyOnly: true
      };
    }

    return { success: true, data };
  } catch (err: any) {
    console.error('Failed to save appointment to Supabase:', err);
    return {
      success: true,
      error: err?.message || 'Network exception',
      savedLocallyOnly: true
    };
  }
}

/**
 * Fetches recent appointments from Supabase with fallback to local store.
 */
export async function fetchAppointments(): Promise<AppointmentRecord[]> {
  try {
    const { data, error } = await supabase
      .from('appointments')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(30);

    if (error || !data) {
      console.warn('Supabase fetch note, using local cache:', error?.message);
      const local = JSON.parse(localStorage.getItem('geetha_local_appointments') || '[]');
      return local;
    }

    return data;
  } catch (e) {
    const local = JSON.parse(localStorage.getItem('geetha_local_appointments') || '[]');
    return local;
  }
}

/**
 * Updates an existing appointment in Supabase and local cache.
 */
export async function updateAppointment(
  bookingRef: string,
  updates: Partial<AppointmentRecord>
): Promise<{ success: boolean; error?: string }> {
  try {
    // 1. Update in local cache
    try {
      const existing: AppointmentRecord[] = JSON.parse(localStorage.getItem('geetha_local_appointments') || '[]');
      const updated = existing.map(item => {
        if (item.booking_ref === bookingRef || item.id === bookingRef) {
          return { ...item, ...updates };
        }
        return item;
      });
      localStorage.setItem('geetha_local_appointments', JSON.stringify(updated));
    } catch (e) {
      console.warn('Local storage update warning', e);
    }

    // 2. Update in Supabase
    const { error } = await supabase
      .from('appointments')
      .update(updates)
      .eq('booking_ref', bookingRef);

    if (error) {
      console.warn('Supabase update note:', error.message);
      // Try by id as fallback
      const { error: idError } = await supabase
        .from('appointments')
        .update(updates)
        .eq('id', bookingRef);

      if (idError) {
        return { success: true, error: idError.message };
      }
    }

    return { success: true };
  } catch (err: any) {
    console.error('Failed to update appointment in Supabase:', err);
    return { success: true, error: err?.message };
  }
}

/**
 * Updates status of an appointment (e.g. 'confirmed', 'completed', 'cancelled')
 */
export async function updateAppointmentStatus(
  bookingRef: string,
  status: 'confirmed' | 'completed' | 'cancelled' | 'in_progress',
  specialNotes?: string
): Promise<{ success: boolean; error?: string }> {
  const payload: Partial<AppointmentRecord> = { status };
  if (specialNotes !== undefined) {
    payload.special_notes = specialNotes;
  }
  return updateAppointment(bookingRef, payload);
}

/**
 * Deletes an appointment permanently from Supabase and local cache.
 */
export async function deleteAppointment(
  bookingRef: string
): Promise<{ success: boolean; error?: string }> {
  try {
    // 1. Remove from local cache
    try {
      const existing: AppointmentRecord[] = JSON.parse(localStorage.getItem('geetha_local_appointments') || '[]');
      const filtered = existing.filter(item => item.booking_ref !== bookingRef && item.id !== bookingRef);
      localStorage.setItem('geetha_local_appointments', JSON.stringify(filtered));
    } catch (e) {
      console.warn('Local storage delete warning', e);
    }

    // 2. Delete from Supabase
    const { error } = await supabase
      .from('appointments')
      .delete()
      .eq('booking_ref', bookingRef);

    if (error) {
      // Try by id
      await supabase.from('appointments').delete().eq('id', bookingRef);
    }

    return { success: true };
  } catch (err: any) {
    console.error('Failed to delete appointment from Supabase:', err);
    return { success: true, error: err?.message };
  }
}

export const SUPABASE_SQL_SETUP_SCRIPT = `
-- Run this in your Supabase SQL Editor if table is not yet created:
create table if not exists public.appointments (
  id uuid default gen_random_uuid() primary key,
  booking_ref text not null,
  service_id text,
  service_name text not null,
  style_id text,
  style_name text not null,
  date date not null,
  time_slot text not null,
  location_type text not null,
  address text,
  city_area text,
  guest_count integer default 1,
  client_name text not null,
  email text,
  phone text not null,
  saree_fabric text,
  saree_length text,
  height_footwear text,
  special_notes text,
  include_pre_pleating boolean default false,
  total_price numeric not null,
  advance_deposit numeric not null,
  status text default 'confirmed',
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable RLS and allow public bookings to be saved and managed
alter table public.appointments enable row level security;

create policy "Allow anonymous inserts" 
on public.appointments 
for insert 
with check (true);

create policy "Allow public read" 
on public.appointments 
for select 
using (true);

create policy "Allow public update" 
on public.appointments 
for update 
using (true);

create policy "Allow public delete" 
on public.appointments 
for delete 
using (true);
`;

