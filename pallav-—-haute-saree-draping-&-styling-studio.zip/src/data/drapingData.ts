import { DrapingStyle, ServicePackage, LookbookItem, Testimonial, FaqItem } from '../types';

export const HERO_IMAGE = '/src/assets/images/hero_bridal_saree_draping_1790795978319.jpg';
export const BHARATANATYAM_IMAGE = '/src/assets/images/bharatanatyam_dance_drape_1790796785854.jpg';
export const KERALA_IMAGE = '/src/assets/images/kerala_kasavu_drape_1790796800155.jpg';
export const NAUVARI_KACHA_IMAGE = '/src/assets/images/lookbook_nauvari_traditional_1790795995455.jpg';
export const CONTEMPORARY_BELTED_IMAGE = '/src/assets/images/lookbook_contemporary_belted_1790796008789.jpg';
export const MASTERCLASS_IMAGE = '/src/assets/images/masterclass_pleating_detail_1790796021043.jpg';

export const STUDIO_INFO = {
  name: 'Geetha Saree Draping',
  phone: '8050566063',
  phoneDisplay: '+91 80505 66063',
  whatsappNumber: '918050566063',
  addressLine1: 'Vittasandra Main Road',
  landmark: 'Near Keerthi Chicken Center',
  locality: 'Bangalore South',
  state: 'Karnataka',
  pincode: '560100',
  fullAddress: 'Vittasandra Main Road, Near Keerthi Chicken Center, Bangalore South, Karnataka 560100',
  mapCoordinates: {
    lat: 12.8622,
    lng: 77.6324,
  },
  mapEmbedUrl: 'https://maps.google.com/maps?q=Vittasandra+Main+Road,+Bangalore+South,+Karnataka&t=&z=15&ie=UTF8&iwloc=&output=embed',
  directionsUrl: 'https://www.google.com/maps/search/?api=1&query=Vittasandra+Main+Road+near+Keerthi+Chicken+Center+Bangalore+South+Karnataka',
  startingPrice: 1500,
};

export const DRAPING_STYLES: DrapingStyle[] = [
  {
    id: 'wedding-bridal',
    name: 'Wedding Bridal Saree Draping',
    subtitle: 'Grand Muhurtham & Reception Couture Drape',
    region: 'South Indian & Pan-Indian Bridal',
    description: 'Immaculate bridal draping engineered for heavy Kanjeevaram and Banarasi silks. Includes 9 razor-sharp knife pleats, veil/dupatta anchoring, box-pleat setting, and Pinless-Feel comfort for 12+ hours.',
    priceINR: 3000,
    occasion: ['Bridal', 'Reception & Sangeet'],
    fabrics: ['Kanjeevaram / Banarasi Silk', 'Raw Silk & Tussar'],
    complexity: 'Classic Heritage',
    durationMins: 45,
    pleatCount: '9 to 11 calibrated knife pleats',
    image: HERO_IMAGE,
    features: [
      'Heavy zari border alignment with zero sagging',
      'Dual-saree and bridal dupatta / veil pinning included',
      'Geetha Pinless-Feel magnetic & velvet cushion guards',
      'Comfortable seating for prolonged mandap rituals'
    ],
    stylingTips: 'Best draped with your bridal heels on; we set the hemline to a floating 1-inch clearance.'
  },
  {
    id: 'kerala-style',
    name: 'Kerala Style Saree Draping',
    subtitle: 'Traditional Kasavu & Set Mundu Elegance',
    region: 'Kerala & South India',
    description: 'Authentic Kerala Kasavu and Set Saree draping with pristine gold zari border symmetry, front fan pleats, and the graceful cross-torso pallu drape worn for weddings, temple ceremonies, and Onam.',
    priceINR: 2500,
    occasion: ['Bridal', 'Festive & Puja', 'Reception & Sangeet'],
    fabrics: ['Cotton & Linen', 'Kanjeevaram / Banarasi Silk'],
    complexity: 'Classic Heritage',
    durationMins: 25,
    pleatCount: '7 to 8 gold border-aligned pleats',
    image: KERALA_IMAGE,
    features: [
      'Pristine Kerala gold kara border symmetry',
      'Traditional Set Mundu or single-piece Kasavu drape',
      'Complements jasmine flower veni and temple gold jewelry',
      'Crisp, lightweight, and heat-friendly tucks'
    ],
    stylingTips: 'Ideal for cotton Kasavu or golden tissue silk sarees with contrasting blouse embroidery.'
  },
  {
    id: 'bharatanatyam-dance',
    name: 'Bharatanatyam Dance Saree Draping',
    subtitle: 'Stage-Performance Classical Dance Drape',
    region: 'Classical Indian Dance Heritage',
    description: 'Specialized stage draping for Bharatanatyam dancers with structured accordion fan pleats, secured dhoti/pyjama katcham leg wrap, and high-stability pin anchors that withstand intense footwork and jumps.',
    priceINR: 4000,
    occasion: ['Festive & Puja', 'Corporate & Formal'],
    fabrics: ['Kanjeevaram / Banarasi Silk', 'Raw Silk & Tussar'],
    complexity: 'Royal Traditional',
    durationMins: 50,
    pleatCount: 'Graduated multi-tiered dance fan pleats',
    image: BHARATANATYAM_IMAGE,
    features: [
      'Rigid stage-performance anchor with zero slip during arangetram',
      'Dynamic front fan opens seamlessly during aramandi sitting postures',
      'Calibrated leg room for high jumps, tatkar footwork & spinning',
      'Temple jewelry & ghungroo bell clearance'
    ],
    stylingTips: 'Requires traditional silk dance saree; arangetram and stage performers receive extra backup anchor pins.'
  },
  {
    id: 'kacha-saree-style',
    name: 'Kacha Saree Style Draping',
    subtitle: 'Authentic Dhoti, Madisar & Nauvari Drape',
    region: 'Maharashtra, Tamil Nadu & Karnataka',
    description: 'Traditional kacha (dhoti-style) drape where the saree is passed between the legs and tucked securely at the back (kashta/katcham). Exemplified by 9-yard Madisar and Maharashtrian Nauvari.',
    priceINR: 4000,
    occasion: ['Bridal', 'Festive & Puja'],
    fabrics: ['Kanjeevaram / Banarasi Silk', 'Cotton & Linen', 'Raw Silk & Tussar'],
    complexity: 'Royal Traditional',
    durationMins: 45,
    pleatCount: '11 front pleats with secured back kashta tuck',
    image: NAUVARI_KACHA_IMAGE,
    features: [
      'Authentic back kacha/kashta tuck preventing unraveling',
      'Full freedom for sitting on the floor at homam / puja altars',
      'Supports traditional 9-yard Madisar or Paithani weaves',
      'Waist belt (Oddiyanam / Kamarbandh) integration'
    ],
    stylingTips: 'Wear fitted stretch leggings or shorts instead of a petticoat for seamless kacha tucks.'
  },
  {
    id: 'indian-saree-classic',
    name: 'Indian Saree Draping (Festive & Reception)',
    subtitle: 'Timeless Nivi & Contemporary Elegance',
    region: 'Pan-Indian',
    description: 'The quintessential Indian saree drape with razor-sharp front pleats and a graceful cascading pallu. Ideal for sangeets, wedding guests, festive celebrations, and family functions.',
    priceINR: 2000,
    occasion: ['Reception & Sangeet', 'Festive & Puja', 'Corporate & Formal'],
    fabrics: ['Kanjeevaram / Banarasi Silk', 'Georgette & Chiffon', 'Organza & Tissue'],
    complexity: 'Classic Heritage',
    durationMins: 20,
    pleatCount: '7 to 9 crisp 1.5-inch pleats',
    image: HERO_IMAGE,
    features: [
      'Hourglass waistline contouring',
      'Ironed-sharp pleat falls with zero ballooning',
      'Pallu length customized to heel height',
      '18-minute swift precision styling'
    ],
    stylingTips: 'Versatile for all fabrics from heavy Kanjeevaram to lightweight designer georgettes.'
  },
  {
    id: 'basic-guest-draping',
    name: 'Classic Festive & Party Saree Draping',
    subtitle: 'Starting from ₹1,500',
    region: 'Everyday & Party Wear',
    description: 'Neat, swift, and comfortable saree draping for parties, festivals, bridesmaids, and wedding guests. Saree draping starts from ₹1,500 with zero pin tears.',
    priceINR: 1500,
    occasion: ['Festive & Puja', 'Corporate & Formal', 'Cocktail & Party'],
    fabrics: ['Cotton & Linen', 'Georgette & Chiffon', 'Raw Silk & Tussar'],
    complexity: 'Classic Heritage',
    durationMins: 15,
    pleatCount: '6 to 7 neat pleats',
    image: CONTEMPORARY_BELTED_IMAGE,
    features: [
      'Accessible starting rate of ₹1,500',
      'Neat and swift 15-minute turnaround',
      'Secure pin placement without damaging fabric',
      'Group discounts for 3+ guests'
    ],
    stylingTips: 'Bring your pre-ironed saree and shapewear for quick 15-minute styling.'
  }
];

export const SERVICE_PACKAGES: ServicePackage[] = [
  {
    id: 'wedding-bridal',
    name: 'Wedding Bridal Saree Draping',
    badge: 'Bridal Specialty',
    tagline: 'Complete bridal styling with 12-hour locked pleats, veil/dupatta setting & emergency touch-up kit.',
    priceINR: 3000,
    priceUSD: 40,
    durationMinutes: 45,
    bestFor: 'Muhurtham, Phere, Reception & Main Wedding Ceremony',
    popular: true,
    features: [
      'Dedicated Master Draper Geetha for your bridal slot',
      'Heavy Kanjeevaram / Zardozi alignment with zero sagging',
      'Dual-saree draping & bridal veil / dupatta pinning',
      'Geetha Pinless-Feel comfort guards (fabric-safe silicone pins)',
      '12-Hour Locked-Pleat Guarantee through long rituals & photography',
      'On-site visit to your mandapam / hotel across Bangalore South'
    ]
  },
  {
    id: 'bharatanatyam-dance',
    name: 'Bharatanatyam Dance Saree Draping',
    badge: 'Stage Mastery',
    tagline: 'Specialized classical dance drape with rigid stage stability, front fan pleats & katcham wrap.',
    priceINR: 4000,
    priceUSD: 50,
    durationMinutes: 50,
    bestFor: 'Arangetram, Dance Festivals, Stage Performances & Photoshoots',
    popular: true,
    features: [
      'Stage-grade anchor withstanding energetic footwork and spins',
      'Flawless accordion fan pleat opening during aramandi postures',
      'Calibrated leg bifurcations for dynamic floor movement',
      'Temple jewelry, belt & ankle ghungroo bell clearance',
      'Backup reinforcement pins for costume shifts'
    ]
  },
  {
    id: 'kacha-saree-style',
    name: 'Kacha Saree Style Draping (Madisar / Dhoti)',
    badge: 'Traditional Heritage',
    tagline: 'Authentic 9-yard Madisar, Maharashtrian Nauvari, and dhoti-style kacha draping.',
    priceINR: 4000,
    priceUSD: 50,
    durationMinutes: 45,
    bestFor: 'Tamil Madisar weddings, Maharashtrian Nauvari, Temple Yagnas & Pujas',
    features: [
      'Mastery of both 9-yard Iyer/Iyengar Madisar and Konkan Nauvari',
      'Authentic back kacha/kashta wrap ensuring zero unraveling',
      'Optimal ease for sitting cross-legged at prayer altars',
      'Even weight distribution preventing waist strain'
    ]
  },
  {
    id: 'kerala-style',
    name: 'Kerala Style Saree Draping',
    badge: 'Pristine Tradition',
    tagline: 'Authentic Kasavu & Set Mundu styling with symmetric gold zari border alignment.',
    priceINR: 2500,
    priceUSD: 32,
    durationMinutes: 25,
    bestFor: 'Kerala Weddings, Onam, Vishu, Temple Festivals & Bridesmaids',
    features: [
      'Symmetric gold border front pleat alignment',
      'Traditional Set Mundu or single-piece Kasavu saree drape',
      'Integrated styling for jasmine veni and temple gold jewelry',
      'Lightweight and breathable tucks for humid weather'
    ]
  },
  {
    id: 'indian-saree-classic',
    name: 'Indian Saree Draping (Festive & Reception)',
    badge: 'Timeless Elegance',
    tagline: 'Razor-crisp 18-minute styling for receptions, sangeets, cocktail parties & festivals.',
    priceINR: 2000,
    priceUSD: 26,
    durationMinutes: 20,
    bestFor: 'Sangeet, Reception, Festive Pujas & Cocktail Parties',
    features: [
      'Precision 1.5-inch uniform knife pleats',
      'Customized pallu sweep calibrated to your heels',
      'Choice of Nivi, Butterfly, or Contemporary Belted style',
      'Rapid 18-minute completion time'
    ]
  },
  {
    id: 'basic-guest-draping',
    name: 'Classic Festive & Party Saree Draping',
    badge: 'Starts from ₹1,500',
    tagline: 'Neat, fast, and elegant saree draping for guests, bridesmaids, and festive events.',
    priceINR: 1500,
    priceUSD: 20,
    durationMinutes: 15,
    bestFor: 'Wedding guests, cousins, sisters of bride & festive celebrations',
    features: [
      'Affordable entry pricing starting from ₹1,500 per person',
      '15-minute swift draping with neat pleat alignment',
      'Zero fabric tearing with fine nickel-free pins',
      'Group discounts for 3+ guests'
    ]
  }
];

export const LOOKBOOK_ITEMS: LookbookItem[] = [
  {
    id: 'look-1',
    title: 'Wedding Bridal Kanjeevaram Drape',
    styleId: 'wedding-bridal',
    occasion: 'Bridal',
    fabric: 'Kanjeevaram / Banarasi Silk',
    complexity: 'Classic Heritage',
    image: HERO_IMAGE,
    description: 'Crimson pure zari Kanjeevaram drape with 9 razor-crisp knife pleats aligned exactly 1.5 inches apart, priced at ₹3,000.',
    palluStyle: 'Shoulder-anchored pleated cascade with gold border highlight',
    pleatDetails: '9 equal knife pleats with invisible inner anchor'
  },
  {
    id: 'look-2',
    title: 'Bharatanatyam Classical Dance Costume Drape',
    styleId: 'bharatanatyam-dance',
    occasion: 'Festive & Puja',
    fabric: 'Kanjeevaram / Banarasi Silk',
    complexity: 'Royal Traditional',
    image: BHARATANATYAM_IMAGE,
    description: 'Stage-calibrated Bharatanatyam dance drape with structured accordion fan pleats and pyjama katcham leg wrap, priced at ₹4,000.',
    palluStyle: 'Cross-chest torso wrap pinned for stage movements',
    pleatDetails: 'Dynamic front fan with arangetram-grade anchor'
  },
  {
    id: 'look-3',
    title: 'Traditional Kerala Kasavu Silk Drape',
    styleId: 'kerala-style',
    occasion: 'Bridal',
    fabric: 'Cotton & Linen',
    complexity: 'Classic Heritage',
    image: KERALA_IMAGE,
    description: 'Authentic ivory and gold Kerala Kasavu saree drape with symmetric border pleats and temple floral aesthetic, priced at ₹2,500.',
    palluStyle: 'Classic shoulder pallu sweep with gold zari Kara',
    pleatDetails: '7 neat front pleats tucked at the waist'
  },
  {
    id: 'look-4',
    title: 'Traditional Kacha Saree Drape (Nauvari / Madisar)',
    styleId: 'kacha-saree-style',
    occasion: 'Bridal',
    fabric: 'Kanjeevaram / Banarasi Silk',
    complexity: 'Royal Traditional',
    image: NAUVARI_KACHA_IMAGE,
    description: 'Bifurcated kacha saree drape with front fan pleats and secure back kashta tuck for ritual seating, priced at ₹4,000.',
    palluStyle: 'Cross-body drape anchored with Kamarbandh / Oddiyanam',
    pleatDetails: '11 front pleats bifurcated between legs into center back tuck'
  },
  {
    id: 'look-5',
    title: 'Indian Saree Draping (Festive & Reception)',
    styleId: 'indian-saree-classic',
    occasion: 'Reception & Sangeet',
    fabric: 'Georgette & Chiffon',
    complexity: 'Classic Heritage',
    image: CONTEMPORARY_BELTED_IMAGE,
    description: 'Contemporary festive Indian saree drape with sculpted waistline and fluid drape fall, priced at ₹2,000.',
    palluStyle: 'Modern floating pallu with metallic waist-belt cinch',
    pleatDetails: '6 razor pleats with flat abdominal tuck'
  },
  {
    id: 'look-6',
    title: 'Classic Festive Draping (Starts from ₹1,500)',
    styleId: 'basic-guest-draping',
    occasion: 'Cocktail & Party',
    fabric: 'Cotton & Linen',
    complexity: 'Classic Heritage',
    image: MASTERCLASS_IMAGE,
    description: 'Fast, neat, and budget-friendly saree draping for guests and bridesmaids starting from ₹1,500.',
    palluStyle: 'Clean pinned shoulder pallu',
    pleatDetails: '6 neat knife pleats with secure safety pins'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    clientName: 'Sowmya Krishnan',
    role: 'Bride (Electronic City Wedding)',
    occasion: 'Muhurtham & Reception',
    sareeType: 'Heavy Pure Kanjeevaram (₹3,000 Wedding Drape)',
    quote: 'Geetha arrived at our venue in Bangalore South right on time. She draped my heavy bridal Kanjeevaram in just 20 minutes! The pleats stayed razor-sharp through the entire 4-hour homam and 800 guest greetings. Zero pin pricks and total comfort.',
    rating: 5,
    location: 'Bangalore South, Karnataka',
    verified: true
  },
  {
    id: 'test-2',
    clientName: 'Divya Nair',
    role: 'Bharatanatyam Arangetram Dancer',
    occasion: 'Classical Dance Debut',
    sareeType: 'Dance Costume Saree (₹4,000 Bharatanatyam Drape)',
    quote: 'For my arangetram, I was terrified the dance fan might slip during the varnam. Geetha’s Bharatanatyam drape didn’t budge an inch through 3 hours of rigorous footwork and jumps. She is based right on Vittasandra Main Road, so convenient!',
    rating: 5,
    location: 'Vittasandra / Bangalore South',
    verified: true
  },
  {
    id: 'test-3',
    clientName: 'Anitha & Lakshmi',
    role: 'Kerala Wedding Bride & Sister',
    occasion: 'Temple Wedding',
    sareeType: 'Kerala Kasavu Silk (₹2,500 Kerala Drape)',
    quote: 'Geetha gave us the most authentic Kerala Kasavu drape with symmetric gold borders. It looked so regal and graceful in our temple photos. WhatsApp booking was instantaneous.',
    rating: 5,
    location: 'Bangalore South',
    verified: true
  },
  {
    id: 'test-4',
    clientName: 'Rukmini Raghavan',
    role: 'Bride’s Mother',
    occasion: 'Traditional Kacha / Madisar Drape',
    sareeType: '9-Yard Silk Saree (₹4,000 Kacha Drape)',
    quote: 'Finding someone in Bangalore South who can drape an authentic kacha style 9-yard saree without making it feel suffocating is rare. Geetha draped it with ease and I could walk and bend effortlessly all day.',
    rating: 5,
    location: 'Vittasandra Main Road Studio',
    verified: true
  }
];

export const FAQS: FaqItem[] = [
  {
    id: 'faq-1',
    category: 'Services & Timing',
    question: 'What are the charges for different saree draping styles at Geetha Saree Draping?',
    answer: 'Our saree draping services start from ₹1,500. Our specialty rates are: Indian Saree Draping at ₹2,000, Kerala Style Saree at ₹2,500, Wedding Bridal Saree Draping at ₹3,000, Bharatanatyam Classical Dance Draping at ₹4,000, and traditional Kacha Saree Style (Dhoti / 9-yard Madisar) at ₹4,000.'
  },
  {
    id: 'faq-2',
    category: 'Travel & Booking',
    question: 'Where is Geetha Saree Draping located in Bangalore South?',
    answer: 'We are located on Vittasandra Main Road, near Keerthi Chicken Center, Bangalore South, Karnataka 560100. We welcome clients to our studio suite and also provide on-site travel across Bangalore South, Electronic City, Begur, and surrounding areas. Call or WhatsApp 8050566063 for directions!'
  },
  {
    id: 'faq-3',
    category: 'Preparation & Safety',
    question: 'How do you secure Bharatanatyam dance sarees for intense stage movements?',
    answer: 'For Bharatanatyam draping (₹4,000), we use stage-tested multi-anchor pin locks, reinforced waist ties, and structured accordion fan folds that expand cleanly during aramandi postures while keeping legs completely unrestricted for jumps and tatkar footwork.'
  },
  {
    id: 'faq-4',
    category: 'Travel & Booking',
    question: 'How can I book an appointment and contact Geetha?',
    answer: 'You can directly call Geetha at 8050566063, message via WhatsApp at 8050566063, or use our interactive online booking system on this website with instant appointment confirmation.'
  },
  {
    id: 'faq-5',
    category: 'Fabrics & Sizing',
    question: 'What is required for the Kacha Saree Style (₹4,000)?',
    answer: 'For Kacha style (including 9-yard Madisar, Nauvari, or dhoti wrap), we recommend wearing snug stretch cycling shorts or leggings instead of a conventional round petticoat. This allows the fabric to pass between the legs cleanly and tuck securely at the back.'
  },
  {
    id: 'faq-6',
    category: 'Preparation & Safety',
    question: 'Will heavy safety pins damage delicate zari or silk sarees?',
    answer: 'Never. We use ultra-fine Japanese safety pins equipped with silicone beads and velvet magnetic cushions that distribute fabric weight evenly without piercing holes or snagging precious gold zari threads.'
  }
];

export const BEFORE_AFTER_DATA = {
  before: {
    title: 'Standard DIY Draping',
    subtitle: 'Common pain points experienced before professional styling',
    points: [
      'Uneven, bulging pleats that fan outward at the abdomen',
      'Dragging hemline prone to being stepped on or tripped over',
      'Bharatanatyam fan pleats collapsing or shifting during dance postures',
      'Slipping shoulder pallu requiring constant hitching throughout rituals',
      'Kacha / Dhoti folds feeling loose or uncomfortable around the waist'
    ]
  },
  after: {
    title: 'Geetha Master Drape',
    subtitle: 'Engineered with our 12-Hour Pinless-Comfort Guarantee (Starts from ₹1,500)',
    points: [
      'Razor-sharp 1.5" knife pleats aligned uniformly with 0mm deviation',
      'Engineered 1-inch floor clearance calibrated to your specific footwear',
      'Arangetram-grade stage anchor for Bharatanatyam that never shifts',
      'Silicone pin-guards ensuring 100% fabric protection on heirloom silks',
      'Authentic Kacha & Kerala Kara border symmetry with total walking freedom'
    ]
  }
};
