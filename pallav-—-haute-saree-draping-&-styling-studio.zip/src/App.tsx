/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { BeforeAfterSection } from './components/BeforeAfterSection';
import { StylesShowcase } from './components/StylesShowcase';
import { LookbookGallery } from './components/LookbookGallery';
import { ServicesPricing } from './components/ServicesPricing';
import { BookingSystem } from './components/BookingSystem';
import { MasterclassSection } from './components/MasterclassSection';
import { StorySection } from './components/StorySection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { MapLocationSection } from './components/MapLocationSection';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { WhatsAppWidget } from './components/WhatsAppWidget';
import { StyleRecommenderModal } from './components/StyleRecommenderModal';
import { AdminBookingsModal } from './components/AdminBookingsModal';
import { AdminPanel } from './components/AdminPanel';

export default function App() {
  const [viewMode, setViewMode] = useState<'website' | 'admin'>('website');
  const [selectedServiceForBooking, setSelectedServiceForBooking] = useState<string | undefined>(undefined);
  const [selectedStyleForBooking, setSelectedStyleForBooking] = useState<string | undefined>(undefined);
  const [isQuizOpen, setIsQuizOpen] = useState<boolean>(false);
  const [isAdminBookingsOpen, setIsAdminBookingsOpen] = useState<boolean>(false);

  const openAdmin = () => {
    setViewMode('admin');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const backToWebsite = () => {
    setViewMode('website');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToBooking = (serviceId?: string, styleId?: string) => {
    if (viewMode === 'admin') {
      setViewMode('website');
    }
    if (serviceId) setSelectedServiceForBooking(serviceId);
    if (styleId) setSelectedStyleForBooking(styleId);
    
    setTimeout(() => {
      const element = document.getElementById('booking');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 50);
  };

  const scrollToStyles = () => {
    if (viewMode === 'admin') {
      setViewMode('website');
    }
    setTimeout(() => {
      const element = document.getElementById('styles');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 50);
  };

  if (viewMode === 'admin') {
    return (
      <AdminPanel 
        onBackToWebsite={backToWebsite} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#F0F5FA] text-[#132235] font-sans antialiased selection:bg-[#D4AF37]/30 selection:text-[#0B1A30]">
      {/* Navigation */}
      <Navbar
        onOpenBooking={(serviceId) => scrollToBooking(serviceId)}
        onOpenQuiz={() => setIsQuizOpen(true)}
        onOpenAdminBookings={openAdmin}
      />

      {/* Main Content */}
      <main>
        {/* Hero Section */}
        <Hero
          onOpenBooking={() => scrollToBooking('wedding-bridal')}
          onExploreStyles={scrollToStyles}
          onOpenQuiz={() => setIsQuizOpen(true)}
        />

        {/* Before & After Transformation */}
        <BeforeAfterSection />

        {/* Signature Styles Showcase */}
        <StylesShowcase
          onSelectStyleForBooking={(styleId) => scrollToBooking(undefined, styleId)}
        />

        {/* Curated Lookbook Gallery */}
        <LookbookGallery
          onSelectLookForBooking={(styleId) => scrollToBooking(undefined, styleId)}
        />

        {/* Services & Transparent Pricing */}
        <ServicesPricing
          onSelectPackageForBooking={(pkgId) => scrollToBooking(pkgId)}
        />

        {/* Core Conversion: Interactive Booking Wizard with Supabase connection */}
        <BookingSystem
          initialServiceId={selectedServiceForBooking}
          initialStyleId={selectedStyleForBooking}
          onOpenAdminBookings={openAdmin}
        />

        {/* 1-on-1 Masterclass Spotlight */}
        <MasterclassSection
          onBookMasterclass={() => scrollToBooking('wedding-bridal')}
        />

        {/* Our Craft & Heritage Story */}
        <StorySection />

        {/* Client Reviews & Testimonials */}
        <TestimonialsSection />

        {/* Live Location Map & Studio Contact Section */}
        <MapLocationSection
          onOpenBooking={() => scrollToBooking()}
        />

        {/* FAQ & Direct Contact Form */}
        <FaqSection />
      </main>

      {/* Footer */}
      <Footer
        onOpenBooking={() => scrollToBooking()}
        onOpenQuiz={() => setIsQuizOpen(true)}
        onOpenAdminBookings={openAdmin}
      />

      {/* Floating Concierge Chat Widget with 8050566063 */}
      <WhatsAppWidget />

      {/* Interactive 30-Second Style Recommender Quiz Modal */}
      <StyleRecommenderModal
        isOpen={isQuizOpen}
        onClose={() => setIsQuizOpen(false)}
        onSelectRecommendedStyle={(styleId) => {
          scrollToBooking(undefined, styleId);
        }}
      />

      {/* Admin / Live Supabase Appointments Viewer Modal */}
      <AdminBookingsModal
        isOpen={isAdminBookingsOpen}
        onClose={() => setIsAdminBookingsOpen(false)}
        onOpenFullAdmin={() => {
          setIsAdminBookingsOpen(false);
          openAdmin();
        }}
      />
    </div>
  );
}
