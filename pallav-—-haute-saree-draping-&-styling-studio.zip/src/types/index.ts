export type OccasionType = 'Bridal' | 'Reception & Sangeet' | 'Festive & Puja' | 'Cocktail & Party' | 'Corporate & Formal';

export type FabricType = 'Kanjeevaram / Banarasi Silk' | 'Organza & Tissue' | 'Georgette & Chiffon' | 'Cotton & Linen' | 'Raw Silk & Tussar';

export type ComplexityType = 'Classic Heritage' | 'Modern / Fusion' | 'Royal Traditional';

export interface DrapingStyle {
  id: string;
  name: string;
  subtitle: string;
  region: string;
  description: string;
  priceINR: number;
  occasion: OccasionType[];
  fabrics: FabricType[];
  complexity: ComplexityType;
  durationMins: number;
  pleatCount: string;
  image: string;
  features: string[];
  stylingTips: string;
}

export interface ServicePackage {
  id: string;
  name: string;
  badge?: string;
  tagline: string;
  priceUSD: number;
  priceINR: number;
  durationMinutes: number;
  bestFor: string;
  features: string[];
  popular?: boolean;
}

export interface LookbookItem {
  id: string;
  title: string;
  styleId: string;
  occasion: OccasionType;
  fabric: FabricType;
  complexity: ComplexityType;
  image: string;
  description: string;
  palluStyle: string;
  pleatDetails: string;
}

export interface Testimonial {
  id: string;
  clientName: string;
  role: string;
  occasion: string;
  sareeType: string;
  quote: string;
  rating: number;
  location: string;
  verified: boolean;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category: 'Preparation & Safety' | 'Services & Timing' | 'Fabrics & Sizing' | 'Travel & Booking';
}

export interface BookingState {
  serviceId: string;
  styleId: string;
  date: string;
  timeSlot: string;
  locationType: 'studio' | 'onsite';
  address: string;
  zipCode: string;
  clientName: string;
  email: string;
  phone: string;
  sareeFabric: string;
  sareeLength: '5.5 meters' | '6 meters' | '9 meters Nauvari';
  specialNotes: string;
  addOns: string[];
  prePleatService: boolean;
}
