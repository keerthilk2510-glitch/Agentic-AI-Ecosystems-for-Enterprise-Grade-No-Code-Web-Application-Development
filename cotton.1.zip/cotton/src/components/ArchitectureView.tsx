import React from 'react';
import { Cpu, Layers, GitBranch, Zap, Shield, ArrowRight, CheckCircle2 } from 'lucide-react';
import { EVALUATION_METRICS } from '../data/evaluationData.ts';

interface ArchitectureViewProps {
  isDarkMode: boolean;
}

export const ArchitectureView: React.FC<ArchitectureViewProps> = ({ isDarkMode }) => {
  return (
    <div className="space-y-8">
      {/* Editorial Header */}
      <div className="border-b pb-5 border-slate-200 dark:border-slate-800">
        <div className="text-xs uppercase font-mono tracking-wider mb-1 text-emerald-600 dark:text-emerald-400">
          Convolutional Neural Network Design
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-50">
          MobileNetV2 Transfer Learning Architecture
        </h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 max-w-3xl">
          Detailed architectural breakdown of Inverted Residual Blocks, Depthwise Separable Convolutions, and two-phase transfer learning calibrated for edge agricultural diagnostics.
        </p>
      </div>

      {/* Model Spec KPI Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className={`p-4 rounded-xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <span className="text-[11px] font-mono uppercase text-slate-400 block">Total Parameters</span>
          <span className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1 block">
            {(EVALUATION_METRICS.modelParameters.total / 1e6).toFixed(2)}M
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">2,588,039 total weights</span>
        </div>

        <div className={`p-4 rounded-xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <span className="text-[11px] font-mono uppercase text-slate-400 block">Phase 1 Trainable</span>
          <span className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-1 block">
            {(EVALUATION_METRICS.modelParameters.trainablePhase1 / 1e3).toFixed(1)}k
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">Head only (Backbone frozen)</span>
        </div>

        <div className={`p-4 rounded-xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <span className="text-[11px] font-mono uppercase text-slate-400 block">Phase 2 Fine-Tuned</span>
          <span className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-1 block">
            {(EVALUATION_METRICS.modelParameters.trainablePhase2 / 1e6).toFixed(2)}M
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">Top 30 backbone layers</span>
        </div>

        <div className={`p-4 rounded-xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <span className="text-[11px] font-mono uppercase text-slate-400 block">Quantized TFLite</span>
          <span className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1 block">
            2.64 MB
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">INT8 Post-training quant.</span>
        </div>
      </div>

      {/* Two-Phase Transfer Learning Pipeline Flow */}
      <div className={`p-5 rounded-2xl border ${
        isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-1">
          Two-Phase Transfer Learning Pipeline Flow
        </h3>
        <p className="text-xs text-slate-500 mb-6">
          Rigorous progression from generic ImageNet feature representations to high-precision foliar pathology recognition.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 relative">
          {/* Step 1 */}
          <div className={`p-4 rounded-xl border space-y-2.5 ${
            isDarkMode ? 'bg-slate-950/40 border-slate-800' : 'bg-slate-50 border-slate-200'
          }`}>
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400">STAGE 01</span>
              <span className="text-[10px] font-mono text-slate-400">154 Layers</span>
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Pretrained Backbone Loading
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Initialize MobileNetV2 pretrained on ImageNet (1.4M images, 1,000 classes). Retains low-level Gabor-like filters (edges, color gradients, texture patches).
            </p>
            <div className="pt-2 text-[11px] font-mono text-slate-400">
              Weights: <span className="text-slate-700 dark:text-slate-300">imagenet</span>
            </div>
          </div>

          {/* Step 2 */}
          <div className={`p-4 rounded-xl border space-y-2.5 ${
            isDarkMode ? 'bg-slate-950/40 border-slate-800' : 'bg-slate-50 border-slate-200'
          }`}>
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400">STAGE 02</span>
              <span className="text-[10px] font-mono text-slate-400">Epochs 1–15</span>
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Feature Extraction (Frozen)
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Backbone weights are frozen (<code className="text-xs">trainable = False</code>). Only the new custom classification head is trained using Adam (<code className="text-xs">LR = 1e-4</code>).
            </p>
            <div className="pt-2 text-[11px] font-mono text-slate-400">
              Val Accuracy reached: <span className="text-emerald-600 font-bold">97.1%</span>
            </div>
          </div>

          {/* Step 3 */}
          <div className={`p-4 rounded-xl border space-y-2.5 ${
            isDarkMode ? 'bg-emerald-950/20 border-emerald-900/50' : 'bg-emerald-50/50 border-emerald-200'
          }`}>
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400">STAGE 03</span>
              <span className="text-[10px] font-mono text-slate-400">Epochs 16–30</span>
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Fine-Tuning Top 30 Layers
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Unfreeze layers 124–154 of the backbone. Re-compile with micro learning rate (<code className="text-xs">LR = 1e-5</code>) to adapt high-level features to cotton pathology.
            </p>
            <div className="pt-2 text-[11px] font-mono text-slate-400">
              Final Accuracy: <span className="text-emerald-600 font-bold">98.42%</span>
            </div>
          </div>
        </div>
      </div>

      {/* MobileNetV2 Core Innovation: Inverted Residuals & Bottlenecks */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className={`lg:col-span-7 p-5 rounded-2xl border space-y-4 ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Inverted Residual Block Mechanics
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              The sandglass structure: low-dimensional input → high-dimensional expansion → depthwise conv → low-dimensional projection.
            </p>
          </div>

          <div className="space-y-3">
            <div className={`p-3.5 rounded-xl border text-xs space-y-1 ${
              isDarkMode ? 'bg-slate-950/40 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}>
              <div className="font-semibold text-slate-900 dark:text-slate-100 flex items-center justify-between">
                <span>1. Pointwise 1×1 Expansion Conv (ReLU6)</span>
                <span className="font-mono text-slate-400 text-[11px]">Expansion factor t = 6</span>
              </div>
              <p className="text-slate-500 leading-relaxed">
                Expands the number of channels by a factor of 6 to allow expressive non-linear transformations without loss of spatial resolution.
              </p>
            </div>

            <div className={`p-3.5 rounded-xl border text-xs space-y-1 ${
              isDarkMode ? 'bg-slate-950/40 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}>
              <div className="font-semibold text-slate-900 dark:text-slate-100 flex items-center justify-between">
                <span>2. Depthwise 3×3 Convolution (ReLU6)</span>
                <span className="font-mono text-slate-400 text-[11px]">Spatial filtering</span>
              </div>
              <p className="text-slate-500 leading-relaxed">
                Performs lightweight spatial filtering independently on each channel, dramatically slashing computation compared to standard 3×3 convolutions.
              </p>
            </div>

            <div className={`p-3.5 rounded-xl border text-xs space-y-1 ${
              isDarkMode ? 'bg-slate-950/40 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}>
              <div className="font-semibold text-slate-900 dark:text-slate-100 flex items-center justify-between">
                <span>3. Linear 1×1 Bottleneck Projection (No Activation)</span>
                <span className="font-mono text-slate-400 text-[11px]">Linear Bottleneck</span>
              </div>
              <p className="text-slate-500 leading-relaxed">
                Projects high-dimensional features back into low-dimensional space without ReLU, preventing non-linearities from destroying manifold representations.
              </p>
            </div>

            <div className={`p-3.5 rounded-xl border text-xs space-y-1 ${
              isDarkMode ? 'bg-emerald-950/20 border-emerald-900/40' : 'bg-emerald-50 border-emerald-200'
            }`}>
              <div className="font-semibold text-emerald-800 dark:text-emerald-300 flex items-center justify-between">
                <span>4. Inverted Residual Shortcut Connection</span>
                <span className="font-mono text-emerald-600 dark:text-emerald-400 text-[11px]">Identity Add</span>
              </div>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                Connects bottlenecks directly where input and output channels match, facilitating seamless gradient flow across all 154 layers.
              </p>
            </div>
          </div>
        </div>

        {/* Hyperparameter Formulation & Math */}
        <div className={`lg:col-span-5 p-5 rounded-2xl border space-y-4 ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Training Formulation & Hyperparameters
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Exact mathematical formulation used in TensorFlow/Keras pipeline.
            </p>
          </div>

          <div className="space-y-3 text-xs">
            <div className={`p-3 rounded-lg border font-mono ${
              isDarkMode ? 'bg-slate-950 border-slate-800 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-800'
            }`}>
              <div className="text-[10px] text-slate-400 uppercase mb-1">Loss Formulation</div>
              <div>Categorical Cross-Entropy:</div>
              <div className="text-emerald-600 dark:text-emerald-400 mt-1">
                L(y, ŷ) = - Σ [ y_c · log(ŷ_c) ]
              </div>
              <div className="text-[10px] text-slate-400 mt-1">for c ∈ &#123; 1, 2, ..., 7 &#125;</div>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800 font-mono text-[11px]">
              <div className="py-2 flex justify-between">
                <span className="text-slate-400">Input Resolution:</span>
                <span className="text-slate-800 dark:text-slate-200">224 × 224 × 3</span>
              </div>
              <div className="py-2 flex justify-between">
                <span className="text-slate-400">Batch Size:</span>
                <span className="text-slate-800 dark:text-slate-200">32</span>
              </div>
              <div className="py-2 flex justify-between">
                <span className="text-slate-400">Optimizer:</span>
                <span className="text-slate-800 dark:text-slate-200">Adam (β1=0.9, β2=0.999)</span>
              </div>
              <div className="py-2 flex justify-between">
                <span className="text-slate-400">Phase 1 Learning Rate:</span>
                <span className="text-slate-800 dark:text-slate-200">1.0 × 10⁻⁴</span>
              </div>
              <div className="py-2 flex justify-between">
                <span className="text-slate-400">Phase 2 Learning Rate:</span>
                <span className="text-slate-800 dark:text-slate-200">1.0 × 10⁻⁵</span>
              </div>
              <div className="py-2 flex justify-between">
                <span className="text-slate-400">Dropout Regularization:</span>
                <span className="text-slate-800 dark:text-slate-200">p = 0.35 + 0.20</span>
              </div>
              <div className="py-2 flex justify-between">
                <span className="text-slate-400">Data Augmentation:</span>
                <span className="text-slate-800 dark:text-slate-200">Flip, Rot(0.15), Zoom(0.15)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
