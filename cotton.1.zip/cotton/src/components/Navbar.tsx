import React from 'react';
import { Sun, Moon, Leaf, Printer, Sparkles } from 'lucide-react';

export type ActiveTab =
  | 'diagnosis'
  | 'gradio'
  | 'evaluation'
  | 'dataset'
  | 'architecture'
  | 'academic'
  | 'code'
  | 'prompt';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean) => void;
  onOpenReport?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  isDarkMode,
  setIsDarkMode,
  onOpenReport,
}) => {
  return (
    <header
      className={`sticky top-0 z-40 w-full border-b transition-colors ${
        isDarkMode
          ? 'bg-slate-950/90 border-emerald-950/40 text-slate-100 backdrop-blur-md'
          : 'bg-white/95 border-emerald-900/10 text-slate-800 backdrop-blur-md'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <div
          onClick={() => setActiveTab('diagnosis')}
          className="flex items-center gap-2.5 shrink-0 cursor-pointer"
        >
          <div className={`p-1.5 rounded-lg ${isDarkMode ? 'bg-emerald-950 text-emerald-400' : 'bg-emerald-50 text-emerald-700'}`}>
            <Leaf className="w-5 h-5" />
          </div>
          <span className="text-lg font-bold tracking-tight whitespace-nowrap">
            CottonVision <span className={isDarkMode ? 'text-emerald-400' : 'text-emerald-600'}>AI</span>
          </span>
        </div>

        {/* Zone 2: Navigation Links (concise, single-line) */}
        <nav className="hidden xl:flex items-center gap-4 text-xs font-medium">
          <button
            onClick={() => setActiveTab('diagnosis')}
            className={`whitespace-nowrap transition-colors pb-0.5 ${
              activeTab === 'diagnosis'
                ? isDarkMode
                  ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                  : 'text-emerald-700 border-b-2 border-emerald-600 font-semibold'
                : isDarkMode
                ? 'text-slate-400 hover:text-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Diagnosis & Grad-CAM
          </button>

          <button
            onClick={() => setActiveTab('gradio')}
            className={`whitespace-nowrap transition-colors pb-0.5 ${
              activeTab === 'gradio'
                ? isDarkMode
                  ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                  : 'text-emerald-700 border-b-2 border-emerald-600 font-semibold'
                : isDarkMode
                ? 'text-slate-400 hover:text-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Gradio Dashboard
          </button>

          <button
            onClick={() => setActiveTab('evaluation')}
            className={`whitespace-nowrap transition-colors pb-0.5 ${
              activeTab === 'evaluation'
                ? isDarkMode
                  ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                  : 'text-emerald-700 border-b-2 border-emerald-600 font-semibold'
                : isDarkMode
                ? 'text-slate-400 hover:text-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Model Evaluation
          </button>

          <button
            onClick={() => setActiveTab('dataset')}
            className={`whitespace-nowrap transition-colors pb-0.5 ${
              activeTab === 'dataset'
                ? isDarkMode
                  ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                  : 'text-emerald-700 border-b-2 border-emerald-600 font-semibold'
                : isDarkMode
                ? 'text-slate-400 hover:text-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            SAR-CLD-2024
          </button>

          <button
            onClick={() => setActiveTab('architecture')}
            className={`whitespace-nowrap transition-colors pb-0.5 ${
              activeTab === 'architecture'
                ? isDarkMode
                  ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                  : 'text-emerald-700 border-b-2 border-emerald-600 font-semibold'
                : isDarkMode
                ? 'text-slate-400 hover:text-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            MobileNetV2 Spec
          </button>

          <button
            onClick={() => setActiveTab('academic')}
            className={`whitespace-nowrap transition-colors pb-0.5 ${
              activeTab === 'academic'
                ? isDarkMode
                  ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                  : 'text-emerald-700 border-b-2 border-emerald-600 font-semibold'
                : isDarkMode
                ? 'text-slate-400 hover:text-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Academic Docs & Viva
          </button>

          <button
            onClick={() => setActiveTab('code')}
            className={`whitespace-nowrap transition-colors pb-0.5 ${
              activeTab === 'code'
                ? isDarkMode
                  ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                  : 'text-emerald-700 border-b-2 border-emerald-600 font-semibold'
                : isDarkMode
                ? 'text-slate-400 hover:text-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Modular Code Hub
          </button>

          <button
            onClick={() => setActiveTab('prompt')}
            className={`whitespace-nowrap transition-colors pb-0.5 flex items-center gap-1 ${
              activeTab === 'prompt'
                ? isDarkMode
                  ? 'text-emerald-400 border-b-2 border-emerald-400 font-semibold'
                  : 'text-emerald-700 border-b-2 border-emerald-600 font-semibold'
                : isDarkMode
                ? 'text-emerald-400/80 hover:text-emerald-300'
                : 'text-emerald-700 hover:text-emerald-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Master AI Prompt</span>
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action + Theme Toggle */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            aria-label="Toggle color theme"
            className={`p-2 rounded-lg border transition-colors ${
              isDarkMode
                ? 'border-slate-800 text-slate-300 hover:bg-slate-900 hover:text-white'
                : 'border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {onOpenReport && (
            <button
              onClick={onOpenReport}
              className={`hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                isDarkMode
                  ? 'bg-emerald-600 text-white hover:bg-emerald-500'
                  : 'bg-emerald-700 text-white hover:bg-emerald-800'
              }`}
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Advisory Slip</span>
            </button>
          )}
        </div>
      </div>

      {/* Horizontal Scroll Subnav for smaller displays */}
      <div className={`xl:hidden flex overflow-x-auto py-2.5 px-4 gap-4 border-t text-xs ${
        isDarkMode ? 'border-slate-800 bg-slate-950' : 'border-slate-200 bg-slate-50'
      }`}>
        <button
          onClick={() => setActiveTab('diagnosis')}
          className={`whitespace-nowrap ${activeTab === 'diagnosis' ? 'font-bold text-emerald-500' : 'text-slate-400'}`}
        >
          Diagnosis & Grad-CAM
        </button>
        <button
          onClick={() => setActiveTab('gradio')}
          className={`whitespace-nowrap ${activeTab === 'gradio' ? 'font-bold text-emerald-500' : 'text-slate-400'}`}
        >
          Gradio Dashboard
        </button>
        <button
          onClick={() => setActiveTab('evaluation')}
          className={`whitespace-nowrap ${activeTab === 'evaluation' ? 'font-bold text-emerald-500' : 'text-slate-400'}`}
        >
          Evaluation
        </button>
        <button
          onClick={() => setActiveTab('dataset')}
          className={`whitespace-nowrap ${activeTab === 'dataset' ? 'font-bold text-emerald-500' : 'text-slate-400'}`}
        >
          Dataset
        </button>
        <button
          onClick={() => setActiveTab('architecture')}
          className={`whitespace-nowrap ${activeTab === 'architecture' ? 'font-bold text-emerald-500' : 'text-slate-400'}`}
        >
          MobileNetV2
        </button>
        <button
          onClick={() => setActiveTab('academic')}
          className={`whitespace-nowrap ${activeTab === 'academic' ? 'font-bold text-emerald-500' : 'text-slate-400'}`}
        >
          Academic Docs & Viva
        </button>
        <button
          onClick={() => setActiveTab('code')}
          className={`whitespace-nowrap ${activeTab === 'code' ? 'font-bold text-emerald-500' : 'text-slate-400'}`}
        >
          Modular Code
        </button>
        <button
          onClick={() => setActiveTab('prompt')}
          className={`whitespace-nowrap font-bold text-emerald-500 flex items-center gap-1`}
        >
          <Sparkles className="w-3 h-3" />
          <span>Master AI Prompt</span>
        </button>
      </div>
    </header>
  );
};
