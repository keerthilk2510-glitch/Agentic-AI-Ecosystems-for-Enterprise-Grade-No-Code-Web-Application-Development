import React, { useState } from 'react';
import {
  Code,
  Copy,
  Check,
  Download,
  Terminal,
  FolderTree,
  FileCode,
  Sparkles,
  BookOpen,
  FileText
} from 'lucide-react';
import { MODULAR_PROJECT_FILES, ModularProjectFile } from '../data/pythonCodeArtifacts.ts';
import { COTTON_KNOWLEDGE_BASE } from '../data/cottonKnowledgeBase.ts';

interface CodeArtifactsViewProps {
  isDarkMode: boolean;
}

export const CodeArtifactsView: React.FC<CodeArtifactsViewProps> = ({ isDarkMode }) => {
  const [selectedFileKey, setSelectedFileKey] = useState<string>('app.py');
  const [copied, setCopied] = useState<boolean>(false);

  const currentFile: ModularProjectFile = MODULAR_PROJECT_FILES[selectedFileKey] || {
    path: 'app.py',
    name: 'app.py',
    category: 'core',
    mime: 'text/x-python',
    content: '# File not found',
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(currentFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([currentFile.content], { type: currentFile.mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = currentFile.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      {/* Editorial Header */}
      <div className="border-b pb-5 border-slate-200 dark:border-slate-800 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="text-xs uppercase font-mono tracking-wider mb-1 text-emerald-600 dark:text-emerald-400">
            Deliverable 2 & Deliverable 10 · Modular Project Repository
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-50">
            Source Code Hub & Python Pipeline
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 max-w-3xl">
            Complete, clean, executable source files structured according to the recommended modular academic repository layout.
          </p>
        </div>

        {/* Copy & Download Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg border transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              copied
                ? 'bg-emerald-600 text-white border-emerald-600'
                : isDarkMode
                ? 'border-slate-800 text-slate-300 hover:bg-slate-800'
                : 'border-slate-300 text-slate-700 hover:bg-slate-100'
            }`}
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied Content' : 'Copy File'}</span>
          </button>

          <button
            onClick={handleDownload}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              isDarkMode
                ? 'bg-emerald-600 text-white hover:bg-emerald-500'
                : 'bg-emerald-700 text-white hover:bg-emerald-800'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>Download {currentFile.name}</span>
          </button>
        </div>
      </div>

      {/* Main Split: File Tree Explorer (Left 4 cols) & Code Inspector (Right 8 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* File Tree Explorer (4 cols) */}
        <div className={`lg:col-span-4 p-4 rounded-2xl border space-y-3 ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200 border-b pb-3 border-slate-100 dark:border-slate-800">
            <FolderTree className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>Modular Project Architecture</span>
          </div>

          <div className="space-y-1 font-mono text-xs">
            {Object.keys(MODULAR_PROJECT_FILES).map((key) => {
              const file = MODULAR_PROJECT_FILES[key];
              const isSelected = selectedFileKey === key;

              return (
                <button
                  key={key}
                  onClick={() => setSelectedFileKey(key)}
                  className={`w-full text-left px-2.5 py-2 rounded-lg transition-colors flex items-center justify-between gap-2 ${
                    isSelected
                      ? isDarkMode
                        ? 'bg-emerald-950/50 text-emerald-300 border border-emerald-800/60 font-semibold'
                        : 'bg-emerald-50 text-emerald-900 border border-emerald-300 font-semibold'
                      : isDarkMode
                      ? 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <FileCode className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    <span className="truncate">{file.path}</span>
                  </div>
                  <span className="text-[10px] uppercase opacity-70 text-slate-400 shrink-0">
                    {file.category}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Quick Terminal Guide */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 space-y-1">
            <strong>Run Local Project:</strong>
            <pre className={`p-2 rounded font-mono ${
              isDarkMode ? 'bg-slate-950 text-emerald-400' : 'bg-slate-100 text-slate-800'
            }`}>
python app.py
            </pre>
          </div>
        </div>

        {/* Code Content Viewer (8 cols) */}
        <div className={`lg:col-span-8 rounded-2xl border overflow-hidden ${
          isDarkMode ? 'bg-slate-950 border-slate-800' : 'bg-slate-900 text-slate-100 border-slate-800'
        }`}>
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-950/90 text-xs font-mono">
            <span className="text-emerald-400 font-bold">{currentFile.path}</span>
            <span className="text-slate-500">{currentFile.mime}</span>
          </div>

          {/* Code Viewer */}
          <div className="p-4 overflow-x-auto max-h-[620px] text-xs font-mono leading-relaxed text-slate-300">
            <pre>{currentFile.content}</pre>
          </div>
        </div>
      </div>
    </div>
  );
};
