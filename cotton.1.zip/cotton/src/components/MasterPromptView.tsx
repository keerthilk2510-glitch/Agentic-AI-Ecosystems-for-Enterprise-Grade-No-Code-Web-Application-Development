import React, { useState } from 'react';
import { Copy, Check, Sparkles, Terminal, FileText, Download, ShieldCheck, Leaf, Layers } from 'lucide-react';

interface MasterPromptViewProps {
  isDarkMode: boolean;
}

export const MASTER_PROMPT_CONTENT = `# MASTER AI SYSTEM SPECIFICATION & IMPLEMENTATION PROMPT

## Project Title
**Smart Cotton Plant Disease Detection and Advisory System Using MobileNetV2 and Transfer Learning**
*AI-Powered Agriculture · Deep Learning · Precision Crop Care · Explainable AI*

---

### 1. Project Goal & Role
Act as an Elite AI/ML Systems Engineer, Computer Vision Researcher, Plant Pathology Specialist, and Senior UI/UX Architect.

Design, train, evaluate, and deploy a production-grade academic major project titled **“Smart Cotton Plant Disease Detection and Advisory System”**.
The system classifies cotton leaf images into seven predefined foliar condition classes using the benchmark **SAR-CLD-2024 / SAR-CLD-2026** dataset. The solution must feature a reproducible deep learning pipeline (MobileNetV2 transfer learning + fine-tuning), Grad-CAM explainability heatmaps, a structured agricultural advisory knowledge base, interactive model evaluation analytics (scikit-learn), and a dual web interface (Streamlit & Gradio) with a modern nature-leaf visual aesthetic.

---

### 2. Verified Technical Stack & Specifications

| Component | Selected Technology | Specification & Role |
| :--- | :--- | :--- |
| **Crop Target** | Cotton (*Gossypium hirsutum L.*) | Foliar disease detection & yield protection |
| **Dataset Benchmark** | SAR-CLD-2024 / SAR-CLD-2026 | 3,741 curated field-collected leaf images |
| **Deep Learning** | CNN (Convolutional Neural Network) | Inverted Residuals with Depthwise Separable Convolutions |
| **Architecture** | **MobileNetV2** (⭐ Primary Backbone) | Pretrained on ImageNet; 2.59M total parameters; 9.87 MB footprint |
| **Training Paradigm** | Transfer Learning + Fine-Tuning | Phase 1: Feature Extraction (LR=1e-4) -> Phase 2: Top 30 Layers Fine-Tuning (LR=1e-5) |
| **Classification Task** | 7-Class Mutually Exclusive Softmax | Bacterial Blight, Target Spot, Alternaria Spot, Powdery Mildew, Grey Mildew, Nutrient Deficiency, Healthy Leaf |
| **Input Specification** | 224 × 224 × 3 RGB Tensor | Normalization scaled to [-1.0, +1.0] using MobileNetV2 preprocess_input |
| **Explainability (XAI)** | Grad-CAM (Class Activation Mapping) | Real-time gradient-weighted heatmaps over Conv_1 feature map activations |
| **Advisory Engine** | Predefined Knowledge Base (JSON / Dict) | Pathogen etiology, exact chemical spray dosages, biocontrol, and cultural practices |
| **Primary Interfaces** | Gradio & Streamlit | Responsive dashboard with forest-green & ivory nature-leaf design |
| **Core Frameworks** | TensorFlow 2.x / Keras | Model definition, data augmentation, callbacks, and TFLite quantization |
| **Image Processing** | OpenCV (cv2) & PIL | RGB conversion, aspect-ratio preservation, interpolation |
| **Model Evaluation** | scikit-learn & Matplotlib | 7x7 Confusion Matrix, Precision, Recall, F1-Score, Training/Val Loss & Acc curves |
| **Cloud Endpoint** | Project: \`imcojddufqgptbjnfafv\` · Region: \`ap-south-1\` | Remote checkpoint sync, inference telemetry & advisory storage |
| **Development Setup** | VS Code (Local) & Google Colab (GPU) | Python 3.10+, PowerShell activation, modular repository tree |

---

### 3. Seven Predefined Cotton Foliar Classes
1. **Bacterial Blight** (*Xanthomonas citri* pv. *malvacearum*): Angular water-soaked lesions bounded by minor veins, blackarm progression.
2. **Target Spot** (*Corynespora cassiicola*): Bullseye-like concentric circular brown necrotic rings leading to premature defoliation.
3. **Alternaria Leaf Spot** (*Alternaria macrospora* / *alternata*): Irregular brown spots with purplish rims and brittle shot-hole centers.
4. **Powdery Mildew** (*Leveillula taurica*): White superficial powdery talcum mycelial coating on leaf lamina.
5. **Grey Mildew / Areolate Mildew** (*Ramularia areola*): Frosty greyish-white angular patches on abaxial surface bounded by veinlets.
6. **Nutrient Deficiency** (Potassium / Nitrogen / Magnesium): Interveinal chlorosis, bronze mottling, margin downward curl, and peripheral scorch.
7. **Healthy Cotton Leaf** (*Gossypium hirsutum*): Pristine emerald green lamina, vigorous vascular venation, zero pathological spotting.

---

### 4. Visual Design System: Modern Nature-Leaf Aesthetic
- **Atmospheric Canvas:** Modern nature leaf backdrop incorporating subtle organic botanical venation pattern SVG background.
  - **Light Mode:** Soft ivory / warm cream background (\`#f8fbf8\` / \`#fcfbf7\`), forest green accents (\`#15803d\`), and crisp hairline borders.
  - **Dark Mode:** Deep obsidian canopy (\`#070d0a\`), luminescent chloroplast green accents (\`#34d399\`), and dark slate surfaces.
  - Strict compliance with WCAG AA accessibility contrast ratios (minimum 4.5:1).
- **Interactive Gradio & Streamlit Dashboards:**
  - **Forest Green Brand Identity:** Primary tone \`#0e381f\`, leaf green accent \`#15803d\`, warning amber \`#b45309\`.
  - **Foliar Workspace:** Drag-and-drop file upload, live webcam snapshot, and SAR-CLD specimen carousel.
  - **Confidence Caution Slider:** Configurable threshold (default 65%) that flags ambiguous or out-of-domain images with an expert verification notice.
  - **Top-3 Ranked Predictions:** Horizontal distribution progress bars indicating candidate softmax probabilities.
  - **Grad-CAM Interactive Overlay:** Dual-layer canvas with thermal jet/turbo color mapping and dynamic opacity slider (0% to 100%).

---

### 5. Deep Learning Pipeline & Mathematical Formulation
- **Feature Extraction (Phase 1):**
  - MobileNetV2 backbone weights frozen (\`base_model.trainable = False\`).
  - Classification Head: \`GlobalAveragePooling2D\` $\\to$ \`BatchNormalization\` $\\to$ \`Dropout(0.35)\` $\\to$ \`Dense(256, activation='relu')\` $\\to$ \`BatchNormalization\` $\\to$ \`Dropout(0.20)\` $\\to$ \`Dense(7, activation='softmax')\`.
  - Optimizer: Adam with initial learning rate $\\eta = 10^{-4}$.
  - Loss: Categorical Cross-Entropy: $\\mathcal{L} = -\\sum_{c=1}^{7} y_c \\log(\\hat{y}_c)$.
- **Fine-Tuning (Phase 2):**
  - Unfreeze top 30 layers (\`layers[124:]\`).
  - Recompile with fine-tuning learning rate $\\eta = 10^{-5}$ to adjust high-level convolutional kernels without catastrophic forgetting.
  - Callbacks: \`ModelCheckpoint\` (monitor=\`val_accuracy\`), \`EarlyStopping\` (patience=5), \`ReduceLROnPlateau\` (factor=0.5, patience=3).
- **Edge Quantization:** Export trained model to \`TFLite\` using INT8 Post-Training Quantization (~2.64 MB).

---

### 6. Agricultural Advisory Knowledge Base Schema
Decoupled JSON knowledge base (\`cotton_advisory.json\`) containing:
- \`condition_name\`: Standard agricultural name
- \`scientific_name\`: Binomial pathogen designation
- \`pathogen_type\`: Bacterial | Fungal | Physiological / Nutrient | Healthy
- \`severity\`: None | Low | Moderate | High | Severe
- \`primary_symptoms\`: Concrete diagnostic field markers
- \`chemical_measures\`: Exact active ingredients, brand formulations, and dosages per liter of water
- \`biological_organic_measures\`: Biocontrol agents (*Trichoderma*, *Pseudomonas*, Neem oil 1500 ppm, sulfur)
- \`agronomic_preventive_practices\`: Canopy aeration, spacing, potassium correction, crop rotation
- \`environmental_triggers\`: Temperature and relative humidity outbreak criteria
- \`when_to_consult_expert\`: Clear escalation protocol for university extension agronomists

---

### 7. Evaluation & Benchmark Deliverables
- **Independent Test Set Evaluation:** Evaluated strictly on 561 held-out test images from SAR-CLD-2024.
- **Metrics Calculated:** Overall Accuracy (98.42%), Macro Precision (98.45%), Macro Recall (98.39%), Macro F1-Score (98.41%).
- **Interactive Confusion Matrix:** 7×7 grid showing actual vs. predicted distribution.
- **Learning Curves:** Training vs. validation loss and accuracy across all 30 epochs.
- **Comparative Benchmark:** Side-by-side comparison with ResNet50, VGG16, InceptionV3, and Custom CNN.

---

### 8. Modular Repository Architecture
\`\`\`text
Smart-Cotton-Plant-Disease-System/
├── app.py                             # Gradio Web Interface
├── config.py                          # Central configurations & 7-class list
├── requirements.txt                   # Dependency specifications
├── README.md                          # Windows PowerShell & Colab setup guide
├── src/
│   ├── preprocessing.py               # OpenCV BGR->RGB & MobileNetV2 normalizer
│   ├── model_utils.py                 # MobileNetV2 architecture & transfer learning
│   ├── predict.py                     # Inference, top-3 confidences & thresholds
│   ├── advisory.py                    # JSON knowledge base lookup engine
│   └── evaluation.py                  # scikit-learn metrics & confusion matrix
├── training/
│   ├── train_mobilenetv2.py           # Two-phase training script
│   └── cotton_disease_training.ipynb  # Google Colab GPU training notebook
└── knowledge_base/
    └── cotton_advisory.json           # Agronomic advisory knowledge base
\`\`\`

---

### 9. Execution Instructions & Deliverables
- Complete code for all modular Python files.
- Google Colab notebook ready for one-click GPU execution.
- Printable Field Agronomic Advisory Prescription Slip.
- Viva-Voce oral examination question bank with model answers.
`;

export const MasterPromptView: React.FC<MasterPromptViewProps> = ({ isDarkMode }) => {
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(MASTER_PROMPT_CONTENT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadPrompt = () => {
    const blob = new Blob([MASTER_PROMPT_CONTENT], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'SMART_COTTON_DISEASE_MASTER_PROMPT.md';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      {/* Editorial Header */}
      <div className="border-b pb-5 border-slate-200 dark:border-slate-800 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="text-xs uppercase font-mono tracking-wider mb-1 text-emerald-600 dark:text-emerald-400">
            Engineered Master Prompt Specification
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-50">
            Master AI Project Development Prompt
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 max-w-3xl">
            A comprehensive, modern prompt template designed for AI coding assistants to generate the complete deep learning system, Gradio interface, MobileNetV2 pipeline, and agronomic knowledge base.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className={`px-4 py-2 text-xs font-semibold rounded-lg border transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              copied
                ? 'bg-emerald-600 text-white border-emerald-600'
                : isDarkMode
                ? 'border-slate-800 text-slate-300 hover:bg-slate-800'
                : 'border-slate-300 text-slate-700 hover:bg-slate-100'
            }`}
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied Master Prompt' : 'Copy Master Prompt'}</span>
          </button>

          <button
            onClick={handleDownloadPrompt}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              isDarkMode
                ? 'bg-emerald-600 text-white hover:bg-emerald-500'
                : 'bg-emerald-700 text-white hover:bg-emerald-800'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>Download Prompt (.md)</span>
          </button>
        </div>
      </div>

      {/* Active Cloud Project Configuration Card */}
      <div className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs ${
        isDarkMode ? 'bg-slate-900/80 border-emerald-950/60' : 'bg-emerald-50/70 border-emerald-200'
      }`}>
        <div className="flex items-center gap-2.5">
          <Terminal className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
          <div>
            <span className="font-bold text-slate-900 dark:text-slate-100">
              Active Cloud Storage & Checkpoint Endpoint:
            </span>
            <div className="font-mono text-slate-600 dark:text-slate-300 mt-0.5">
              Project ID: <span className="text-emerald-700 dark:text-emerald-300 font-bold">imcojddufqgptbjnfafv</span> · Region: <span className="text-emerald-700 dark:text-emerald-300 font-bold">ap-south-1</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 border border-emerald-500/30">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Endpoint Configured</span>
          </span>
        </div>
      </div>

      {/* Visual Design Directives Badge Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className={`p-4 rounded-xl border space-y-1.5 ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-slate-100">
            <Leaf className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>01 — Nature-Tech Branding</span>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">
            Forest-green accents (\`#0e381f\`), ivory/cotton-white surfaces (\`#f8fbf8\`), organic leaf venation backdrop, and accessible WCAG AA contrast.
          </p>
        </div>

        <div className={`p-4 rounded-xl border space-y-1.5 ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-slate-100">
            <Layers className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>02 — AI Prediction & XAI Workspace</span>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">
            224×224 tensor preprocessing, MobileNetV2 softmax classification, ranked top-3 candidate distribution, and real-time Grad-CAM heatmap overlay.
          </p>
        </div>

        <div className={`p-4 rounded-xl border space-y-1.5 ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-slate-100">
            <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>03 — Cotton-Care Advisory</span>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">
            Predefined agronomic guidance: symptoms, chemical fungicide dosages, biological controls, agronomic cultural prevention, and threshold warning triggers.
          </p>
        </div>
      </div>

      {/* Formatted Master Prompt Code Block */}
      <div className={`rounded-2xl border overflow-hidden ${
        isDarkMode ? 'bg-slate-950 border-slate-800' : 'bg-slate-900 text-slate-100 border-slate-800'
      }`}>
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-950/90 text-xs font-mono">
          <span className="text-emerald-400 font-bold">SMART_COTTON_DISEASE_MASTER_PROMPT.md</span>
          <button
            onClick={handleCopy}
            className="text-slate-400 hover:text-white flex items-center gap-1 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>

        <div className="p-5 overflow-x-auto max-h-[700px] text-xs font-mono leading-relaxed text-slate-300">
          <pre>{MASTER_PROMPT_CONTENT}</pre>
        </div>
      </div>
    </div>
  );
};
