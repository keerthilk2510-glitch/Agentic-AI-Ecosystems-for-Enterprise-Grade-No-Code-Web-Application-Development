import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  Table,
  CheckCircle,
  HelpCircle,
  Cpu,
  Layers,
  ArrowUpRight
} from 'lucide-react';
import {
  CONFUSION_MATRIX,
  EVALUATION_METRICS,
  PER_CLASS_METRICS,
  TRAINING_HISTORY,
  MODEL_BENCHMARK_COMPARISONS
} from '../data/evaluationData.ts';

interface ModelEvaluationViewProps {
  isDarkMode: boolean;
}

export const ModelEvaluationView: React.FC<ModelEvaluationViewProps> = ({ isDarkMode }) => {
  const [activeChartMode, setActiveChartMode] = useState<'accuracy' | 'loss'>('accuracy');
  const [hoveredMatrixCell, setHoveredMatrixCell] = useState<{
    actualIdx: number;
    predIdx: number;
    count: number;
  } | null>(null);

  const [hoveredEpoch, setHoveredEpoch] = useState<number | null>(null);

  // SVG chart dimensions for loss/accuracy curve
  const chartW = 700;
  const chartH = 260;
  const padding = { top: 20, right: 30, bottom: 40, left: 50 };
  const innerW = chartW - padding.left - padding.right;
  const innerH = chartH - padding.top - padding.bottom;

  const maxEpoch = 30;
  const getX = (epoch: number) => padding.left + ((epoch - 1) / (maxEpoch - 1)) * innerW;

  // Accuracy scale: 0.6 to 1.0; Loss scale: 0.0 to 1.6
  const getAccY = (val: number) => {
    const min = 0.55;
    const max = 1.0;
    return padding.top + innerH - ((val - min) / (max - min)) * innerH;
  };

  const getLossY = (val: number) => {
    const min = 0.0;
    const max = 1.6;
    return padding.top + innerH - ((val - min) / (max - min)) * innerH;
  };

  // Build SVG path
  const trainPath = TRAINING_HISTORY.map((pt, i) => {
    const x = getX(pt.epoch);
    const y = activeChartMode === 'accuracy' ? getAccY(pt.trainAcc) : getLossY(pt.trainLoss);
    return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
  }).join(' ');

  const valPath = TRAINING_HISTORY.map((pt, i) => {
    const x = getX(pt.epoch);
    const y = activeChartMode === 'accuracy' ? getAccY(pt.valAcc) : getLossY(pt.valLoss);
    return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
  }).join(' ');

  return (
    <div className="space-y-8">
      {/* Editorial Header */}
      <div className="border-b pb-5 border-slate-200 dark:border-slate-800">
        <div className="text-xs uppercase font-mono tracking-wider mb-1 text-emerald-600 dark:text-emerald-400">
          Empirical Validation & Benchmark Metrics
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-50">
          MobileNetV2 Model Performance & scikit-learn Evaluation
        </h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 max-w-3xl">
          Comprehensive test set evaluation on 561 stratified test images from the SAR-CLD-2024 dataset, including confusion matrix, classification report, and fine-tuning learning dynamics.
        </p>
      </div>

      {/* Primary KPI Ribbon (Single-line tabular figures) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className={`p-4 rounded-xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <span className="text-[11px] font-mono uppercase text-slate-400 block">Overall Test Accuracy</span>
          <span className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1 block">
            {(EVALUATION_METRICS.overallAccuracy * 100).toFixed(2)}%
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">552 / 561 correct</span>
        </div>

        <div className={`p-4 rounded-xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <span className="text-[11px] font-mono uppercase text-slate-400 block">Macro Precision</span>
          <span className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-1 block">
            {(EVALUATION_METRICS.macroPrecision * 100).toFixed(2)}%
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">Zero false-positive skew</span>
        </div>

        <div className={`p-4 rounded-xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <span className="text-[11px] font-mono uppercase text-slate-400 block">Macro Recall</span>
          <span className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-1 block">
            {(EVALUATION_METRICS.macroRecall * 100).toFixed(2)}%
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">High sensitivity</span>
        </div>

        <div className={`p-4 rounded-xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <span className="text-[11px] font-mono uppercase text-slate-400 block">Macro F1-Score</span>
          <span className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-1 block">
            {(EVALUATION_METRICS.macroF1Score * 100).toFixed(2)}%
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">Harmonic balance</span>
        </div>

        <div className={`p-4 rounded-xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <span className="text-[11px] font-mono uppercase text-slate-400 block">Edge Footprint</span>
          <span className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-1 block">
            {EVALUATION_METRICS.modelFileSizeMb} MB
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">2.59M parameters</span>
        </div>

        <div className={`p-4 rounded-xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <span className="text-[11px] font-mono uppercase text-slate-400 block">CPU Latency</span>
          <span className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1 block">
            {EVALUATION_METRICS.inferenceLatencyCpuMs} ms
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">3.2 ms on mobile GPU</span>
        </div>
      </div>

      {/* Row 2: Confusion Matrix & Training Dynamics */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: 7x7 Interactive Confusion Matrix (6 cols) */}
        <div className={`lg:col-span-6 p-5 rounded-2xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                7-Class Confusion Matrix
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Rows = Ground Truth classes; Columns = MobileNetV2 predicted classes
              </p>
            </div>
            <span className="text-xs font-mono text-slate-400">N = 561 test images</span>
          </div>

          {/* Interactive Matrix Grid */}
          <div className="overflow-x-auto pb-2">
            <div className="min-w-[480px]">
              {/* Header column labels */}
              <div className="grid grid-cols-8 gap-1 mb-1 text-[10px] font-mono text-slate-400 text-center">
                <div className="text-left font-sans text-slate-500">Actual ↓ / Pred →</div>
                <div>BB</div>
                <div>TS</div>
                <div>ALS</div>
                <div>PM</div>
                <div>GM</div>
                <div>ND</div>
                <div>HL</div>
              </div>

              {/* Rows */}
              {CONFUSION_MATRIX.matrix.map((row, rowIdx) => {
                const totalInRow = row.reduce((a, b) => a + b, 0);

                return (
                  <div key={rowIdx} className="grid grid-cols-8 gap-1 mb-1 items-center">
                    {/* Row Label */}
                    <div className="text-[11px] font-medium text-slate-700 dark:text-slate-300 truncate pr-1" title={CONFUSION_MATRIX.classes[rowIdx]}>
                      {CONFUSION_MATRIX.classes[rowIdx]}
                    </div>

                    {/* Cells */}
                    {row.map((val, colIdx) => {
                      const isDiagonal = rowIdx === colIdx;
                      const pct = totalInRow > 0 ? (val / totalInRow) * 100 : 0;
                      
                      // Intensity
                      let bgStyle = isDarkMode ? 'bg-slate-800/40 text-slate-400' : 'bg-slate-100 text-slate-500';
                      if (isDiagonal && val > 0) {
                        bgStyle = isDarkMode
                          ? 'bg-emerald-600/90 text-white font-bold'
                          : 'bg-emerald-700 text-white font-bold';
                      } else if (!isDiagonal && val > 0) {
                        bgStyle = isDarkMode
                          ? 'bg-rose-950 text-rose-300 font-semibold'
                          : 'bg-rose-100 text-rose-800 font-semibold';
                      }

                      return (
                        <div
                          key={colIdx}
                          onMouseEnter={() =>
                            setHoveredMatrixCell({ actualIdx: rowIdx, predIdx: colIdx, count: val })
                          }
                          onMouseLeave={() => setHoveredMatrixCell(null)}
                          className={`aspect-square flex flex-col items-center justify-center rounded cursor-pointer transition-transform hover:scale-105 text-xs font-mono ${bgStyle}`}
                        >
                          <span>{val}</span>
                          {isDiagonal && (
                            <span className="text-[9px] opacity-80">{pct.toFixed(0)}%</span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Matrix Cell Inspector HUD */}
          <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800/70 text-xs">
            {hoveredMatrixCell ? (
              <div className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                <div>
                  <strong>Actual:</strong> {CONFUSION_MATRIX.classes[hoveredMatrixCell.actualIdx]} →{' '}
                  <strong>Predicted:</strong> {CONFUSION_MATRIX.classes[hoveredMatrixCell.predIdx]}
                </div>
                <div className="font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                  {hoveredMatrixCell.count} samples (
                  {hoveredMatrixCell.actualIdx === hoveredMatrixCell.predIdx ? 'Correct Hit' : 'Misclassification'})
                </div>
              </div>
            ) : (
              <div className="text-slate-400 text-center font-mono text-[11px]">
                Hover over matrix cells to inspect class-to-class predictions.
              </div>
            )}
          </div>
        </div>

        {/* Right: Training & Validation Curves (6 cols) */}
        <div className={`lg:col-span-6 p-5 rounded-2xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Learning Dynamics across 30 Epochs
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Phase 1: Feature Extraction (1-15) · Phase 2: Fine-Tuning (16-30)
              </p>
            </div>

            {/* Segmented Control */}
            <div className={`flex p-0.5 rounded-lg border text-xs ${
              isDarkMode ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'
            }`}>
              <button
                onClick={() => setActiveChartMode('accuracy')}
                className={`px-2.5 py-1 rounded font-medium transition-colors ${
                  activeChartMode === 'accuracy'
                    ? isDarkMode ? 'bg-emerald-600 text-white' : 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                Accuracy
              </button>
              <button
                onClick={() => setActiveChartMode('loss')}
                className={`px-2.5 py-1 rounded font-medium transition-colors ${
                  activeChartMode === 'loss'
                    ? isDarkMode ? 'bg-emerald-600 text-white' : 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                Loss
              </button>
            </div>
          </div>

          {/* SVG Line Chart */}
          <div className="relative w-full overflow-hidden">
            <svg viewBox={`0 0 ${chartW} ${chartH}`} className="w-full h-auto">
              {/* Grid Lines */}
              {[0, 1, 2, 3, 4].map((step) => {
                const y = padding.top + (innerH / 4) * step;
                return (
                  <line
                    key={step}
                    x1={padding.left}
                    y1={y}
                    x2={chartW - padding.right}
                    y2={y}
                    stroke={isDarkMode ? '#1e293b' : '#f1f5f9'}
                    strokeWidth="1"
                  />
                );
              })}

              {/* Phase 1 / Phase 2 boundary divider */}
              <line
                x1={getX(15.5)}
                y1={padding.top}
                x2={getX(15.5)}
                y2={padding.top + innerH}
                stroke={isDarkMode ? '#334155' : '#cbd5e1'}
                strokeWidth="1.5"
                strokeDasharray="4 4"
              />

              <text
                x={getX(7.5)}
                y={padding.top + 14}
                textAnchor="middle"
                fontSize="10"
                fontFamily="JetBrains Mono"
                fill={isDarkMode ? '#64748b' : '#94a3b8'}
              >
                PHASE 1 (FROZEN BACKBONE)
              </text>
              <text
                x={getX(23)}
                y={padding.top + 14}
                textAnchor="middle"
                fontSize="10"
                fontFamily="JetBrains Mono"
                fill={isDarkMode ? '#64748b' : '#94a3b8'}
              >
                PHASE 2 (FINE-TUNING)
              </text>

              {/* Data paths */}
              <path
                d={trainPath}
                fill="none"
                stroke={isDarkMode ? '#34d399' : '#059669'}
                strokeWidth="2.5"
              />
              <path
                d={valPath}
                fill="none"
                stroke={isDarkMode ? '#38bdf8' : '#2563eb'}
                strokeWidth="2.5"
                strokeDasharray="6 3"
              />

              {/* Axis labels */}
              <text
                x={padding.left}
                y={chartH - 12}
                fontSize="10"
                fontFamily="JetBrains Mono"
                fill={isDarkMode ? '#64748b' : '#94a3b8'}
              >
                Epoch 1
              </text>
              <text
                x={getX(15)}
                y={chartH - 12}
                fontSize="10"
                fontFamily="JetBrains Mono"
                fill={isDarkMode ? '#64748b' : '#94a3b8'}
              >
                Epoch 15
              </text>
              <text
                x={chartW - padding.right - 45}
                y={chartH - 12}
                fontSize="10"
                fontFamily="JetBrains Mono"
                fill={isDarkMode ? '#64748b' : '#94a3b8'}
              >
                Epoch 30
              </text>
            </svg>
          </div>

          {/* Chart Legend */}
          <div className="flex items-center justify-between text-xs font-mono pt-3 border-t border-slate-100 dark:border-slate-800/70">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-1 bg-emerald-600 dark:bg-emerald-400 inline-block rounded" />
                <span className="text-slate-600 dark:text-slate-300">Training Curve</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-1 bg-blue-600 dark:bg-blue-400 inline-block rounded border-dashed" />
                <span className="text-slate-600 dark:text-slate-300">Validation Curve</span>
              </div>
            </div>
            <span className="text-slate-400 text-[11px]">Final Val Acc: 98.4% · Val Loss: 0.058</span>
          </div>
        </div>
      </div>

      {/* Row 3: scikit-learn Classification Report Table */}
      <div className={`p-5 rounded-2xl border ${
        isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Per-Class Classification Report (scikit-learn format)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Precision, Recall, and F1-Score calculated across each condition class on the test subset.
            </p>
          </div>
          <span className="text-xs font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
            macro avg F1 = 0.9841
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className={`border-b text-[11px] font-mono uppercase text-slate-400 ${
                isDarkMode ? 'border-slate-800' : 'border-slate-200'
              }`}>
                <th className="py-2.5 pr-4 font-semibold">Condition Class</th>
                <th className="py-2.5 px-3 text-right font-semibold">Precision</th>
                <th className="py-2.5 px-3 text-right font-semibold">Recall</th>
                <th className="py-2.5 px-3 text-right font-semibold">F1-Score</th>
                <th className="py-2.5 pl-3 text-right font-semibold">Support (N)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono">
              {PER_CLASS_METRICS.map((row) => (
                <tr key={row.classId} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                  <td className="py-2.5 pr-4 font-sans font-medium text-slate-800 dark:text-slate-200">
                    {row.className}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-700 dark:text-slate-300">
                    {row.precision.toFixed(4)}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-700 dark:text-slate-300">
                    {row.recall.toFixed(4)}
                  </td>
                  <td className="py-2.5 px-3 text-right font-semibold text-emerald-600 dark:text-emerald-400">
                    {row.f1Score.toFixed(4)}
                  </td>
                  <td className="py-2.5 pl-3 text-right text-slate-500">
                    {row.support}
                  </td>
                </tr>
              ))}

              {/* Summary Rows */}
              <tr className="border-t-2 border-slate-200 dark:border-slate-700 font-bold">
                <td className="py-2.5 pr-4 font-sans text-slate-900 dark:text-slate-100">
                  Accuracy
                </td>
                <td colSpan={2} className="py-2.5 px-3 text-center text-slate-400 italic">
                  —
                </td>
                <td className="py-2.5 px-3 text-right text-emerald-600 dark:text-emerald-400">
                  {EVALUATION_METRICS.overallAccuracy.toFixed(4)}
                </td>
                <td className="py-2.5 pl-3 text-right text-slate-900 dark:text-slate-100">
                  {EVALUATION_METRICS.testSetSize}
                </td>
              </tr>

              <tr className="text-slate-600 dark:text-slate-400 font-semibold">
                <td className="py-2 pr-4 font-sans">Macro Average</td>
                <td className="py-2 px-3 text-right">{EVALUATION_METRICS.macroPrecision.toFixed(4)}</td>
                <td className="py-2 px-3 text-right">{EVALUATION_METRICS.macroRecall.toFixed(4)}</td>
                <td className="py-2 px-3 text-right text-emerald-600 dark:text-emerald-400">
                  {EVALUATION_METRICS.macroF1Score.toFixed(4)}
                </td>
                <td className="py-2 pl-3 text-right">{EVALUATION_METRICS.testSetSize}</td>
              </tr>

              <tr className="text-slate-600 dark:text-slate-400 font-semibold">
                <td className="py-2 pr-4 font-sans">Weighted Average</td>
                <td className="py-2 px-3 text-right">0.9844</td>
                <td className="py-2 px-3 text-right">0.9842</td>
                <td className="py-2 px-3 text-right text-emerald-600 dark:text-emerald-400">
                  {EVALUATION_METRICS.weightedF1Score.toFixed(4)}
                </td>
                <td className="py-2 pl-3 text-right">{EVALUATION_METRICS.testSetSize}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Row 4: Architectural Benchmark Comparison Table */}
      <div className={`p-5 rounded-2xl border ${
        isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <div className="mb-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
            CNN Architecture Benchmark: MobileNetV2 vs Alternatives
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Empirical comparison explaining why MobileNetV2 was selected for agricultural edge deployment.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className={`border-b text-[11px] font-mono uppercase text-slate-400 ${
                isDarkMode ? 'border-slate-800' : 'border-slate-200'
              }`}>
                <th className="py-2.5 pr-4">Architecture</th>
                <th className="py-2.5 px-3 text-right">Accuracy</th>
                <th className="py-2.5 px-3 text-right">Parameters</th>
                <th className="py-2.5 px-3 text-right">Model Size</th>
                <th className="py-2.5 px-3 text-right">CPU Latency</th>
                <th className="py-2.5 px-3 text-right">GPU Latency</th>
                <th className="py-2.5 pl-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono">
              {MODEL_BENCHMARK_COMPARISONS.map((m, idx) => (
                <tr
                  key={idx}
                  className={`transition-colors ${
                    m.isProposed
                      ? isDarkMode
                        ? 'bg-emerald-950/30 font-semibold'
                        : 'bg-emerald-50/70 font-semibold'
                      : 'hover:bg-slate-50/50 dark:hover:bg-slate-800/30'
                  }`}
                >
                  <td className="py-2.5 pr-4 font-sans text-slate-900 dark:text-slate-100">
                    {m.model}
                  </td>
                  <td className="py-2.5 px-3 text-right text-emerald-600 dark:text-emerald-400 font-bold">
                    {m.accuracy}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-700 dark:text-slate-300">
                    {m.params}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-700 dark:text-slate-300">
                    {m.sizeMb}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-700 dark:text-slate-300">
                    {m.cpuLatencyMs}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-700 dark:text-slate-300">
                    {m.gpuLatencyMs}
                  </td>
                  <td className="py-2.5 pl-3 text-center">
                    {m.isProposed ? (
                      <span className="text-[11px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                        ★ Selected
                      </span>
                    ) : (
                      <span className="text-[11px] text-slate-400">Baseline</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
