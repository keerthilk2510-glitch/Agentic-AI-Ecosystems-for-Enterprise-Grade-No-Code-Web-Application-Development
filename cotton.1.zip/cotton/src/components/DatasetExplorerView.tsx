import React from 'react';
import { Database, Image as ImageIcon, CheckCircle, ShieldCheck, PieChart, Layers } from 'lucide-react';
import { COTTON_CLASSES, COTTON_KNOWLEDGE_BASE } from '../data/cottonKnowledgeBase.ts';
import { EVALUATION_METRICS } from '../data/evaluationData.ts';

interface DatasetExplorerViewProps {
  isDarkMode: boolean;
  onSelectSample: (classId: any) => void;
}

export const DatasetExplorerView: React.FC<DatasetExplorerViewProps> = ({
  isDarkMode,
  onSelectSample,
}) => {
  return (
    <div className="space-y-8">
      {/* Editorial Header */}
      <div className="border-b pb-5 border-slate-200 dark:border-slate-800">
        <div className="text-xs uppercase font-mono tracking-wider mb-1 text-emerald-600 dark:text-emerald-400">
          Curated Agricultural Benchmark
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-50">
          SAR-CLD-2024 Dataset Overview & Distribution
        </h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 max-w-3xl">
          South Asian Region Cotton Leaf Disease dataset comprising 3,741 high-resolution annotated leaf images categorized into 7 distinct pathological and physiological condition classes.
        </p>
      </div>

      {/* Dataset Overview KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className={`p-4 rounded-xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <span className="text-[11px] font-mono uppercase text-slate-400 block">Total Specimen Images</span>
          <span className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1 block">
            {EVALUATION_METRICS.totalImages.toLocaleString()}
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">High-resolution in situ RGB</span>
        </div>

        <div className={`p-4 rounded-xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <span className="text-[11px] font-mono uppercase text-slate-400 block">Training Subset (70%)</span>
          <span className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-1 block">
            {EVALUATION_METRICS.trainingSetSize.toLocaleString()}
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">Stratified balanced split</span>
        </div>

        <div className={`p-4 rounded-xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <span className="text-[11px] font-mono uppercase text-slate-400 block">Validation Subset (15%)</span>
          <span className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-1 block">
            {EVALUATION_METRICS.validationSetSize.toLocaleString()}
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">Early stopping monitor</span>
        </div>

        <div className={`p-4 rounded-xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <span className="text-[11px] font-mono uppercase text-slate-400 block">Test Subset (15%)</span>
          <span className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-1 block">
            {EVALUATION_METRICS.testSetSize.toLocaleString()}
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">Strict held-out evaluation</span>
        </div>
      </div>

      {/* Class Distribution Bars & Methodology */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Class distribution progress bars */}
        <div className={`lg:col-span-7 p-5 rounded-2xl border ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Class Sample Distribution & Split Verification
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Stratified division ensures representative sample distribution across all 7 conditions.
              </p>
            </div>
            <span className="text-xs font-mono text-slate-400">7 Classes</span>
          </div>

          <div className="space-y-3.5">
            {COTTON_CLASSES.map((cls) => {
              const info = COTTON_KNOWLEDGE_BASE[cls.id];
              const pct = (info.sarCldImageCount / EVALUATION_METRICS.totalImages) * 100;
              const trainCount = Math.round(info.sarCldImageCount * 0.7);
              const valCount = Math.round(info.sarCldImageCount * 0.15);
              const testCount = info.sarCldImageCount - trainCount - valCount;

              return (
                <div key={cls.id} className="space-y-1 text-xs">
                  <div className="flex justify-between items-center font-mono">
                    <span className="font-sans font-medium text-slate-800 dark:text-slate-200">
                      {info.name}
                    </span>
                    <span className="text-slate-500">
                      {info.sarCldImageCount} imgs ({pct.toFixed(1)}%)
                    </span>
                  </div>

                  {/* Multi-segment stratified bar */}
                  <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full flex overflow-hidden">
                    <div
                      className="h-full bg-emerald-600 dark:bg-emerald-500"
                      style={{ width: `${pct * 0.70}%` }}
                      title={`Train: ${trainCount}`}
                    />
                    <div
                      className="h-full bg-blue-500 dark:bg-blue-400"
                      style={{ width: `${pct * 0.15}%` }}
                      title={`Val: ${valCount}`}
                    />
                    <div
                      className="h-full bg-amber-500 dark:bg-amber-400"
                      style={{ width: `${pct * 0.15}%` }}
                      title={`Test: ${testCount}`}
                    />
                  </div>

                  <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                    <span>Train: {trainCount}</span>
                    <span>Val: {valCount}</span>
                    <span>Test: {testCount}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center gap-4 text-xs font-mono">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-emerald-600 rounded-full inline-block" />
              <span className="text-slate-600 dark:text-slate-300">Train (70%)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-blue-500 rounded-full inline-block" />
              <span className="text-slate-600 dark:text-slate-300">Validation (15%)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-amber-500 rounded-full inline-block" />
              <span className="text-slate-600 dark:text-slate-300">Test (15%)</span>
            </div>
          </div>
        </div>

        {/* Dataset Curation & Quality Assurance Specs */}
        <div className={`lg:col-span-5 p-5 rounded-2xl border space-y-4 ${
          isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Dataset Quality & Ingestion Protocol
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Strict academic quality standards adhered to during pipeline preparation.
            </p>
          </div>

          <div className="space-y-3 text-xs leading-relaxed">
            <div className="flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-800 dark:text-slate-200">Zero Data Leakage Guarantee:</strong>
                <p className="text-slate-500 dark:text-slate-400 mt-0.5">
                  Foliar data augmentations (rotations, horizontal flips, zooms) are applied exclusively to the training stream. Validation and test pipelines remain pristine and un-augmented.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-800 dark:text-slate-200">Integrity & Sanitization:</strong>
                <p className="text-slate-500 dark:text-slate-400 mt-0.5">
                  Automated md5 checksum verification removes duplicate exposures. Corrupt EXIF headers and blurred out-of-focus samples are pruned.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-800 dark:text-slate-200">Stratified Splitting:</strong>
                <p className="text-slate-500 dark:text-slate-400 mt-0.5">
                  Class ratios in the test and validation sets match the overall distribution exactly, preventing class imbalance skew during cross-entropy evaluation.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-800 dark:text-slate-200">Ground-Truth Pathology Annotations:</strong>
                <p className="text-slate-500 dark:text-slate-400 mt-0.5">
                  All 7 condition classifications verified by senior agricultural plant pathologists from regional agricultural research institutes.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 7-Class Visual Specimen Gallery */}
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
            SAR-CLD-2024 Visual Specimen Catalog
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Click on any specimen to load directly into the real-time MobileNetV2 diagnostic pipeline.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {COTTON_CLASSES.map((cls) => {
            const info = COTTON_KNOWLEDGE_BASE[cls.id];

            return (
              <div
                key={cls.id}
                onClick={() => onSelectSample(cls.id)}
                className={`group rounded-xl border overflow-hidden cursor-pointer transition-all hover:shadow-md ${
                  isDarkMode
                    ? 'bg-slate-900/60 border-slate-800 hover:border-emerald-500/60'
                    : 'bg-white border-slate-200 hover:border-emerald-600/60'
                }`}
              >
                <div className="aspect-[4/3] w-full overflow-hidden bg-slate-100 dark:bg-slate-800 relative">
                  <img
                    src={info.sampleImagePath}
                    alt={info.name}
                    className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-300"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-black/70 text-white backdrop-blur-xs">
                    {info.pathogenType}
                  </div>
                </div>

                <div className="p-3.5 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 group-hover:text-emerald-600 transition-colors">
                      {info.name}
                    </h4>
                    <span className="text-[11px] font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                      {info.sarCldImageCount} imgs
                    </span>
                  </div>

                  <p className="text-xs italic text-slate-500 line-clamp-1">
                    {info.scientificName}
                  </p>

                  <p className="text-[11px] text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed">
                    {info.leafVisualCharacteristics}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
