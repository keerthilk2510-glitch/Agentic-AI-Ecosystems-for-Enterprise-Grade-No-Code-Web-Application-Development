import React from 'react';
import { X, Printer, Leaf, ShieldAlert, Droplets, Sparkles, CheckCircle2 } from 'lucide-react';
import { PredictionResult } from '../types/cotton.ts';

interface ReportModalProps {
  prediction: PredictionResult;
  onClose: () => void;
  isDarkMode: boolean;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  prediction,
  onClose,
  isDarkMode,
}) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className={`w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl border shadow-2xl transition-colors ${
        isDarkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
      }`}>
        {/* Modal Controls (No print) */}
        <div className="no-print sticky top-0 z-10 flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800 bg-inherit backdrop-blur-md">
          <div className="flex items-center gap-2">
            <Leaf className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <span className="text-sm font-bold">Field Agronomic Advisory Report</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 text-white hover:bg-emerald-500 transition-colors flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Field Report Sheet */}
        <div className="p-8 space-y-6 print-card">
          {/* Slip Header */}
          <div className="border-b-2 border-emerald-700 pb-4 flex justify-between items-start">
            <div>
              <span className="text-xs uppercase font-mono tracking-wider text-emerald-700 dark:text-emerald-400 font-bold">
                SAR-CLD-2024 Agricultural Advisory Service
              </span>
              <h2 className="text-xl font-bold mt-1 text-slate-900 dark:text-slate-50">
                Cotton Foliar Pathology & Prescription Slip
              </h2>
              <div className="text-xs text-slate-500 font-mono mt-1">
                Diagnostic Architecture: MobileNetV2 Transfer Learning · 7-Class Model
              </div>
            </div>

            <div className="text-right text-xs font-mono text-slate-500">
              <div><strong>Date:</strong> {new Date().toLocaleDateString()}</div>
              <div><strong>Time:</strong> {prediction.analyzedAt}</div>
              <div><strong>Status:</strong> Verified</div>
            </div>
          </div>

          {/* Diagnostic Verdict Block */}
          <div className="p-4 rounded-xl border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/50 dark:bg-emerald-950/20 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="text-xs font-mono text-emerald-800 dark:text-emerald-300 uppercase">
                Diagnostic Classification
              </div>
              <div className="text-2xl font-bold text-slate-900 dark:text-slate-50">
                {prediction.className}
              </div>
              <div className="text-xs italic text-emerald-700 dark:text-emerald-400 font-medium mt-0.5">
                Pathogen: {prediction.scientificName} ({prediction.advisory.pathogenType})
              </div>
            </div>

            <div className="text-right shrink-0">
              <div className="text-3xl font-bold font-mono text-emerald-700 dark:text-emerald-400">
                {(prediction.confidence * 100).toFixed(1)}%
              </div>
              <div className="text-xs font-mono text-slate-500">
                Severity: <strong className="text-slate-900 dark:text-slate-100">{prediction.severity}</strong> · {prediction.inferenceTimeMs} ms
              </div>
            </div>
          </div>

          {/* Visual Symptoms Summary */}
          <div className="space-y-2">
            <h4 className="text-xs uppercase font-mono font-bold text-slate-400 tracking-wider">
              1. Observed Foliar Symptoms
            </h4>
            <div className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
              {prediction.advisory.primarySymptoms.map((symp, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-emerald-600">●</span>
                  <span>{symp}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Chemical Prescription */}
          <div className="space-y-2">
            <h4 className="text-xs uppercase font-mono font-bold text-slate-400 tracking-wider">
              2. Chemical Control Measures (Fungicides / Bactericides)
            </h4>
            <div className="space-y-2">
              {prediction.advisory.treatments
                .filter((t) => t.category === 'Chemical')
                .map((t, i) => (
                  <div key={i} className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 text-xs">
                    <div className="font-semibold text-slate-900 dark:text-slate-100 flex justify-between">
                      <span>{t.title}</span>
                      {t.dosage && <span className="font-mono text-emerald-700 dark:text-emerald-400">{t.dosage}</span>}
                    </div>
                    <p className="text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                      {t.recommendation}
                    </p>
                    {t.applicationSchedule && (
                      <div className="text-[11px] font-mono text-slate-500 mt-1">
                        Schedule: {t.applicationSchedule}
                      </div>
                    )}
                  </div>
                ))}
            </div>
          </div>

          {/* Organic & Agronomic Measures */}
          <div className="space-y-2">
            <h4 className="text-xs uppercase font-mono font-bold text-slate-400 tracking-wider">
              3. Biological & Agronomic Management
            </h4>
            <div className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
              {prediction.advisory.preventionMeasures.map((measure, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="font-bold text-emerald-600">0{i + 1}.</span>
                  <span>{measure}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Outbreak Trigger Environmental Warning */}
          <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 text-xs text-amber-900 dark:text-amber-200">
            <strong>Environmental Outbreak Criteria:</strong> Temperature: {prediction.advisory.environmentalTriggers.tempRange} | Humidity: {prediction.advisory.environmentalTriggers.humidity} ({prediction.advisory.environmentalTriggers.weatherCondition})
          </div>

          {/* Disclaimer & Footer */}
          <div className="border-t pt-4 text-[11px] text-slate-400 flex justify-between items-center font-mono">
            <span>CottonVision AI Advisory System · Academic Major Project</span>
            <span>Dataset: SAR-CLD-2024 · MobileNetV2</span>
          </div>
        </div>
      </div>
    </div>
  );
};
