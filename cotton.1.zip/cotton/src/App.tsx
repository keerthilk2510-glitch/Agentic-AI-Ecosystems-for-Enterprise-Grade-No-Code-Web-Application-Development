/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar, ActiveTab } from './components/Navbar.tsx';
import { DiagnosisView } from './components/DiagnosisView.tsx';
import { GradioDashboardView } from './components/GradioDashboardView.tsx';
import { ModelEvaluationView } from './components/ModelEvaluationView.tsx';
import { DatasetExplorerView } from './components/DatasetExplorerView.tsx';
import { ArchitectureView } from './components/ArchitectureView.tsx';
import { AcademicDocsView } from './components/AcademicDocsView.tsx';
import { CodeArtifactsView } from './components/CodeArtifactsView.tsx';
import { MasterPromptView } from './components/MasterPromptView.tsx';
import { ReportModal } from './components/ReportModal.tsx';
import { PredictionResult, CottonClassId } from './types/cotton.ts';
import { COTTON_KNOWLEDGE_BASE } from './data/cottonKnowledgeBase.ts';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('diagnosis');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  const [activeReportPrediction, setActiveReportPrediction] = useState<PredictionResult | null>(null);

  // Sync dark class on documentElement for tailwind dark styling
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleOpenReportFromNav = () => {
    if (!activeReportPrediction) {
      const info = COTTON_KNOWLEDGE_BASE['bacterial_blight'];
      setActiveReportPrediction({
        classId: 'bacterial_blight',
        className: info.name,
        scientificName: info.scientificName,
        confidence: 0.984,
        inferenceTimeMs: 14.8,
        allProbabilities: [
          { classId: 'bacterial_blight', className: info.name, probability: 0.984 },
          { classId: 'target_spot', className: 'Target Spot', probability: 0.012 },
          { classId: 'alternaria_spot', className: 'Alternaria Leaf Spot', probability: 0.003 },
        ],
        severity: info.severity,
        advisory: info,
        analyzedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        imageDimensions: { width: 224, height: 224 },
      });
    }
  };

  const handleSelectSampleFromDataset = (classId: CottonClassId) => {
    setActiveTab('diagnosis');
  };

  return (
    <div
      className={`min-h-screen transition-colors duration-200 flex flex-col ${
        isDarkMode
          ? 'nature-leaf-bg-dark text-slate-100'
          : 'nature-leaf-bg-light text-slate-900'
      }`}
    >
      {/* Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
        onOpenReport={handleOpenReportFromNav}
      />

      {/* Main Content Stage */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'diagnosis' && (
          <DiagnosisView
            isDarkMode={isDarkMode}
            onOpenReport={(res) => setActiveReportPrediction(res)}
          />
        )}

        {activeTab === 'gradio' && (
          <GradioDashboardView
            isDarkMode={isDarkMode}
            onOpenReport={(res) => setActiveReportPrediction(res)}
          />
        )}

        {activeTab === 'evaluation' && (
          <ModelEvaluationView isDarkMode={isDarkMode} />
        )}

        {activeTab === 'dataset' && (
          <DatasetExplorerView
            isDarkMode={isDarkMode}
            onSelectSample={handleSelectSampleFromDataset}
          />
        )}

        {activeTab === 'architecture' && (
          <ArchitectureView isDarkMode={isDarkMode} />
        )}

        {activeTab === 'academic' && (
          <AcademicDocsView isDarkMode={isDarkMode} />
        )}

        {activeTab === 'code' && (
          <CodeArtifactsView isDarkMode={isDarkMode} />
        )}

        {activeTab === 'prompt' && (
          <MasterPromptView isDarkMode={isDarkMode} />
        )}
      </main>

      {/* Project Footnote */}
      <footer
        className={`border-t py-8 text-xs transition-colors ${
          isDarkMode
            ? 'border-slate-900 bg-slate-950/70 text-slate-500'
            : 'border-slate-200/80 bg-white/80 text-slate-500'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center md:text-left">
            <p className="font-semibold text-slate-700 dark:text-slate-300">
              Smart Cotton Plant Disease Detection and Advisory System
            </p>
            <p className="text-[11px]">
              Academic Major Project · MobileNetV2 Transfer Learning · SAR-CLD-2024 / 2026 Dataset (7 Classes)
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1 font-mono text-[11px] text-slate-400">
            <span>TensorFlow/Keras</span>
            <span>·</span>
            <span>MobileNetV2</span>
            <span>·</span>
            <span>scikit-learn</span>
            <span>·</span>
            <span>Gradio</span>
            <span>·</span>
            <span>OpenCV</span>
            <span>·</span>
            <span>NumPy</span>
          </div>
        </div>
      </footer>

      {/* Printable Report Modal */}
      {activeReportPrediction && (
        <ReportModal
          prediction={activeReportPrediction}
          onClose={() => setActiveReportPrediction(null)}
          isDarkMode={isDarkMode}
        />
      )}
    </div>
  );
}
