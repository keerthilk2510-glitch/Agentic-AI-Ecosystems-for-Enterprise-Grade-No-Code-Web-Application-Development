import { CottonClassId, CottonConditionInfo } from '../types/cotton.ts';

export const COTTON_CLASSES: { id: CottonClassId; name: string; index: number }[] = [
  { id: 'cotton_bacterial_blight_1791647148723.jpg', name: 'Bacterial Blight', index: 0 },
  { id: 'cotton_target_spot_1791647161374.jpg', name: 'Target Spot', index: 1 },
  { id: 'cotton_alternaria_spot_1791647286604.jpg', name: 'Alternaria Leaf Spot', index: 2 },
  { id: 'cotton_powdery_mildew_1791647172981.jpg', name: 'Powdery Mildew', index: 3 },
  { id: 'cotton_grey_mildew_1791647148723.jpg', name: 'Grey Mildew', index: 4 },
  { id: 'cotton_nutrient_deficiency_1791647311124.jpg', name: 'Nutrient Deficiency', index: 5 },
  { id: 'cotton_healthy_leaf_1791647135053.jpg', name: 'Healthy Leaf', index: 6 },
];

export const COTTON_KNOWLEDGE_BASE: Record<CottonClassId, CottonConditionInfo> = {
  bacterial_blight: {
    id: 'bacterial_blight',
    name: 'Bacterial Blight',
    scientificName: 'Xanthomonas citri pv. malvacearum',
    pathogenType: 'Bacterial',
    commonNames: ['Angular Leaf Spot', 'Blackarm', 'Boll Rot'],
    severity: 'High',
    primarySymptoms: [
      'Small, angular, water-soaked translucent lesions bounded strictly by leaf veinlets',
      'Spots turn dark reddish-brown to black with chlorotic yellowish halos',
      'Lesions coalesce causing systemic leaf blight, premature defoliation, and stem blackarm',
      'Infected bolls exhibit round water-soaked sunken lesions leading to lint discoloration and internal boll rotting'
    ],
    leafVisualCharacteristics: 'Geometric angular dark necrotic patches constrained by veins, visible from both abaxial and adaxial surfaces.',
    environmentalTriggers: {
      tempRange: '28°C – 34°C',
      humidity: '> 85% Relative Humidity',
      weatherCondition: 'Warm spells with intermittent heavy rainfall, overhead sprinkler splash, and persistent dew'
    },
    economicImpact: 'Can cause 20% to 35% crop yield loss and severe fiber quality degradation when early canopy defoliation occurs during peak boll development.',
    treatments: [
      {
        category: 'Chemical',
        title: 'Copper Oxychloride + Streptocycline Combination',
        recommendation: 'Apply Copper Oxychloride 50 WP (2.5 g/L) mixed with Streptomycin sulphate + Tetracycline hydrochloride (Streptocycline 100 ppm, approx 1 g per 10 L water).',
        dosage: '2.5 g COC + 0.1 g Streptocycline per Liter of water',
        applicationSchedule: 'Spray at first symptom onset; repeat after 12–15 days if humid conditions persist.',
        cautions: 'Avoid spraying in midday heat (>35°C) to prevent foliar phytotoxicity. Observe 14-day pre-harvest interval.'
      },
      {
        category: 'Biological/Organic',
        title: 'Pseudomonas fluorescens & Neem Formulations',
        recommendation: 'Foliar application of biocontrol agent Pseudomonas fluorescens (10 g/L or 2.5 kg/ha) or 5% Neem Seed Kernel Extract (NSKE).',
        dosage: '10 g/L P. fluorescens talc formulation',
        applicationSchedule: 'Preventive foliar application every 10–14 days starting at 45 days after sowing.'
      },
      {
        category: 'Agronomic/Cultural',
        title: 'Canopy Aeration & Residue Sanitation',
        recommendation: 'Destroy crop debris from previous harvest to remove primary inoculum. Avoid excessive nitrogenous fertilizers that promote succulent foliage. Employ furrow or drip irrigation instead of overhead sprinklers.'
      }
    ],
    preventionMeasures: [
      'Delint acid-treatment of cotton seeds with concentrated H2SO4 (100 ml/kg seed) followed by carboxin dressing.',
      'Sow certified disease-resistant or tolerant cultivars (e.g., Bt cotton hybrids with blight resistance genes).',
      'Maintain optimal crop spacing (90 cm × 60 cm) to ensure adequate sunlight penetration and airflow.',
      'Strict field hygiene and immediate destruction of volunteer cotton plants during fallow periods.'
    ],
    sarCldImageCount: 684,
    sampleImagePath: '/src/assets/images/cotton_bacterial_blight_1791647148723.jpg',
    sampleDescription: 'Cotton leaf exhibiting classic angular water-soaked lesions bounded by minor veins with dark necrotic centers.'
  },

  target_spot: {
    id: 'target_spot',
    name: 'Target Spot',
    scientificName: 'Corynespora cassiicola',
    pathogenType: 'Fungal',
    commonNames: ['Corynespora Leaf Spot', 'Bullseye Spot'],
    severity: 'High',
    primarySymptoms: [
      'Circular to irregular brown lesions displaying distinct concentric rings resembling an archery target',
      'Starts typically in the dense lower canopy around the 3rd to 5th week of bloom',
      'Rapid upward progression leading to sudden catastrophic canopy defoliation within 7–10 days',
      'Bract and boll lesions appear as dark circular sunken cankers'
    ],
    leafVisualCharacteristics: 'Concentric ring brown circular necrotic spots with well-defined dark borders and lighter center rings.',
    environmentalTriggers: {
      tempRange: '24°C – 30°C',
      humidity: '> 85% to 95% RH',
      weatherCondition: 'Continuous dense canopy humidity, prolonged leaf wetness (>8 hours), closed canopy rows'
    },
    economicImpact: 'Up to 30% yield loss in high-yielding irrigated cotton due to sudden defoliation during peak boll filling stage.',
    treatments: [
      {
        category: 'Chemical',
        title: 'Quinone Outside Inhibitor (QoI) & SDHI Fungicides',
        recommendation: 'Apply Azoxystrobin 18.2% + Difenoconazole 11.4% SC or Pyraclostrobin 20% WG or Fluxapyroxad + Pyraclostrobin.',
        dosage: '1.0 ml/L (Azoxystrobin+Difenoconazole) or 0.8 g/L (Pyraclostrobin)',
        applicationSchedule: 'First spray at 3rd week of bloom if lower canopy shows lesions; second spray 14 days later.',
        cautions: 'Rotate fungicide modes of action (FRAC 11 and FRAC 7) to mitigate rapid fungicide resistance.'
      },
      {
        category: 'Biological/Organic',
        title: 'Trichoderma harzianum Foliar Spray',
        recommendation: 'Bio-fungicide formulation of Trichoderma harzianum or Bacillus subtilis foliar spray.',
        dosage: '5 g to 10 g per Liter of water',
        applicationSchedule: 'Bi-weekly preventive spray before dense canopy closure.'
      },
      {
        category: 'Agronomic/Cultural',
        title: 'Canopy Management with Plant Growth Regulators (PGR)',
        recommendation: 'Apply Mepiquat chloride (PGR) judiciously to control rank vegetative growth and prevent dense lodging. Increase row spacing to facilitate air circulation.'
      }
    ],
    preventionMeasures: [
      'Avoid high plant populations (>100,000 plants/ha) that create microclimates favorable for leaf wetness.',
      'Calibrate nitrogen applications; excess nitrogen exacerbates target spot severity.',
      'Monitor lower canopy leaves weekly beginning at first flower bloom.',
      'Deep plow infected residues post-harvest to accelerate fungal decay in the soil.'
    ],
    sarCldImageCount: 612,
    sampleImagePath: '/src/assets/images/cotton_target_spot_1791647161374.jpg',
    sampleDescription: 'Foliage showing characteristic concentric rings with dark margins and concentric necrotic rings in circular pattern.'
  },

  alternaria_spot: {
    id: 'alternaria_spot',
    name: 'Alternaria Leaf Spot',
    scientificName: 'Alternaria macrospora / Alternaria alternata',
    pathogenType: 'Fungal',
    commonNames: ['Brown Leaf Spot', 'Macrospora Blight'],
    severity: 'Moderate',
    primarySymptoms: [
      'Small, circular to irregular dull brown necrotic spots with purplish to dark red margins',
      'Concentric target-like rings may develop within older lesions',
      'Center of dried necrotic lesions frequently cracks or drops out leaving "shot-hole" perforations',
      'Predominantly infects older or nutrient-stressed leaves, seedling cotyledons, and mature bracts'
    ],
    leafVisualCharacteristics: 'Irregular brown spots with prominent purplish-brown margins, often with shot-hole centers.',
    environmentalTriggers: {
      tempRange: '20°C – 28°C',
      humidity: '> 75% Relative Humidity',
      weatherCondition: 'Intermittent rainfall followed by dry windy periods, particularly in potassium-deficient soils'
    },
    economicImpact: 'Moderate economic loss (10–20%); can become severe if combined with potassium deficiency or drought stress.',
    treatments: [
      {
        category: 'Chemical',
        title: 'Mancozeb or Difenoconazole Spray',
        recommendation: 'Spray Mancozeb 75% WP or Propiconazole 25% EC or Difenoconazole 25% EC at disease detection.',
        dosage: '2.5 g/L (Mancozeb) or 1.0 ml/L (Propiconazole)',
        applicationSchedule: 'Apply upon spotting first lesions; repeat once after 14 days if wet spells continue.',
        cautions: 'Ensure full coverage of both upper and lower leaf surfaces with a good surfactant.'
      },
      {
        category: 'Biological/Organic',
        title: 'Neem Oil & Copper Formulations',
        recommendation: 'Foliar spray of 1% Cold-Pressed Neem Oil (1500 ppm Azadirachtin) or Copper hydroxide.',
        dosage: '5 ml/L Neem Oil + 1 ml/L bio-surfactant',
        applicationSchedule: 'Preventive spray at 10-day intervals.'
      },
      {
        category: 'Agronomic/Cultural',
        title: 'Correct Potassium Deficiency & Soil Health',
        recommendation: 'Ensure adequate potash fertilizer application (MOP 50–60 kg/ha) as potassium stress directly predisposes cotton leaves to Alternaria infection.'
      }
    ],
    preventionMeasures: [
      'Seed treatment with Thiram or Captan (3 g/kg seed) to eradicate seed-borne Alternaria spores.',
      'Balanced fertilization with recommended N:P:K ratios; do not neglect secondary and micro-nutrients.',
      'Maintain good field drainage to prevent localized water stagnation and root stress.',
      'Crop rotation with non-host cereals or legumes every 2 seasons.'
    ],
    sarCldImageCount: 590,
    sampleImagePath: '/src/assets/images/cotton_alternaria_spot_1791647286604.jpg',
    sampleDescription: 'Leaf showing distinct brown irregular lesions with purplish-red rims and necrotic dry centers.'
  },

  powdery_mildew: {
    id: 'powdery_mildew',
    name: 'Powdery Mildew',
    scientificName: 'Leveillula taurica',
    pathogenType: 'Fungal',
    commonNames: ['Oidiopsis Gossypii Blight', 'White Mildew'],
    severity: 'Moderate',
    primarySymptoms: [
      'Superficial white powdery talcum-like fungal growth on upper and lower leaf lamina surfaces',
      'Underlying leaf tissue turns pale chlorotic yellow, subsequently turning brown and necrotic',
      'Leaves become brittle, curl downward along margins, and experience premature senescence',
      'Severe infection leads to widespread defoliation, reducing photosynthesis during square formation'
    ],
    leafVisualCharacteristics: 'Fine white powdery mycelial and conidial coating forming irregular patches across the leaf surface.',
    environmentalTriggers: {
      tempRange: '22°C – 28°C',
      humidity: '50% – 70% RH (Thrives even in semi-arid conditions)',
      weatherCondition: 'Warm dry days combined with cool humid nights and morning dew'
    },
    economicImpact: 'Causes 10% to 25% yield loss by reducing photosynthetic efficiency and causing early leaf drop.',
    treatments: [
      {
        category: 'Chemical',
        title: 'Wettable Sulfur & Triazole Fungicides',
        recommendation: 'Apply Wettable Sulfur 80% WDG (3 g/L) or Hexaconazole 5% EC (1.5 ml/L) or Penconazole 10% EC (0.5 ml/L).',
        dosage: '3.0 g/L (Wettable Sulfur) or 1.5 ml/L (Hexaconazole)',
        applicationSchedule: 'Initiate spray at initial appearance of white talc-like patches; repeat in 14 days.',
        cautions: 'Do not apply sulfur when field temperature exceeds 33°C to avoid severe leaf scorch.'
      },
      {
        category: 'Biological/Organic',
        title: 'Potassium Bicarbonate & Ampelomyces quisqualis',
        recommendation: 'Foliar application of Potassium Bicarbonate (5 g/L) or hyperparasitic fungus Ampelomyces quisqualis.',
        dosage: '5 g/L Potassium Bicarbonate + 0.5 ml spreader',
        applicationSchedule: 'Weekly morning foliar spray.'
      },
      {
        category: 'Agronomic/Cultural',
        title: 'Adequate Row Spacing & Weed Control',
        recommendation: 'Ensure wider crop spacing for light penetration, remove alternate weed hosts (e.g., Abutilon indicum).'
      }
    ],
    preventionMeasures: [
      'Plant less susceptible cultivars in areas with historic powdery mildew epidemics.',
      'Regular scouting during late vegetative to early reproductive growth stages.',
      'Avoid high density planting that creates sheltered microclimates.',
      'Maintain uniform soil moisture to avoid moisture stress spikes.'
    ],
    sarCldImageCount: 540,
    sampleImagePath: '/src/assets/images/cotton_powdery_mildew_1791647172981.jpg',
    sampleDescription: 'Abundant white powdery mycelial dusting spreading over the leaf blade with underlying yellowing.'
  },

  grey_mildew: {
    id: 'grey_mildew',
    name: 'Grey Mildew',
    scientificName: 'Ramularia areola (Pseudocercosporella albida)',
    pathogenType: 'Fungal',
    commonNames: ['Areolate Mildew', 'Dahiya Disease', 'False Mildew'],
    severity: 'High',
    primarySymptoms: [
      'Small, angular, pale translucent spots restricted by minor leaf veinlets (areolate appearance)',
      'Under-surface of leaf develops frosty, whitish-grey powdery conidiophores and conidia',
      'Corresponding upper surface appears chlorotic yellow, gradually turning necrotic brown',
      'Leaves dry up rapidly, roll inwards, and drop in large numbers, giving a "dahiya" or frosted look'
    ],
    leafVisualCharacteristics: 'Angular, frosty grey-white patches bounded by the leaf venation on the lower leaf surface with chlorosis above.',
    environmentalTriggers: {
      tempRange: '20°C – 26°C',
      humidity: '> 80% Relative Humidity',
      weatherCondition: 'Cool, cloudy, and damp weather in post-monsoon or late-season cotton crop'
    },
    economicImpact: 'Can cause devastating 25% to 40% yield drop under late-season cloudy damp weather if defoliation is unchecked.',
    treatments: [
      {
        category: 'Chemical',
        title: 'Carbendazim or Kresoxim-methyl',
        recommendation: 'Foliar spray with Carbendazim 50% WP (1 g/L) or Kresoxim-methyl 44.3% SC (1 ml/L) or Azoxystrobin (1 ml/L).',
        dosage: '1.0 g/L (Carbendazim) or 1.0 ml/L (Kresoxim-methyl)',
        applicationSchedule: 'Spray immediately upon detection of frosty angular spots; follow up in 12–15 days.',
        cautions: 'Rotate chemical groups to avoid resistance build-up.'
      },
      {
        category: 'Biological/Organic',
        title: 'Copper Hydroxide & Trichoderma viride',
        recommendation: 'Foliar application of Copper Hydroxide (2 g/L) or Trichoderma viride bio-fungicide.',
        dosage: '2.5 g/L Copper Hydroxide',
        applicationSchedule: 'Bi-weekly applications under persistent cool damp weather.'
      },
      {
        category: 'Agronomic/Cultural',
        title: 'Crop Residue Destruction & Air Circulation',
        recommendation: 'Prune excess lower vegetative branches in late season. Burn or deep plow fallen infected leaves.'
      }
    ],
    preventionMeasures: [
      'Early sowing to complete boll filling prior to peak cool humid late-season weather.',
      'Optimum plant spacing avoiding claustrophobic dense stands.',
      'Avoid late excessive nitrogen top-dressing that prolongs vegetative succulence.',
      'Clean weeding to eliminate overwintering host plants.'
    ],
    sarCldImageCount: 575,
    sampleImagePath: '/src/assets/images/cotton_grey_mildew_1791647298407.jpg',
    sampleDescription: 'Angular frosted whitish-grey mycelial patches tightly bounded by leaf veinlets with yellowish mosaic discoloration.'
  },

  nutrient_deficiency: {
    id: 'nutrient_deficiency',
    name: 'Nutrient Deficiency',
    scientificName: 'Abiotic / Physiological Stress (K / N / Mg)',
    pathogenType: 'Physiological/Nutrient',
    commonNames: ['Potassium Hunger', 'Cotton Rust', 'Red Leaf Disease', 'Interveinal Chlorosis'],
    severity: 'Moderate',
    primarySymptoms: [
      'Interveinal chlorosis with characteristic yellowish-bronze mottling between veins on older leaves',
      'Margins and tips curl downward, turn dark reddish-brown, and undergo marginal necrosis ("leaf scorch")',
      'In nitrogen deficiency, entire canopy becomes pale light green to yellow starting from bottom leaves',
      'In magnesium deficiency, purplish-red discoloration between green veins ("red leaf syndrome")'
    ],
    leafVisualCharacteristics: 'Uniform symmetrical interveinal yellowing, bronze discoloration, upward/downward edge curl, and necrotic margins while main veins stay green.',
    environmentalTriggers: {
      tempRange: 'Variable (Any)',
      humidity: 'Independent of humidity',
      weatherCondition: 'Sandy soils, compacted root zones, waterlogging or prolonged drought impairing nutrient uptake'
    },
    economicImpact: 'Causes premature boll opening, small boll sizes, reduced lint quality, and up to 30% reduction in boll retention.',
    treatments: [
      {
        category: 'Chemical',
        title: 'Foliar Potassium Nitrate (13-0-45) & Magnesium Sulphate',
        recommendation: 'Foliar spray with Potassium Nitrate (KNO3) 13:0:45 at 10 g/L (1% solution) and Magnesium Sulphate (MgSO4) at 10 g/L.',
        dosage: '10 g to 15 g per Liter (1% to 1.5% solution)',
        applicationSchedule: 'Spray 3 to 4 times at 10-day intervals beginning from flowering to peak boll development.',
        cautions: 'Spray in early morning or late afternoon to prevent salt scorch on foliage.'
      },
      {
        category: 'Biological/Organic',
        title: 'Bio-Fertilizers & Potash Mobilizing Bacteria (KMB)',
        recommendation: 'Soil application of Potash Mobilizing Bacteria (Frateuria aurantia) and enriched Farm Yard Manure (FYM).',
        dosage: '5 kg/ha KMB mixed with 500 kg FYM',
        applicationSchedule: 'Apply at planting and top-dress at 45 days.'
      },
      {
        category: 'Agronomic/Cultural',
        title: 'Soil Testing & Balanced Fertilizer Management',
        recommendation: 'Apply Muriate of Potash (MOP) based on soil test recommendations (typically 60–90 kg K2O/ha). Split K application: 50% basal + 50% at flowering.'
      }
    ],
    preventionMeasures: [
      'Perform pre-sowing soil fertility analysis to calculate accurate NPK and micronutrient requirements.',
      'Incorporate 10–12 tonnes/ha of well-decomposed organic manure before sowing.',
      'Maintain regular drip irrigation intervals to prevent cyclic drought-stress induced nutrient lock.',
      'Apply foliar micronutrient mixtures (B, Zn, Fe) during square formation.'
    ],
    sarCldImageCount: 520,
    sampleImagePath: '/src/assets/images/cotton_nutrient_deficiency_1791647311124.jpg',
    sampleDescription: 'Leaf showing interveinal yellowing and bronze coloration with curling necrotic margins, typical of potassium deficiency.'
  },

  healthy: {
    id: 'healthy',
    name: 'Healthy Leaf',
    scientificName: 'Gossypium hirsutum L.',
    pathogenType: 'Healthy Organism',
    commonNames: ['Normal Cotton Foliage', 'Vigorous Plant Canopy'],
    severity: 'None',
    primarySymptoms: [
      'Smooth, intact leaf blade with uniform rich emerald green coloration',
      'No necrotic lesions, water-soaked spots, fungal mycelium, or powdery efflorescence',
      'Healthy turgid petiole with vigorous vascular leaf veins and intact margins',
      'Active photosynthesis and normal vegetative/reproductive biomass accumulation'
    ],
    leafVisualCharacteristics: 'Clean deep green leaf lamina with well-defined venation, supple turgor, zero spotting or discoloration.',
    environmentalTriggers: {
      tempRange: '25°C – 32°C (Optimal)',
      humidity: '55% – 75% RH',
      weatherCondition: 'Abundant sunshine, adequate soil moisture, well-drained loamy soil, good canopy ventilation'
    },
    economicImpact: 'Healthy canopy ensures maximal boll weight, premium fiber micronaire, high ginning outturn (GOT), and peak yield potential.',
    treatments: [
      {
        category: 'Agronomic/Cultural',
        title: 'Maintain Standard Integrated Crop Management (ICM)',
        recommendation: 'Continue regular field scouting twice a week. Maintain balanced NPK nutrition and schedule irrigation according to crop growth stage.',
        dosage: 'Standard crop management protocol',
        applicationSchedule: 'Bi-weekly monitoring routine.'
      },
      {
        category: 'Biological/Organic',
        title: 'Prophylactic Bio-Stimulant Spray',
        recommendation: 'Optional prophylactic spray of seaweed extract (Ascophyllum nodosum) or humic acid to boost foliar vigor and disease resistance.',
        dosage: '2 ml/L seaweed extract'
      }
    ],
    preventionMeasures: [
      'Continue routine IPM (Integrated Pest and Disease Management) surveillance.',
      'Maintain proper drainage in rainy spells to avoid waterlogging.',
      'Use pheromone traps and yellow sticky cards for early pest monitoring.',
      'Protect beneficial entomofauna (predatory ladybird beetles, spiders).'
    ],
    sarCldImageCount: 710,
    sampleImagePath: '/src/assets/images/cotton_healthy_leaf_1791647135053.jpg',
    sampleDescription: 'Uniformly green, turgid cotton leaf blade with pristine venation and zero pathological lesions.'
  }
};
