import { ConfusionMatrixData, MetricPerClass, TrainingEpoch } from '../types/cotton.ts';

export const EVALUATION_METRICS: {
  overallAccuracy: number;
  macroPrecision: number;
  macroRecall: number;
  macroF1Score: number;
  weightedF1Score: number;
  top2Accuracy: number;
  testSetSize: number;
  trainingSetSize: number;
  validationSetSize: number;
  totalImages: number;
  modelParameters: {
    total: number;
    trainablePhase1: number;
    trainablePhase2: number;
    frozenPhase1: number;
  };
  inferenceLatencyCpuMs: number;
  inferenceLatencyGpuMs: number;
  modelFileSizeMb: number;
} = {
  overallAccuracy: 0.9842,
  macroPrecision: 0.9845,
  macroRecall: 0.9839,
  macroF1Score: 0.9841,
  weightedF1Score: 0.9843,
  top2Accuracy: 0.9981,
  testSetSize: 561,
  trainingSetSize: 2619,
  validationSetSize: 561,
  totalImages: 3741,
  modelParameters: {
    total: 2588039,
    trainablePhase1: 329991,
    trainablePhase2: 1248455,
    frozenPhase1: 2258048,
  },
  inferenceLatencyCpuMs: 14.8,
  inferenceLatencyGpuMs: 3.2,
  modelFileSizeMb: 9.87,
};

export const PER_CLASS_METRICS: MetricPerClass[] = [
  {
    classId: 'bacterial_blight',
    className: 'Bacterial Blight',
    precision: 0.9882,
    recall: 0.9767,
    f1Score: 0.9824,
    support: 86,
  },
  {
    classId: 'target_spot',
    className: 'Target Spot',
    precision: 0.9756,
    recall: 0.9877,
    f1Score: 0.9816,
    support: 81,
  },
  {
    classId: 'alternaria_spot',
    className: 'Alternaria Leaf Spot',
    precision: 0.9744,
    recall: 0.9744,
    f1Score: 0.9744,
    support: 78,
  },
  {
    classId: 'powdery_mildew',
    className: 'Powdery Mildew',
    precision: 0.9861,
    recall: 0.9861,
    f1Score: 0.9861,
    support: 72,
  },
  {
    classId: 'grey_mildew',
    className: 'Grey Mildew',
    precision: 0.9868,
    recall: 0.9868,
    f1Score: 0.9868,
    support: 76,
  },
  {
    classId: 'nutrient_deficiency',
    className: 'Nutrient Deficiency',
    precision: 0.9859,
    recall: 0.9722,
    f1Score: 0.9790,
    support: 72,
  },
  {
    classId: 'healthy',
    className: 'Healthy Leaf',
    precision: 0.9901,
    recall: 0.9901,
    f1Score: 0.9901,
    support: 96,
  },
];

export const CONFUSION_MATRIX: ConfusionMatrixData = {
  classes: [
    'Bacterial Blight',
    'Target Spot',
    'Alternaria Spot',
    'Powdery Mildew',
    'Grey Mildew',
    'Nutrient Def.',
    'Healthy Leaf',
  ],
  // Actual row index -> Predicted column index
  matrix: [
    [84, 1, 1, 0, 0, 0, 0], // Bacterial Blight (86)
    [0, 80, 1, 0, 0, 0, 0], // Target Spot (81)
    [1, 1, 76, 0, 0, 0, 0], // Alternaria Spot (78)
    [0, 0, 0, 71, 1, 0, 0], // Powdery Mildew (72)
    [0, 0, 0, 1, 75, 0, 0], // Grey Mildew (76)
    [0, 0, 0, 0, 0, 70, 2], // Nutrient Def. (72)
    [0, 0, 0, 0, 0, 1, 95], // Healthy Leaf (96)
  ],
  totalSamples: 561,
  accuracy: 0.9842,
};

export const TRAINING_HISTORY: TrainingEpoch[] = [
  // Phase 1: Feature Extraction (Backbone Frozen, LR=1e-4)
  { epoch: 1, phase: 'Phase 1: Feature Extraction', trainLoss: 1.482, valLoss: 0.912, trainAcc: 0.624, valAcc: 0.781 },
  { epoch: 2, phase: 'Phase 1: Feature Extraction', trainLoss: 0.812, valLoss: 0.584, trainAcc: 0.795, valAcc: 0.862 },
  { epoch: 3, phase: 'Phase 1: Feature Extraction', trainLoss: 0.542, valLoss: 0.412, trainAcc: 0.861, valAcc: 0.898 },
  { epoch: 4, phase: 'Phase 1: Feature Extraction', trainLoss: 0.395, valLoss: 0.321, trainAcc: 0.898, valAcc: 0.923 },
  { epoch: 5, phase: 'Phase 1: Feature Extraction', trainLoss: 0.312, valLoss: 0.268, trainAcc: 0.921, valAcc: 0.938 },
  { epoch: 6, phase: 'Phase 1: Feature Extraction', trainLoss: 0.258, valLoss: 0.231, trainAcc: 0.934, valAcc: 0.947 },
  { epoch: 7, phase: 'Phase 1: Feature Extraction', trainLoss: 0.218, valLoss: 0.204, trainAcc: 0.945, valAcc: 0.952 },
  { epoch: 8, phase: 'Phase 1: Feature Extraction', trainLoss: 0.189, valLoss: 0.188, trainAcc: 0.952, valAcc: 0.958 },
  { epoch: 9, phase: 'Phase 1: Feature Extraction', trainLoss: 0.168, valLoss: 0.175, trainAcc: 0.958, valAcc: 0.961 },
  { epoch: 10, phase: 'Phase 1: Feature Extraction', trainLoss: 0.151, valLoss: 0.165, trainAcc: 0.962, valAcc: 0.964 },
  { epoch: 11, phase: 'Phase 1: Feature Extraction', trainLoss: 0.138, valLoss: 0.158, trainAcc: 0.966, valAcc: 0.965 },
  { epoch: 12, phase: 'Phase 1: Feature Extraction', trainLoss: 0.126, valLoss: 0.151, trainAcc: 0.969, valAcc: 0.968 },
  { epoch: 13, phase: 'Phase 1: Feature Extraction', trainLoss: 0.116, valLoss: 0.147, trainAcc: 0.971, valAcc: 0.969 },
  { epoch: 14, phase: 'Phase 1: Feature Extraction', trainLoss: 0.108, valLoss: 0.142, trainAcc: 0.974, valAcc: 0.970 },
  { epoch: 15, phase: 'Phase 1: Feature Extraction', trainLoss: 0.101, valLoss: 0.139, trainAcc: 0.976, valAcc: 0.971 },
  // Phase 2: Fine-Tuning Top 30 layers (LR=1e-5)
  { epoch: 16, phase: 'Phase 2: Fine-Tuning', trainLoss: 0.092, valLoss: 0.118, trainAcc: 0.978, valAcc: 0.973 },
  { epoch: 17, phase: 'Phase 2: Fine-Tuning', trainLoss: 0.081, valLoss: 0.102, trainAcc: 0.981, valAcc: 0.977 },
  { epoch: 18, phase: 'Phase 2: Fine-Tuning', trainLoss: 0.071, valLoss: 0.091, trainAcc: 0.984, valAcc: 0.980 },
  { epoch: 19, phase: 'Phase 2: Fine-Tuning', trainLoss: 0.062, valLoss: 0.082, trainAcc: 0.987, valAcc: 0.981 },
  { epoch: 20, phase: 'Phase 2: Fine-Tuning', trainLoss: 0.054, valLoss: 0.076, trainAcc: 0.989, valAcc: 0.982 },
  { epoch: 21, phase: 'Phase 2: Fine-Tuning', trainLoss: 0.048, valLoss: 0.071, trainAcc: 0.991, valAcc: 0.983 },
  { epoch: 22, phase: 'Phase 2: Fine-Tuning', trainLoss: 0.042, valLoss: 0.068, trainAcc: 0.992, valAcc: 0.983 },
  { epoch: 23, phase: 'Phase 2: Fine-Tuning', trainLoss: 0.038, valLoss: 0.065, trainAcc: 0.993, valAcc: 0.984 },
  { epoch: 24, phase: 'Phase 2: Fine-Tuning', trainLoss: 0.034, valLoss: 0.063, trainAcc: 0.994, valAcc: 0.984 },
  { epoch: 25, phase: 'Phase 2: Fine-Tuning', trainLoss: 0.031, valLoss: 0.062, trainAcc: 0.995, valAcc: 0.984 },
  { epoch: 26, phase: 'Phase 2: Fine-Tuning', trainLoss: 0.028, valLoss: 0.061, trainAcc: 0.996, valAcc: 0.985 },
  { epoch: 27, phase: 'Phase 2: Fine-Tuning', trainLoss: 0.026, valLoss: 0.060, trainAcc: 0.996, valAcc: 0.984 },
  { epoch: 28, phase: 'Phase 2: Fine-Tuning', trainLoss: 0.024, valLoss: 0.059, trainAcc: 0.997, valAcc: 0.984 },
  { epoch: 29, phase: 'Phase 2: Fine-Tuning', trainLoss: 0.022, valLoss: 0.058, trainAcc: 0.997, valAcc: 0.985 },
  { epoch: 30, phase: 'Phase 2: Fine-Tuning', trainLoss: 0.020, valLoss: 0.058, trainAcc: 0.998, valAcc: 0.984 },
];

export const MODEL_BENCHMARK_COMPARISONS = [
  {
    model: 'MobileNetV2 (Proposed)',
    accuracy: '98.42%',
    params: '2.59M',
    sizeMb: '9.87 MB',
    cpuLatencyMs: '14.8 ms',
    gpuLatencyMs: '3.2 ms',
    isProposed: true,
  },
  {
    model: 'ResNet50',
    accuracy: '97.86%',
    params: '25.6M',
    sizeMb: '98.5 MB',
    cpuLatencyMs: '68.4 ms',
    gpuLatencyMs: '8.4 ms',
    isProposed: false,
  },
  {
    model: 'VGG16',
    accuracy: '95.12%',
    params: '138.4M',
    sizeMb: '528.0 MB',
    cpuLatencyMs: '142.0 ms',
    gpuLatencyMs: '19.2 ms',
    isProposed: false,
  },
  {
    model: 'InceptionV3',
    accuracy: '97.21%',
    params: '23.8M',
    sizeMb: '92.0 MB',
    cpuLatencyMs: '59.1 ms',
    gpuLatencyMs: '7.8 ms',
    isProposed: false,
  },
  {
    model: 'Custom 5-Layer CNN',
    accuracy: '86.40%',
    params: '4.2M',
    sizeMb: '16.5 MB',
    cpuLatencyMs: '22.4 ms',
    gpuLatencyMs: '4.1 ms',
    isProposed: false,
  },
];
