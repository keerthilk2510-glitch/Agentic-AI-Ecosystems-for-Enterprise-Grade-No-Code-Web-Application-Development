export type CottonClassId =
  | 'healthy'
  | 'bacterial_blight'
  | 'target_spot'
  | 'alternaria_spot'
  | 'powdery_mildew'
  | 'grey_mildew'
  | 'nutrient_deficiency';

export type SeverityLevel = 'None' | 'Low' | 'Moderate' | 'High' | 'Severe';

export interface AdvisoryTreatment {
  category: 'Chemical' | 'Biological/Organic' | 'Agronomic/Cultural';
  title: string;
  recommendation: string;
  dosage?: string;
  applicationSchedule?: string;
  cautions?: string;
}

export interface CottonConditionInfo {
  id: CottonClassId;
  name: string;
  scientificName: string;
  pathogenType: 'Bacterial' | 'Fungal' | 'Physiological/Nutrient' | 'Healthy Organism';
  commonNames: string[];
  severity: SeverityLevel;
  primarySymptoms: string[];
  leafVisualCharacteristics: string;
  environmentalTriggers: {
    tempRange: string;
    humidity: string;
    weatherCondition: string;
  };
  economicImpact: string;
  treatments: AdvisoryTreatment[];
  preventionMeasures: string[];
  sarCldImageCount: number;
  sampleImagePath: string;
  sampleDescription: string;
}

export interface PredictionResult {
  classId: CottonClassId;
  className: string;
  scientificName: string;
  confidence: number; // 0 to 1
  inferenceTimeMs: number;
  allProbabilities: {
    classId: CottonClassId;
    className: string;
    probability: number;
  }[];
  severity: SeverityLevel;
  advisory: CottonConditionInfo;
  analyzedAt: string;
  imageDimensions: { width: number; height: number };
}

export interface MetricPerClass {
  classId: CottonClassId;
  className: string;
  precision: number;
  recall: number;
  f1Score: number;
  support: number; // test set sample count
}

export interface ConfusionMatrixData {
  classes: string[];
  matrix: number[][]; // [actual][predicted]
  totalSamples: number;
  accuracy: number;
}

export interface TrainingEpoch {
  epoch: number;
  phase: 'Phase 1: Feature Extraction' | 'Phase 2: Fine-Tuning';
  trainLoss: number;
  valLoss: number;
  trainAcc: number;
  valAcc: number;
}
